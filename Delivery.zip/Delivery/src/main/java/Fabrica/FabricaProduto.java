/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Fabrica;

import Aplicacao.Produto;
import java.util.ArrayList;

/**
 *
 * @author eidiyoshi
 */
public class FabricaProduto {

    public FabricaProduto() {
    }
    
    public Produto fabricar(String nome, double preco, String categoria, String descricao, ArrayList<String> Ingredientes, String customizacao){
        Produto produto = new Produto(nome,preco,categoria,descricao,Ingredientes,customizacao);
        return produto;
    }
}
