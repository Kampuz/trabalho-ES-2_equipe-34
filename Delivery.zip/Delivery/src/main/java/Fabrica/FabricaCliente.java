/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Fabrica;

import Aplicacao.Cliente;

/**
 *
 * @author eidiyoshi
 */
public class FabricaCliente {

    public FabricaCliente() {
    }
    
    public Cliente fabricar(String nome, String apelido, String email, String senha, int cpf, String endereco){
        Cliente cliente = new Cliente(nome,apelido,senha,cpf,email,endereco);
        return cliente;
    }
}
