/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Fabrica;

import Aplicacao.Restaurante;

/**
 *
 * @author eidiyoshi
 */
public class FabricaRestaurante {
    public Restaurante fabricar(String nomeRest, String nomeDono, String email, String Senha, int cnpj, int cpf, String descricao, String endereco){
        Restaurante rest = new Restaurante(nomeRest, nomeDono, email, Senha, cnpj, cpf, descricao, endereco);
        return rest;
    }

    public FabricaRestaurante() {
    }
}
