/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Aplicacao.Cardapio;
import Aplicacao.Pedido;
import Aplicacao.Produto;
import Aplicacao.Restaurante;
import Catalogo.CatalogoRestaurante;
import Fabrica.FabricaRestaurante;
import java.util.ArrayList;

/**
 *
 * @author eidiyoshi
 */
public class ControladorRestaurante {
    private CatalogoRestaurante catalogoRestaurante;

    public ControladorRestaurante() {
        catalogoRestaurante = new CatalogoRestaurante();
    }
    
    
    public void adicionarProdutoCardapio(int cnpj, String nome, Double preco, String categoria, String descricao, ArrayList<String> ingredientes, String customizacao){
        Restaurante rest = catalogoRestaurante.buscarRestauranteCNPJ(cnpj);
        rest.adicionarItem(nome, preco, categoria, descricao, ingredientes, customizacao);
    }
    
    public void alterarItemCardapio(int cnpj, Produto produto, String novoNome, String novaDescricao, double novoPreco, String novaCategoria, ArrayList<String> novosIngredientes, String novasCustomizacoes){
        Restaurante rest = catalogoRestaurante.buscarRestauranteCNPJ(cnpj);
        rest.alterarItemCardapio(produto, novoNome, novaDescricao, novoPreco, novosIngredientes, novasCustomizacoes);
    }
    
    public void alterarPerfilRestaurante(int cnpj, String novoNome, String novaSenha, String novoEndereco, String novoNomeEstabelecimento){
        Restaurante rest = catalogoRestaurante.buscarRestauranteCNPJ(cnpj);
        rest.atualizarDados(novoNome, novaSenha, novoEndereco, novoEndereco, novoNomeEstabelecimento);
    }
    
    public boolean validarDados(int cnpj, String email){
        return !catalogoRestaurante.buscarRestauranteCNPJBool(cnpj) && !catalogoRestaurante.buscarRestauranteEmailBool(email);
    }
    
    public void cadastrarRestaurante(String nomeRest, String nomeDono, String email, String senha, int cpf, int cnpj, String descricao, String endereco){
        FabricaRestaurante fabrica = new FabricaRestaurante();
        Restaurante rest = fabrica.fabricar(nomeRest, nomeDono, email, senha, cnpj, cpf, descricao, endereco);
        catalogoRestaurante.adicionarRestaurante(rest);
    }
    
    public boolean validaConectar(String email, String senha){
        return catalogoRestaurante.validaConectar(email, senha);
    }
    
    public boolean buscaCadastro(int cnpj){
        return !catalogoRestaurante.buscarRestauranteCNPJBool(cnpj);
    }
    
    public void desconectarUsuarioRest(Restaurante rest){
        
    }
    
    public ArrayList<String> buscarItemInfo(int cnpj, String nomeProduto){
        return catalogoRestaurante.buscarItemInfo(cnpj, nomeProduto);
    }
    
    public ArrayList<String> exibirInfoRestaurante(int cnpj){
        return catalogoRestaurante.getInfoRest(cnpj);
    }
    
    public ArrayList<String> pesquisaRestaurante(String nome){
        return catalogoRestaurante.getInfoRest(nome);
    }
    
    public ArrayList<Produto> pesquisaProduto(String nome){
        return catalogoRestaurante.getProdutos(nome);
    }
    
    public ArrayList<Pedido> buscarPedidosRestaurante(int cnpj){
        return catalogoRestaurante.getPedidos(cnpj);
    }
    
    public void removerProdutoCardapio(String nomeProduto, int cnpj){
        catalogoRestaurante.removerProdutoCardapio(nomeProduto, cnpj);
    }
    
}
