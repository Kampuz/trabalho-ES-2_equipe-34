/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Aplicacao.Cliente;
import Catalogo.CatalogoCliente;
import Fabrica.FabricaCliente;

/**
 *
 * @author eidiyoshi
 */
public class ControladorCliente {
    private CatalogoCliente catalogoCliente;

    public ControladorCliente() {
        catalogoCliente = new CatalogoCliente();
    }
    
    public boolean validarDados(int cpf, String email){
        return !catalogoCliente.buscaClienteCPFBool(cpf) && !catalogoCliente.buscaClienteEmailBool(email);
    }
    
    public boolean cadastrarCliente(String nome, String apelido, String email, String senha, int cpf, String endereco){
        FabricaCliente fabrica = new FabricaCliente();
        Cliente cliente = fabrica.fabricar(nome, apelido, email, senha, cpf, endereco);
        if( catalogoCliente.adicionarCliente(cliente) && validarDados(cpf,email) ){
            return true;
        }
        return false;
    }
    
    public void AlterarPerfilCliente(int cpf, String novoNome, String novaSenha, String novoApelido, String novoEndereco){
        FabricaCliente fabrica = new FabricaCliente();
        Cliente cliente = catalogoCliente.buscaClienteCPF(cpf);
        Cliente clienteNovo = fabrica.fabricar(novoNome, novoApelido, cliente.getEmail(), novaSenha, cliente.getCpf(), novoEndereco);
        
        catalogoCliente.atualizarCliente(cpf, clienteNovo);
    }
    
    public void validarConectar(String email, String senha){
        
    }
    
    public void desconectarCliente(Cliente cliente){
        
    }
}
