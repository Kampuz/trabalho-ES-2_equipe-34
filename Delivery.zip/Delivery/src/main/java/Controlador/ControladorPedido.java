/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Aplicacao.Cliente;
import Aplicacao.Pedido;
import Aplicacao.Produto;
import java.util.ArrayList;

/**
 *
 * @author eidiyoshi
 */
public class ControladorPedido {
    
    
    public ArrayList<String> atualizarPedidos(Cliente cliente){
        
    }
    
    public ArrayList<String> obterDetalhesPedido(Pedido pedido){
        
    }
    
    public boolean adicionarItemCarrinho(Produto produto, int quantidade){
        
    }
    
    public void alterarQuantidadeCarrinho(Produto produto, int novaQuantidade){
        
    }
    
    public void atualizarPedido(Pedido pedido, String novoStatus){
        
    }
    
    public void registrarAvaliacao(Pedido pedido, int nota, String descricao){ // vai pegar do catalogo, vai atualizar diretamente, vai atualizar o pedido no catalogo
        
    }
    
    public void aceitarPedido(Pedido pedido){
        
    }
    
    public void rejeitarPedido(Pedido pedido){
        
    }
    
    public ArrayList<String> receberPedidos(Restaurante restaurante){
        
    }
    
    public void removerProdutoCarrinho(Produto produto, Carrinho carrinho){
        
    }
    
    public void cancelarPedido(int codigo){
        
    }
    
    public void confirmarEntrega(int codigo){
        
    }
    
    public ArrayList<String> historicoPedidos(Restaurante restaurante){
        
    }
}
