/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Aplicacao.Cardapio;
import Aplicacao.Carrinho;
import Aplicacao.Cliente;
import Aplicacao.ItemPedido;
import Aplicacao.Pagamento;
import Aplicacao.Pedido;
import Aplicacao.Produto;
import Aplicacao.Restaurante;
import java.util.ArrayList;

/**
 *
 * @author eidiyoshi
 */
public class ControladorGeral {
    // NAOFUNCIONA ControladorCarrinho controladorCarrinhoNAOFUNCIONA;
    ControladorCliente controladorCliente;
    // NAOFUNCIONA ControladorPedido controladorPedido;
    ControladorRestaurante controladorRestaurante;

    public ControladorGeral() {
        //controladorCarrinho = new ControladorCarrinho();
        controladorCliente = new ControladorCliente();
        //controladorPedido = new ControladorPedido();
        controladorRestaurante = new ControladorRestaurante();
    }
    
    public void cadastrarUsuario(String nome, String apelido, String email, String senha, int CPF, String endereco){
        controladorCliente.cadastrarCliente(nome, apelido, email, senha, CPF, endereco);
    }
    
    public ArrayList<String> atualizarPedidos(){
    }
    
    public ArrayList<String> obterDetalhesPedido(){
        
    }
    
    public void adicionarProdutoCardapio(int cnpj, String nome, double preco, String categoria, String descricao, ArrayList<String> Ingredientes, String Customização){
        controladorRestaurante.adicionarProdutoCardapio( cnpj , nome, preco, categoria, descricao, Ingredientes, Customização);
    }
    
    public void adicionarProdutoCarrinho(ItemPedido itemPedido){
        
    }
    
    public void alterarItemCardapio(int cnpj, Produto produto, String novoNome, String novaDescricao, double novoPreco, String novaCategoria, ArrayList<String> novosIngredientes, String novasCustomizacoes){
        controladorRestaurante.alterarItemCardapio(cnpj, produto, novoNome, novaDescricao, novoPreco, novaCategoria, novosIngredientes, novasCustomizacoes);
    }
    
    public void alterarPerfilCliente(int cpf, String novoNome, String novaSenha, String novaDescricao, String novoEndereco, String novoNomeEstabelecimento){
        controladorCliente.AlterarPerfilCliente(cpf, novoNome, novaSenha, novoEndereco, novoEndereco);
    }
    
    public void alterarQuantidadeCarrinho(Produto produto, int novaQuantidade){
        
    }
    
    public void atualizarPedido(Pedido pedido, String novoStatus){
        
    }
    
    public void enviarAvaliacao(Pedido pedido, int nota, String comentario){
        
    }
    
    public void alterarPerfilRestaurante(String novoNome, String novaSenha, String novaDescricao, String novoEndereco, String novoNomeEstabelecimento){
        controladorRestaurante.alterarPerfilRestaurante(cnpj, novoNome, novaSenha, novoEndereco, novoNomeEstabelecimento);
    }
    
    public void aceitarPedido(Pedido pedido){
        
    }
    
    public void rejeitarPedido(Pedido pedido){
        
    }
    
    public ArrayList<String> receberPedidos(Restaurante rest){
        
    }
    
    public void removerProdutoCardapio(String nomeProduto, int cnpj){
        controladorRestaurante.removerProdutoCardapio(nomeProduto, cnpj);
    }
    
    public void removerProdutoCarrinho(Produto produto, Carrinho carrinho){
   
        
    }
    
    public void cadastrarUsuarioRestaurante(String nomeRest, String nomeDono, String email, String senha, int cpf, int cnpj, String descricao, String endereco){
        controladorRestaurante.cadastrarRestaurante(nomeRest, nomeDono, email, senha, cpf, cnpj, descricao, endereco);
    }
    
    public void cancelarPedido(int codigo){
        
    }
    
    public void conectarUsuarioCliente(String email, String senha){
        
    }
    
    public void conectarUsuarioRestaurante(String email, String senha){
        
    }
    
    public void confirmarEntrega(int codigo){
        
    }
    
    public void desconectarUsuarioCLiente(Cliente cliente){
        
    }
    
    public void desconectarUsuarioRestaurante(Restaurante rest){
        
    }
    
    public boolean efetuarPagamento(Pagamento pag){
        
    }
    
    public void selecionarPagamento(Pedido pedido){
        
        
    }
    
    public ArrayList<String> historicoPedidos(Restaurante rest){
        
    }
    
    public void exibirInfoItem(int cnpj, String nomeProduto){
        controladorRestaurante.buscarItemInfo(cnpj, nomeProduto);
    }
    
    public void selecionarRestaurante(){
        
    }
    
    public ArrayList<String> exibirInfoRestaurante(int cnpj){
        return controladorRestaurante.exibirInfoRestaurante(cnpj);
    }
    
    public ArrayList<Produto> pesquisaItemRestaurante(String nome){
        return controladorRestaurante.pesquisaProduto(nome);
    }
    
    public double realizarPedido(Pedido pedido){
        
    }

    public ArrayList<Pedido> buscarPedidosRestaurante(int cnpj){
        return controladorRestaurante.buscarPedidosRestaurante(cnpj);
    }
}

