/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Catalogo;

import Aplicacao.Cliente;
import Aplicacao.Pedido;
import Aplicacao.Restaurante;
import java.util.ArrayList;

/**
 *
 * @author eidiyoshi
 */
public class CatalogoPedido {
    private ArrayList<Pedido> pedidos;

    public CatalogoPedido() {
        pedidos = new ArrayList<Pedido>();
    }
    
    public boolean buscarPorCodigoConfirmacao(int codigo){
        for(int i = 0; i < pedidos.size(); i++){
            if( pedidos.get(i).getCodigo() == codigo ){
                return true;
            }
        }
        return false;
    }
    
    public Pedido buscarPedido(Pedido pedido){
        return null;
    }
    
    public ArrayList<Pedido> buscarPedidosDoCliente(Cliente cliente){
        return null;
    }
    
    public void atualizarPedido(Pedido pedido, Pedido pedidoNovo){
        for(int i = 0; i < pedidos.size(); i++){
            if( pedidos.get(i).equals(pedido) ){
                pedidos.set(i, pedidoNovo);
            }
        }
    }
    
    public void cancelaPedido(int codigo){
        for(int i = 0; i < pedidos.size(); i++){
            if( pedidos.get(i).getCodigo() == codigo ){
                pedidos.get(i).setStatus("cancelado");
            }
        }
    }
    
    public boolean confirmarEntrega(int codigo){
        for(int i = 0; i < pedidos.size(); i++){
            if( pedidos.get(i).getCodigo() == codigo ){
                pedidos.get(i).setStatus("entregue");
                return true;
            }
        }
        return false;
    }
    
    
    public void confirmarCancelamento(int codigo){
        
    }
}
