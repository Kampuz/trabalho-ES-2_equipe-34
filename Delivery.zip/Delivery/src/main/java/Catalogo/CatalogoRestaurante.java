/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Catalogo;

import Aplicacao.Pedido;
import Aplicacao.Produto;
import Aplicacao.Restaurante;
import java.util.ArrayList;

/**
 *
 * @author eidiyoshi
 */
public class CatalogoRestaurante {
    private ArrayList<Restaurante> restaurantes;

    public CatalogoRestaurante() {
        restaurantes = new ArrayList<Restaurante>();
    }
    
    
    public void atualizarRestaurante(Restaurante restaurante, Restaurante restauranteNovo){
        for(int i = 0; i < restaurantes.size(); i++){
            if( restaurantes.get(i).equals(restaurante) ){
                restaurantes.set(i, restauranteNovo);
            }
        }
        
    }
    
    public Restaurante buscarRestauranteCNPJ(int CNPJ){
        for(int i = 0; i < restaurantes.size(); i++){
            if( restaurantes.get(i).getCnpj() == CNPJ ){
                return restaurantes.get(i);
            }
        }
        return null;
    }
    
    public Restaurante buscarRestauranteEmail(String email){
        for(int i = 0; i < restaurantes.size(); i++){
            if( restaurantes.get(i).getEmail().equals(email) ){
                return restaurantes.get(i);
            }
        }
        return null;
    }
    
    public boolean buscarRestauranteEmailBool(String email){
        for(int i = 0; i < restaurantes.size(); i++){
            if( restaurantes.get(i).getEmail().equals(email) ){
                return true;
            }
        }
        return false;
    }
    
    public boolean buscarRestauranteCNPJBool(int cnpj){
        for(int i = 0; i < restaurantes.size(); i++){
            if( restaurantes.get(i).getCnpj() == cnpj ){
                return true;
            }
        }
        return false;
    }
    
    public void adicionarRestaurante(Restaurante rest){
        restaurantes.add(rest);
    }
    
    public Restaurante buscarConectar(String email, String senha){
        for(int i = 0; i < restaurantes.size(); i++){
            if( restaurantes.get(i).getEmail().equals(email) && restaurantes.get(i).getSenha().equals(senha)){
                return restaurantes.get(i);
            }
        }
        return null;
    }
    
    public void buscaRestaurante(Restaurante rest){
        
    }
    
    public ArrayList<Pedido> buscarPedidosRestaurante(int cnpj){
        for(int i = 0; i < restaurantes.size(); i++){
            if( restaurantes.get(i).getCnpj() == cnpj ){
                return restaurantes.get(i).getPedidos();
            }
        }
        return null;
    }
    
    public ArrayList<String> getHistoricoPedidos(Restaurante restaurante){
        for(int i = 0; i < restaurantes.size(); i++){
            if( restaurantes.get(i).equals(restaurante) ){
                return restaurantes.get(i).getHistoricoPedidos();
            }
        }
        return null;
    }
    
    public ArrayList<String> buscarItemInfo(int cnpj, String produto){
        for(int i = 0; i < restaurantes.size(); i++){
            if( restaurantes.get(i).getCnpj() == cnpj ){
                return restaurantes.get(i).getProdutoInfo(produto);
            }
        }
        return null;
    }
    
    public ArrayList<String> getInfoRest(int cnpj){
        for(int i = 0; i < restaurantes.size(); i++){
            if( restaurantes.get(i).getCnpj() == cnpj ){
                return restaurantes.get(i).getInfoRestaurante();
            }
        }
        return null;
    }
    
    public ArrayList<String> getInfoRest(String nomeRest){
        for(int i = 0; i < restaurantes.size(); i++){
            if( restaurantes.get(i).getNomeRest().equals(nomeRest) ){
                return restaurantes.get(i).getInfoRestaurante();
            }
        }
        return null;
    }
    
    public ArrayList<Pedido> getPedidos(int cnpj){
        for(int i = 0; i < restaurantes.size(); i++){
            if( restaurantes.get(i).getCnpj() == cnpj ){
                return restaurantes.get(i).getPedidos();
            }
        }
        return null;
    }
    
    public ArrayList<Produto> getProdutos(String nomeRest){
        for(int i = 0; i < restaurantes.size(); i++){
            if( restaurantes.get(i).getNomeRest().equals(nomeRest) ){
                return restaurantes.get(i).getProdutos();
            }
        }
        return null;
    }
    
    public boolean validaConectar(String email, String senha){
        for(int i = 0; i < restaurantes.size(); i++){
            if( restaurantes.get(i).getEmail().equals(email) ){
                return restaurantes.get(i).validarConectar(senha);
            }
        }
        return false;
    }
    
    public void removerProdutoCardapio(String nomeProduto, int cnpj){
        for(int i = 0; i < restaurantes.size(); i++){
            if( restaurantes.get(i).getCnpj() == cnpj){
                restaurantes.get(i).removerProdutoCardapio(nomeProduto);
            }
        }
    }
}
