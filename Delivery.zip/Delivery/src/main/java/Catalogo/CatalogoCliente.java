/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Catalogo;

import Aplicacao.Cliente;
import java.util.ArrayList;

/**
 *
 * @author eidiyoshi
 */
public class CatalogoCliente {
    private ArrayList<Cliente> clientes;

    public CatalogoCliente() {
        clientes = new ArrayList<Cliente>();
    }
    
    public Cliente buscaClienteCPF(int cpf){
        for(int i = 0; i < clientes.size(); i++){
            if( clientes.get(i).getCpf() == cpf){
                return clientes.get(i);
            }
        }
        return null;
    }
    
    public boolean buscaClienteCPFBool(int cpf){
        for(int i = 0; i < clientes.size(); i++){
            if( clientes.get(i).getCpf() == cpf){
                return true;
            }
        }
        return false;
    }
    
    public Cliente buscaClienteEmail(String email){
        for(int i = 0; i < clientes.size(); i++){
            if( (clientes.get(i).getEmail()).equals(email) ){
                return clientes.get(i);
            }
        }
        return null;
    }
    
    public boolean buscaClienteEmailBool(String email){
        for(int i = 0; i < clientes.size(); i++){
            if( (clientes.get(i).getEmail()).equals(email) ){
                return true;
            }
        }
        return false;
    }
    
    public boolean adicionarCliente(Cliente cliente ){
        if(cliente != null){
            clientes.add(cliente);
            return true;
        }
        return false;
    }
    
    public void atualizarCliente(int cpf, Cliente clienteAtualizado){
        for(int i = 0; i < clientes.size(); i++){
            if( clientes.get(i).getCpf() == cpf ){
                clientes.set(i, clienteAtualizado);
            }
        }
    }
    
    public Cliente buscaCadastro(String email, String senha){
        for(int i = 0; i < clientes.size(); i++){
            if( clientes.get(i).getEmail().equals(email) && clientes.get(i).getSenha().equals(senha) ){
                return clientes.get(i);
            }
        }
        return null;
    }
    
    
}
