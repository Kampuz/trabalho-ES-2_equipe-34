/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Aplicacao;

import java.time.LocalTime;
import java.util.ArrayList;

/**
 *
 * @author eidiyoshi
 */
public class Pedido {
    private LocalTime horario;
    private double valor;
    private String status;
    private int codigo;
    private Pagamento pagamento;
    private Avaliacao avaliacao;
    
    public ArrayList<String> retornarPedido(){
        ArrayList<String> arrayInfo = new ArrayList<String>();
        arrayInfo.add(String.valueOf(horario));
        arrayInfo.add(String.valueOf(valor));
        arrayInfo.add(status);
        arrayInfo.add(String.valueOf(codigo));
        arrayInfo.add(pagamento.getTipo());
        arrayInfo.add(pagamento.getStatus());
        arrayInfo.add(String.valueOf(pagamento.getValor()));
        arrayInfo.add(avaliacao.getComentario());
        arrayInfo.add(String.valueOf(avaliacao.getNota()));
        return arrayInfo;
    }
    
    public ArrayList<String> getDetalhes(){
        ArrayList<String> arrayInfo = new ArrayList<String>();
        arrayInfo.add(String.valueOf(horario));
        arrayInfo.add(String.valueOf(valor));
        arrayInfo.add(status);
        arrayInfo.add(String.valueOf(codigo));
        arrayInfo.add(pagamento.getTipo());
        arrayInfo.add(pagamento.getStatus());
        arrayInfo.add(String.valueOf(pagamento.getValor()));
        arrayInfo.add(avaliacao.getComentario());
        arrayInfo.add(String.valueOf(avaliacao.getNota()));
        return arrayInfo;
    }
    
    public void atualizarStatus(String novoStatus){
        this.status = novoStatus;
    }
    
    public void adicionarAvaliacao(Avaliacao avaliacao){
        this.avaliacao = avaliacao;
    }

    public LocalTime getHorario() {
        return horario;
    }

    public void setHorario(LocalTime horario) {
        this.horario = horario;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public Pagamento getPagamento() {
        return pagamento;
    }

    public void setPagamento(Pagamento pagamento) {
        this.pagamento = pagamento;
    }

    public Avaliacao getAvaliacao() {
        return avaliacao;
    }

    public void setAvaliacao(Avaliacao avaliacao) {
        this.avaliacao = avaliacao;
    }
    
}
