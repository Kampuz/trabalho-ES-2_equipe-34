/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Aplicacao;

import java.util.ArrayList;

/**
 *
 * @author eidiyoshi
 */
public class Produto {
    private String nome;
    private double preco;
    private String descricao;
    private String categoria;
    private ArrayList<String> ingredientes;
    private String customizacao;

    public Produto(String nome, double preco, String descricao, String categoria, ArrayList<String> ingredientes, String customizacao) {
        this.nome = nome;
        this.preco = preco;
        this.descricao = descricao;
        this.categoria = categoria;
        this.ingredientes = ingredientes;
        this.customizacao = customizacao;
    }
    

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public ArrayList<String> getIngredientes() {
        return ingredientes;
    }

    public void setIngredientes(ArrayList<String> ingredientes) {
        this.ingredientes = ingredientes;
    }

    public String getCustomizacao() {
        return customizacao;
    }

    public void setCustomizacao(String customizacao) {
        this.customizacao = customizacao;
    }
}
