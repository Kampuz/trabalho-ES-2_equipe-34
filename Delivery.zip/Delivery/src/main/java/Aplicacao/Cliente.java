/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Aplicacao;

import java.util.ArrayList;

/**
 *
 * @author eidiyoshi
 */
public class Cliente {
    private String nome;
    private String apelido;
    private String senha;
    private int cpf;
    private String email;
    private String endereco;
    private ArrayList<Pedido> pedidos;

    public Cliente(String nome, String apelido, String senha, int cpf, String email, String endereco) {
        this.nome = nome;
        this.apelido = apelido;
        this.senha = senha;
        this.cpf = cpf;
        this.email = email;
        this.endereco = endereco;
    }
    
    
    
    public Cliente atualizarDados(String novoNome, String novaSenha, String novoApelido, String novoEndereco){
        this.nome = novoNome;
        this.senha = novaSenha;
        this.apelido = novoApelido;
        this.endereco = novoEndereco;
        pedidos = new ArrayList<Pedido>();
        return this;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getApelido() {
        return apelido;
    }

    public void setApelido(String apelido) {
        this.apelido = apelido;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public int getCpf() {
        return cpf;
    }

    public void setCpf(int cpf) {
        this.cpf = cpf;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }
    
    
}
