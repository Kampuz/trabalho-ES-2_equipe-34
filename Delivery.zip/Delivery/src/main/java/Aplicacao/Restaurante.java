/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Aplicacao;

import Fabrica.FabricaProduto;
import java.util.ArrayList;

/**
 *
 * @author eidiyoshi
 */
public class Restaurante {
    private String nomeRest;
    private String nomeDono;
    private String senha;
    private int cpf;
    private String email;
    private int cnpj;
    private String descricao;
    private String endereco;
    private Cardapio cardapio;
    private ArrayList<Pedido> pedidos;
    
    public Restaurante(String nomeRest, String nomeDono, String email,String senha, int cnpj, int cpf, String descricao, String endereco) {
        this.nomeRest = nomeRest;
        this.nomeDono = nomeDono;
        this.senha = senha;
        this.cpf = cpf;
        this.email = email;
        this.cnpj = cnpj;
        this.descricao = descricao;
        this.endereco = endereco;
        pedidos = new ArrayList<Pedido>();
    }
    
    
    public void adicionarItem(String nome, double preco, String cateogria, String descricao, ArrayList<String> ingredientes, String customizacao){
        FabricaProduto fabrica = new FabricaProduto();
        cardapio.adicionarItem(fabrica.fabricar(nome, preco, cateogria, descricao, ingredientes, customizacao));
    }
    
    public void alterarItemCardapio(Produto produto, String novoNome, String novaDescricao, double novoPreco, ArrayList<String> novosIngredientes, String novasCustomizacoes){
        cardapio.alterarItem(produto, novoNome, novaDescricao, novoPreco, novaDescricao, novosIngredientes, novasCustomizacoes);
    }
    
    public void atualizarDados(String novoNome, String novaSenha, String novaDescricao, String novoEndereco, String novoNomeEstabelecimento){
        this.nomeDono = novoNome;
        this.senha = novaSenha;
        this.descricao = novaDescricao;
        this.endereco = novoEndereco;
        this.nomeRest = novoNomeEstabelecimento;
    }
    
    public ArrayList<String> getInfoRestaurante(){
        ArrayList<String> arrayInfo = new ArrayList<String>();
        arrayInfo.add(nomeRest);
        arrayInfo.add(nomeDono);
        arrayInfo.add(senha);
        arrayInfo.add(String.valueOf(cpf));
        arrayInfo.add(email);
        arrayInfo.add(String.valueOf(cnpj));
        arrayInfo.add(descricao);
        arrayInfo.add(endereco);
        return arrayInfo;
    }
    
    public Restaurante buscaRestaurante(String nome){
        return null;
    }

    public String getNomeRest() {
        return nomeRest;
    }

    public void setNomeRest(String nomeRest) {
        this.nomeRest = nomeRest;
    }

    public String getNomeDono() {
        return nomeDono;
    }

    public void setNomeDono(String nomeDono) {
        this.nomeDono = nomeDono;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public int getCpf() {
        return cpf;
    }

    public void setCpf(int cpf) {
        this.cpf = cpf;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getCnpj() {
        return cnpj;
    }

    public void setCnpj(int cnpj) {
        this.cnpj = cnpj;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public Cardapio getCardapio() {
        return cardapio;
    }

    public void setCardapio(Cardapio cardapio) {
        this.cardapio = cardapio;
    }

    public ArrayList<Pedido> getPedidos() {
        return pedidos;
    }

    public void setPedidos(ArrayList<Pedido> pedidos) {
        this.pedidos = pedidos;
    }
    
    public ArrayList<String> getHistoricoPedidos(){
        ArrayList<String> arrayHist = new ArrayList<String>();
        for(int i = 0; i < pedidos.size(); i++){
            if( pedidos.get(i).getStatus().equals("cancelado") || pedidos.get(i).getStatus().equals("entregue") ){
                arrayHist.add(String.valueOf(pedidos.get(i).getCodigo()));
            }
        }
        return arrayHist;
    }
    
    public ArrayList<String> getProdutoInfo(String produto){
        return cardapio.getProdutoInfo(produto);
    }
    
    public ArrayList<Produto> getProdutos(){
        return cardapio.getProdutos();
    }
    
    public boolean validarConectar(String senha){
        return this.senha.equals(senha);
    }
    
    public void removerProdutoCardapio(String nomeProduto){
        cardapio.removerProduto(nomeProduto);
    }
}
