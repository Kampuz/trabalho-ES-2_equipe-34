/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Aplicacao;

import java.util.ArrayList;

/**
 *
 * @author eidiyoshi
 */
public class Carrinho {
    private ArrayList<ItemPedido> produtos;
    private double valorTotal;
    
    public boolean adicionarProduto(ItemPedido itemPedido){
        if(itemPedido == null){
            return false;
        }
        produtos.add(itemPedido);
        return true;
    }
    
    public void alterarQuantidade(Produto produto, int novaQuantidade){
        for(int i = 0; i < produtos.size(); i++){
            if(produto.equals(produtos.get(i).getProduto())){
                produtos.get(i).setQuantidade(novaQuantidade);
            }
        }
    }
    
    public boolean removerProduto(ItemPedido itemPedido){
        for(int i = 0; i < produtos.size(); i++){
            if(itemPedido.equals(produtos.get(i).getProduto())){
                produtos.remove(i);
            }
        }
    }
    
    public void realizarPedido(Pedido pedido){
        if(!produtos.isEmpty()){
            
        }
    }
}
