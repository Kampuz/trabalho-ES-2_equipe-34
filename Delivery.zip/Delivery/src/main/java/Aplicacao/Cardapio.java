/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Aplicacao;

import java.util.ArrayList;

/**
 *
 * @author eidiyoshi
 */
public class Cardapio {
    private ArrayList<Produto> itens;
    
    public void adicionarItem(Produto produto){
        itens.add(produto);
        System.out.println("Cardapio: adicionarItem sucesso");
    }
    
    public void alterarItem(Produto produto, String novoNome, String novaDescricao, double novoPreco, String novaCategoria, ArrayList<String> novosIngredientes, String novasCustomizacoes){
        for(int i = 0; i < itens.size(); i++){
            if(produto.equals(itens.get(i))){
                itens.get(i).setNome(novoNome);
                itens.get(i).setDescricao(novaDescricao);
                itens.get(i).setPreco(novoPreco);
                itens.get(i).setCategoria(novaCategoria);
                itens.get(i).setIngredientes(novosIngredientes);
                itens.get(i).setCustomizacao(novasCustomizacoes);
                System.out.println("Cardapio: alterarItem sucesso");
            }
        }
    }
    
    public boolean removerProduto(String nomeProduto){
        for(int i = 0; i < itens.size(); i++){
            if(nomeProduto.equals(itens.get(i).getNome())){
                itens.remove(i);
                return true;
            }
        }
        return false;
    }
    
    public ArrayList<String> getProdutoInfo(String nome){
        for(int i = 0; i < itens.size(); i++){
            if(nome.equals(itens.get(i).getNome())){
                ArrayList<String> arrayInfos = new ArrayList<String>();
                arrayInfos.add(itens.get(i).getNome());
                arrayInfos.add(itens.get(i).getCategoria());
                arrayInfos.add(String.valueOf(itens.get(i).getPreco() ));
                arrayInfos.add(itens.get(i).getCustomizacao());
                return arrayInfos;
            }
        }
        return null;
    }

    public ArrayList<Produto> getProdutos() {
        return itens;
    }
}
