package Persistencia;

public class Arquivos {

    public void salvar() {
    }

    public void logTexto(String texto) {
        System.out.println("[LOG] " + texto);
    }

}