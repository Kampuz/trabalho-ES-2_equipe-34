package Persistencia;

public class logger {

    public static void logTexto(String texto) {
        System.out.println("[LOG] " + texto);
    }
    
    public static void log(String texto) {
        logTexto(texto);
    }
    
    public static void logRegistroImovel(String idImovel) {
        log("Registro de imóvel com ID: " + idImovel);
    }

}
