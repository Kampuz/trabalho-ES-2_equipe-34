package Controle;

import Interface.InterfaceCentral;
import Conceitos.Cliente;
import Conceitos.CobrancaAluguel;
import Conceitos.CobrancaMulta;
import Conceitos.EnumCargo;
import Conceitos.Funcionario;
import Conceitos.imovel;
import Conceitos.LaudoTecnico;
import Conceitos.LaudoVistoria;
import Conceitos.EnumGenero;
import Conceitos.EnumImovel;
import Catalogos.CatalogoFuncionario;
import Persistencia.logger;
import java.time.LocalDateTime;
import java.awt.Graphics2D;
import java.util.HashMap;
import java.util.Map;

public class ControladorCentral {

	private ControladorFuncionario controladorFuncionario;

	private ControladorGerente controladorGerente;

	private InterfaceCentral interfaceCentral;
        
        private CatalogoFuncionario catalogoFuncionarios;
        private logger logger;
        private Map<String, Boolean> funcionariosConectados; 
        
        public ControladorCentral() {
            this.controladorFuncionario = ControladorFuncionario.getInstance();
            this.controladorGerente = ControladorGerente.getInstance();
            this.catalogoFuncionarios = CatalogoFuncionario.getInstance();
            this.logger = new logger();
            this.funcionariosConectados = new HashMap<>();
        }

	public boolean criarAgendamentoVisita(Cliente cliente, Funcionario funcionario, imovel imovel, LocalDateTime data_hora) {
            return controladorFuncionario.criarAgendamentoVisita(data_hora.toString(), funcionario.getNome(), cliente.getNome(), imovel.getNome());
	}

	public boolean criarAgendamentoVistoria(Cliente cliente, Funcionario funcionario, imovel imovel, LocalDateTime data_hora) {
            return controladorFuncionario.criarAgendamentoVistoria(data_hora.toString(), funcionario.getNome(), imovel.getNome());
	}

	public boolean registrarCliente(String nome, LocalDateTime data_nascimento, String CPFouCNPJ, String telefone, String email, String endereco, EnumGenero genero, Graphics2D imagem) {
            if (!validarDadosCliente(nome)) {
                logger.logTexto("Falha no registro de cliente - Dados inválidos");
                return false;
            }
            
            return controladorFuncionario.registrarCliente(nome, data_nascimento, CPFouCNPJ, telefone, email, endereco, genero, imagem);
	}
        
        public void registrarCliente(String nome, String email, String celular) {
            if (validarDadosCliente(nome)) {
                registrarCliente(nome, null, "", celular, email, "", null, null);
            } else {
                logger.logTexto("Registro de cliente rejeitado - Nome inválido: " + nome);
            }
        }
        
        public boolean editarCliente(String identificador, String nome, String telefone, String email, String endereco, EnumGenero genero) {
            return controladorFuncionario.editarCliente(identificador, nome, telefone, email, endereco, genero);
        }
        
        public boolean editarImovel(String identificador, String nome, EnumImovel tipo, boolean ocupado, String cliente) {
            return controladorFuncionario.editarImovel(identificador, nome, tipo, ocupado, cliente);
        }
        
        public boolean arquivarImovel(String identificador) {
            return controladorFuncionario.arquivarImovel(identificador);
        }
        
        public boolean arquivarCliente(String identificador) {
            return controladorFuncionario.arquivarCliente(identificador);
        }
        
        public boolean arquivarFuncionario(String identificador) {
            return controladorGerente.arquivarFuncionario(identificador);
        }
        
        public boolean processarPagamentoAluguel(String identificadorCobranca) {
            return controladorFuncionario.processarPagamentoAluguel(identificadorCobranca);
        }
        
        public boolean processarPagamentoMulta(String identificadorCobranca) {
            return controladorFuncionario.processarPagamentoMulta(identificadorCobranca);
        }
        
        public boolean editarCobrancaAluguel(String identificador, Double novoValor, LocalDateTime novoVencimento) {
            return controladorFuncionario.editarCobrancaAluguel(identificador, novoValor, novoVencimento);
        }
        
        public boolean editarCobrancaMulta(String identificador, Double novoValor, Integer novosDiasAtraso, Double novosJuros) {
            return controladorFuncionario.editarCobrancaMulta(identificador, novoValor, novosDiasAtraso, novosJuros);
        }
        
        public java.util.List<CobrancaAluguel> listarCobrancasAluguelPendentes() {
            return controladorFuncionario.listarCobrancasAluguelPendentes();
        }
        
        public java.util.List<CobrancaMulta> listarCobrancasMultaPendentes() {
            return controladorFuncionario.listarCobrancasMultaPendentes();
        }
        
        public Catalogos.CatalogoCliente getCatalogoCliente() {
            return controladorFuncionario.getCatalogoCliente();
        }
        
        
        public boolean editarSeguro(String identificadorSeguro, String nome, Double valor, String descricao, Boolean ativo) {
            return controladorFuncionario.editarSeguro(identificadorSeguro, nome, valor, descricao, ativo);
        }

	public void registrarAluguel(int caucao, float comissao_imobiliaria, float desconto, Funcionario funcionario_responsavel, imovel imovel, Cliente locatario) {
            
	}

	public boolean registrarFuncionario(String nome, LocalDateTime data_nascimento, String CPF, String telefone, String email, String endereco, EnumGenero genero, Graphics2D imagem, EnumCargo cargo, double salario) {
            if (!validarNome(nome)) {
                logger.logTexto("Falha no registro de funcionário - Nome inválido: " + nome);
                return false;
            }
            
            return controladorGerente.registrarFuncionario(nome, data_nascimento, CPF, telefone, email, endereco, genero, imagem, cargo, salario);
	}

	public boolean registrarGerente(String nome, LocalDateTime data_nascimento, String CPF, String telefone, String email, String endereco, EnumGenero genero, Graphics2D imagem, double salario) {
            if (!validarNome(nome)) {
                logger.logTexto("Falha no registro de gerente - Nome inválido: " + nome);
                return false;
            }
            
            return controladorGerente.registrarFuncionario(nome, data_nascimento, CPF, telefone, email, endereco, genero, imagem, EnumCargo.GERENTE, salario);
	}
        
        public boolean registrarFuncionarioComSenha(String nome, String senha, LocalDateTime data_nascimento, String CPF, String telefone, String email, String endereco, EnumGenero genero, Graphics2D imagem, EnumCargo cargo, double salario) {
            if (!validarDadosFuncionario(nome, senha)) {
                logger.logTexto("Falha no registro de funcionário - Dados inválidos (nome ou senha)");
                return false;
            }
            
            boolean sucesso = controladorGerente.registrarFuncionarioComSenha(nome, senha, data_nascimento, CPF, telefone, email, endereco, genero, imagem, cargo, salario);
            
            if (sucesso) {
                logger.logTexto("Funcionário registrado com sucesso: " + nome + " - Validações RF_En1 e RF_En2 aplicadas");
            }
            
            return sucesso;
        }

	public boolean registrarImovel(String nome, String cliente, EnumImovel tipo_imovel, boolean ocupado, int laudo_tecnico, int laudo_vistoria, Graphics2D imagem) {
            return controladorFuncionario.registrarImovel(nome, cliente, tipo_imovel, ocupado, laudo_tecnico, laudo_vistoria, imagem);
	}

	public boolean registrarLaudoVistoria(String nome_responsavel, String descricao) {
            return controladorFuncionario.registrarLaudoVistoria(nome_responsavel, descricao);
	}

	public boolean registrarLaudoTecnico(String nome_responsavel, String endereco, double valor, double area_total, double area_interna) {
            return controladorFuncionario.registrarLaudoTecnico(nome_responsavel, endereco, valor, area_total, area_interna);
	}
        
        public boolean registrarSeguro(String nome, double valor, String descricao) {
            return controladorFuncionario.registrarSeguro(nome, valor, descricao);
        }
        
        public boolean registrarSeguro(String nome, double valor, String descricao, boolean ativacao) {
            return controladorFuncionario.registrarSeguro(nome, valor, descricao, ativacao);
        }
        
        public Cliente buscarClientePorNome(String nome) {
            return controladorFuncionario.buscarClientePorNome(nome);
        }

        public Funcionario buscarFuncionarioPorNome(String nome) {
            return controladorGerente.buscarFuncionarioPorNome(nome);
        }
        
        public Funcionario buscarFuncionario(String identificador) {
            return catalogoFuncionarios.buscarFuncionario(identificador);
        }
        
        public imovel buscarImovel(String nome) {
            return controladorFuncionario.buscarImovel(nome);
        }
        
        public double consultaGastosMensais() {
            return controladorFuncionario.consultaGastosMensais();
        }

        public String consultaIdentificador(int objetivo, String identificador) {
            return controladorFuncionario.consultaIdentificador(objetivo, identificador);
        }

        public String consultaListagem(int objetivo) {
            return controladorFuncionario.consultaListagem(objetivo);
        }
        
        public Funcionario realizarLogin(String email, String senha) {
            try {
                logger.logTexto("Tentativa de login para: " + email);
                
                if (email == null || email.trim().isEmpty() || senha == null || senha.trim().isEmpty()) {
                    logger.logTexto("Erro: Dados de login vazios");
                    return null;
                }
                
                
                Funcionario funcionario = catalogoFuncionarios.buscarFuncionarioPorEmail(email);
                
                if (funcionario == null) {
                    logger.logTexto("Erro: Funcionário não encontrado para email: " + email);
                    return null;
                }
                
                if (funcionariosConectados.getOrDefault(email, false)) {
                    logger.logTexto("Erro: Funcionário já está conectado em outra máquina: " + email);
                    return null;
                }
                
                if (!funcionario.getSenha().equals(senha)) {
                    logger.logTexto("Erro: Senha incorreta para funcionário: " + email);
                    return null;
                }
                
                funcionariosConectados.put(email, true);
                logger.logTexto("Login realizado com sucesso para: " + funcionario.getNome());
                
                return funcionario;
                
            } catch (Exception e) {
                logger.logTexto("Erro no processo de login: " + e.getMessage());
                return null;
            }
        }
        
        public boolean realizarLogout(String email) {
            try {
                if (funcionariosConectados.containsKey(email)) {
                    funcionariosConectados.put(email, false);
                    logger.logTexto("Logout realizado para: " + email);
                    return true;
                }
                logger.logTexto("Tentativa de logout para funcionário não logado: " + email);
                return false;
            } catch (Exception e) {
                logger.logTexto("Erro no logout: " + e.getMessage());
                return false;
            }
        }
        
        public boolean isFuncionarioLogado(String email) {
            return funcionariosConectados.getOrDefault(email, false);
        }
        
        public String gerarRelatorioCustosMensais() {
            return controladorFuncionario.gerarRelatorioCustosMensais();
        }
        
        public String gerarRelatorioGeral() {
            return controladorFuncionario.gerarRelatorioGeral();
        }
        
        public boolean criarGerenteInicial() {
            try {
                if (catalogoFuncionarios.temFuncionarios()) {
                    return false; // Já foi criado
                }
                
                LocalDateTime nascimento = LocalDateTime.of(1980, 1, 1, 0, 0);
                boolean sucesso = registrarFuncionario(
                    "Gerente Inicial",
                    nascimento,
                    "00000000000",
                    "(11)99999-9999", 
                    "gerente@imobiliaria.com",
                    "Rua Principal, 123",
                    EnumGenero.MASCULINO,
                    null, // sem imagem
                    EnumCargo.GERENTE,
                    5000.0
                );
                
                if (sucesso) {
                    Funcionario gerenteInicial = catalogoFuncionarios.buscarFuncionario("Gerente Inicial");
                    if (gerenteInicial != null) {
                        logger.logTexto("=== CREDENCIAIS DO GERENTE INICIAL ===");
                        logger.logTexto("Nome: " + gerenteInicial.getNome());
                        logger.logTexto("Email: " + gerenteInicial.getEmail());
                        logger.logTexto("Senha: " + gerenteInicial.getSenha());
                        logger.logTexto("======================================");
                    }
                    logger.logTexto("Gerente inicial criado com sucesso - RF_En3 cumprido");
                }
                
                return sucesso;
                
            } catch (Exception e) {
                logger.logTexto("Erro ao criar gerente inicial: " + e.getMessage());
                return false;
            }
        }
        
        public boolean validarNome(String nome) {
            if (nome == null || nome.trim().isEmpty()) {
                logger.logTexto("Erro de validação: Nome está vazio");
                return false;
            }
            
            String regex = "^[a-zA-ZÀ-ÿ\\s]+$";
            
            if (!nome.matches(regex)) {
                logger.logTexto("Erro de validação RF_En1: Nome contém caracteres inválidos: " + nome);
                return false;
            }
            
            logger.logTexto("Nome válido: " + nome);
            return true;
        }
        
        public boolean validarSenha(String senha) {
            if (senha == null || senha.trim().isEmpty()) {
                logger.logTexto("Erro de validação: Senha está vazia");
                return false;
            }
            
            boolean temMinuscula = false;
            boolean temMaiuscula = false;
            boolean temNumero = false;
            boolean temEspecial = false;
            
            for (char c : senha.toCharArray()) {
                if (Character.isLowerCase(c) && Character.isLetter(c)) {
                    temMinuscula = true;
                } else if (Character.isUpperCase(c) && Character.isLetter(c)) {
                    temMaiuscula = true;
                } else if (Character.isDigit(c)) {
                    temNumero = true;
                } else if (!Character.isLetterOrDigit(c) && !Character.isWhitespace(c)) {
                    temEspecial = true;
                }
            }
            
            if (!temMinuscula) {
                logger.logTexto("Erro RF_En2: Senha deve conter pelo menos uma letra minúscula");
                return false;
            }
            if (!temMaiuscula) {
                logger.logTexto("Erro RF_En2: Senha deve conter pelo menos uma letra maiúscula");
                return false;
            }
            if (!temNumero) {
                logger.logTexto("Erro RF_En2: Senha deve conter pelo menos um número");
                return false;
            }
            if (!temEspecial) {
                logger.logTexto("Erro RF_En2: Senha deve conter pelo menos um caracter especial");
                return false;
            }
            
            logger.logTexto("Senha válida conforme RF_En2");
            return true;
        }
        
        public boolean validarDadosFuncionario(String nome, String senha) {
            boolean nomeValido = validarNome(nome);
            boolean senhaValida = validarSenha(senha);
            
            if (nomeValido && senhaValida) {
                logger.logTexto("Dados de funcionário válidos para: " + nome);
                return true;
            } else {
                logger.logTexto("Dados de funcionário inválidos - Nome: " + nomeValido + ", Senha: " + senhaValida);
                return false;
            }
        }
        
        public boolean validarDadosCliente(String nome) {
            return validarNome(nome);
        }
        
        
        public boolean editarFuncionarioProprio(String emailFuncionario, String novaSenha, String novoTelefone, String novoEmail, String novoEndereco) {
            return controladorGerente.editarFuncionarioProprio(emailFuncionario, novaSenha, novoTelefone, novoEmail, novoEndereco);
        }
        
        public boolean editarFuncionarioPorGerente(String identificadorFuncionario, String nome, String telefone, String email, String endereco, Graphics2D foto, EnumGenero genero, EnumCargo cargo, Double salario) {
            return controladorGerente.editarFuncionarioPorGerente(identificadorFuncionario, nome, telefone, email, endereco, foto, genero, cargo, salario);
        }
        
        public boolean editarFuncionarioGerenteInicial(String identificadorFuncionario, String nome, String telefone, String email, String endereco, Graphics2D foto, EnumGenero genero, EnumCargo cargo, Double salario, String novaSenha) {
            return controladorGerente.editarFuncionarioGerenteInicial(identificadorFuncionario, nome, telefone, email, endereco, foto, genero, cargo, salario, novaSenha);
        }
        
        public Funcionario getFuncionarioLogado() {
            for (String email : funcionariosConectados.keySet()) {
                if (funcionariosConectados.get(email)) {
                    return catalogoFuncionarios.buscarFuncionarioPorEmail(email);
                }
            }
            return null;
        }
        
}
