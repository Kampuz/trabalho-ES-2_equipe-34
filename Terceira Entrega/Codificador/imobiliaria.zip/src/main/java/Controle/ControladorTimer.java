package Controle;

import Catalogos.CatalogoCliente;

public class ControladorTimer {

	private CatalogoCliente catalogoCliente;

        public ControladorTimer() {
            this.catalogoCliente = CatalogoCliente.getInstance();
        }
        
        public void timerDia() {
            
            catalogoCliente.cobrarAluguel();
            
            
            catalogoCliente.cobrarMulta();
            
            
            catalogoCliente.verificarNotificacoes();
        }

}