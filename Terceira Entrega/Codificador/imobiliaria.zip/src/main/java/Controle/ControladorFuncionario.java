package Controle;

import Catalogos.CatalogoCliente;
import Catalogos.CatalogoLaudoTecnico;
import Catalogos.CatalogoLaudoVistoria;
import Catalogos.CatalogoImovel;
import Factory.FactoryImovel;
import Factory.FactoryCliente;
import Factory.FactoryLaudoVistoria;
import Factory.FactorySeguro;
import Catalogos.CatalogoSeguro;
import Factory.FactoryLaudoTecnico;
import Catalogos.CatalogoFuncionario;
import Catalogos.CatalogoAgendamentoVisita;
import Factory.FactoryAgendamentoVisita;
import Factory.FactoryAgendamentoVistoria;
import Catalogos.CatalogoAgendamentoVistoria;
import Catalogos.CatalogoContratoAluguel;
import Factory.FactoryContratoAluguel;
import Persistencia.logger;
import Conceitos.EnumGenero;
import Conceitos.EnumImovel;
import java.time.LocalDateTime;
import java.awt.Graphics2D;
import java.util.List;
import java.util.ArrayList;
import Conceitos.*;

public class ControladorFuncionario {
    
    private static ControladorFuncionario instance;

	private ControladorCentral controladorCentral;

	private CatalogoCliente catalogoCliente;

	private CatalogoLaudoTecnico catalogoLaudoTecnico;

	private CatalogoLaudoVistoria catalogoLaudoVistoria;

	private CatalogoImovel catalogoImovel;

	private FactoryImovel factoryImovel;

	private FactoryCliente factoryCliente;

	private FactoryLaudoVistoria factoryLaudoVistoria;

	private FactorySeguro factorySeguro;

	private CatalogoSeguro catalogoSeguro;

	private FactoryLaudoTecnico factoryLaudoTecnico;

	private CatalogoFuncionario catalogoFuncionario;

	private CatalogoAgendamentoVisita catalogoAgendamentoVisita;

	private FactoryAgendamentoVisita factoryAgendamentoVisita;

	private FactoryAgendamentoVistoria factoryAgendamentoVistoria;

	private CatalogoAgendamentoVistoria catalogoAgendamentoVistoria;

	private CatalogoContratoAluguel catalogoContratoAluguel;

	private FactoryContratoAluguel factoryContratoAluguel;

	private logger logger;

        private ControladorFuncionario() {
            this.catalogoCliente = CatalogoCliente.getInstance();
            this.catalogoImovel = CatalogoImovel.getInstance();
            this.catalogoFuncionario = CatalogoFuncionario.getInstance();
            this.catalogoSeguro = CatalogoSeguro.getInstance();
            this.catalogoLaudoTecnico = CatalogoLaudoTecnico.getInstance();
            this.catalogoLaudoVistoria = CatalogoLaudoVistoria.getInstance();
            this.catalogoAgendamentoVisita = CatalogoAgendamentoVisita.getInstance();
            this.catalogoAgendamentoVistoria = CatalogoAgendamentoVistoria.getInstance();
            this.catalogoContratoAluguel = new CatalogoContratoAluguel();
            this.factoryCliente = new FactoryCliente();
            this.factoryImovel = new FactoryImovel();
            this.factorySeguro = new FactorySeguro();
            this.factoryLaudoTecnico = new FactoryLaudoTecnico();
            this.factoryLaudoVistoria = new FactoryLaudoVistoria();
            this.factoryAgendamentoVisita = new FactoryAgendamentoVisita();
            this.factoryAgendamentoVistoria = new FactoryAgendamentoVistoria();
            this.factoryContratoAluguel = new FactoryContratoAluguel();
            this.logger = new logger();
        }
        
        public static synchronized ControladorFuncionario getInstance() {
            if (instance == null) {
                instance = new ControladorFuncionario();
            }
            return instance;
        }
        
        public CatalogoCliente getCatalogoCliente() {
            return CatalogoCliente.getInstance();
        }

	public boolean registrarImovel(String nome, String cliente, EnumImovel tipo_imovel, boolean ocupado, int laudo_tecnico, int laudo_vistoria, Graphics2D imagem) {
            try {
                Cliente proprietario = catalogoCliente.buscarCliente(cliente);
                if (proprietario == null) {
                    logger.logTexto("❌ ERRO: Cliente não encontrado: " + cliente + " - Cadastre o cliente primeiro");
                    return false;
                }
                
                LaudoTecnico laudoTec = catalogoLaudoTecnico.buscarLaudoTecnico(laudo_tecnico);
                if (laudoTec == null) {
                    logger.logTexto("❌ ERRO: Laudo técnico não encontrado (índice " + laudo_tecnico + ") - Cadastre o laudo primeiro");
                    return false;
                }
                
                LaudoVistoria laudoVist = null;
                if (laudo_vistoria >= 0) {
                    laudoVist = catalogoLaudoVistoria.buscarLaudoVistoria(laudo_vistoria);
                    if (laudoVist == null) {
                        logger.logTexto("❌ ERRO: Laudo de vistoria não encontrado (índice " + laudo_vistoria + ") - Cadastre o laudo primeiro");
                        return false;
                    }
                }
                
                imovel novoImovel = factoryImovel.criarImovel(nome, proprietario, tipo_imovel, ocupado, laudoTec, laudoVist, imagem);
                
                catalogoImovel.adicionarImovel(novoImovel);
                
                logger.logTexto("✅ Imóvel cadastrado com sucesso: " + nome);
                return true;
            } catch (Exception e) {
                logger.logTexto("❌ ERRO ao registrar imóvel: " + e.getMessage());
                return false;
            }
	}

	public boolean registrarCliente(String nome, LocalDateTime data_nascimento, String CPFouCNPJ, String telefone, String email, String endereco, EnumGenero genero, Graphics2D imagem) {
            try {
                Cliente cliente = factoryCliente.criarCliente(nome, data_nascimento, CPFouCNPJ, telefone, email, endereco, genero, imagem);
                
                boolean registrado = catalogoCliente.registrarCliente(cliente);
                
                if (!registrado) {
                    return false;
                }
                
                return catalogoCliente.valida();
            } catch (Exception e) {
                return false;
            }
	}

	public boolean registrarSeguro(String nome, double valor, String descricao) {
            return registrarSeguro(nome, valor, descricao, false);
	}
        
        public boolean registrarSeguro(String nome, double valor, String descricao, boolean ativacao) {
            try {
                if (descricao != null && descricao.length() > 2500) {
                    return false;
                }
                
                Seguro seguro = factorySeguro.criarSeguro(nome, valor, descricao, ativacao);
                
                catalogoSeguro.registrarSeguro(seguro);
                
                return true;
            } catch (Exception e) {
                return false;
            }
        }

	public boolean registrarLaudoVistoria(String nome_responsavel, String descricao) {
            try {
                Funcionario funcionario = catalogoFuncionario.buscarFuncionario(nome_responsavel);
                if (funcionario == null) {
                    logger.logTexto("❌ ERRO: Funcionário responsável não encontrado: " + nome_responsavel);
                    return false;
                }
                
                LaudoVistoria laudo = factoryLaudoVistoria.criarLaudoVistoria(nome_responsavel, descricao);
                
                catalogoLaudoVistoria.adicionarLaudo(laudo);
                
                logger.logTexto("✅ Laudo de vistoria cadastrado com sucesso");
                return true;
            } catch (Exception e) {
                logger.logTexto("❌ ERRO ao registrar laudo de vistoria: " + e.getMessage());
                return false;
            }
	}

	public boolean registrarLaudoTecnico(String nome_responsavel, String endereco, double valor, double area_total, double area_interna) {
            try {
                Funcionario funcionario = catalogoFuncionario.buscarFuncionario(nome_responsavel);
                if (funcionario == null) {
                    logger.logTexto("❌ ERRO: Funcionário responsável não encontrado: " + nome_responsavel);
                    return false;
                }
                
                LaudoTecnico laudo = factoryLaudoTecnico.criarLaudoTecnico(nome_responsavel, endereco, valor, area_total, area_interna);
                
                catalogoLaudoTecnico.adicionarLaudo(laudo);
                
                logger.logTexto("✅ Laudo técnico cadastrado com sucesso");
                return true;
            } catch (Exception e) {
                logger.logTexto("❌ ERRO ao registrar laudo técnico: " + e.getMessage());
                return false;
            }
	}

	public String consultaListagem(int objetivo) {
            logger.logTexto("🔍 DEBUG consultaListagem: objetivo=" + objetivo);
            
            if (objetivo == 0) {
                String resultado = catalogoCliente.listar();
                logger.logTexto("🔍 DEBUG Cliente listagem: " + (resultado != null ? "OK - " + resultado.length() + " chars" : "NULL"));
                return resultado;
            } else if (objetivo == 1) {
                String resultado = catalogoFuncionario.listar();
                logger.logTexto("🔍 DEBUG Funcionário listagem: " + (resultado != null ? "OK - " + resultado.length() + " chars" : "NULL"));
                return resultado;
            } else if (objetivo == 2) {
                String resultado = catalogoImovel.listar();
                logger.logTexto("🔍 DEBUG Imóvel listagem: " + (resultado != null ? "OK - " + resultado.length() + " chars" : "NULL"));
                logger.logTexto("🔍 DEBUG Conteúdo listagem imóveis: [" + resultado + "]");
                return resultado;
            }
            logger.logTexto("❌ DEBUG: Objetivo inválido para listagem: " + objetivo);
            return null;
	}

	public String consultaIdentificador(int objetivo, String identificador) {
            logger.logTexto("🔍 DEBUG consultaIdentificador: objetivo=" + objetivo + ", identificador=[" + identificador + "]");
            
            if (objetivo == 0) {
                Cliente cliente = catalogoCliente.buscarCliente(identificador);
                String resultado = cliente != null ? cliente.getNome() : null;
                logger.logTexto("🔍 DEBUG Cliente: " + (resultado != null ? "Encontrado: " + resultado : "Não encontrado"));
                return resultado;
            } else if (objetivo == 1) {
                Funcionario funcionario = catalogoFuncionario.buscarFuncionario(identificador);
                String resultado = funcionario != null ? funcionario.getNome() : null;
                logger.logTexto("🔍 DEBUG Funcionário: " + (resultado != null ? "Encontrado: " + resultado : "Não encontrado"));
                return resultado;
            } else if (objetivo == 2) {
                logger.logTexto("🔍 DEBUG: Buscando imóvel com nome: " + identificador);
                imovel imovel = catalogoImovel.buscarImovel(identificador);
                if (imovel != null) {
                    String resultado = "Nome: " + imovel.getNome() + 
                                     ", Proprietário: " + imovel.getProprietario().getNome() + 
                                     ", Tipo: " + imovel.getTipoImovel() +
                                     ", Ocupado: " + (imovel.isOcupado() ? "Sim" : "Não");
                    logger.logTexto("✅ DEBUG Imóvel encontrado: " + resultado);
                    return resultado;
                } else {
                    logger.logTexto("❌ DEBUG Imóvel não encontrado: " + identificador);
                    return null;
                }
            }
            logger.logTexto("❌ DEBUG: Objetivo inválido: " + objetivo);
            return null;
	}

	public double consultaGastosMensais() {
            return catalogoFuncionario.calcularGastos();
	}
	
        public String gerarRelatorioCustosMensais() {
            return catalogoCliente.gerarRelatorioCustosMensais();
        }
        
        public String gerarRelatorioGeral() {
            return catalogoCliente.gerarRelatorioGeral();
        }

	public boolean criarAgendamentoVisita(String data, String identificador_funcionario, String identificador_cliente, String identificador_imovel) {
            Funcionario funcionario = catalogoFuncionario.buscarFuncionario(identificador_funcionario);
            Cliente cliente = catalogoCliente.buscarCliente(identificador_cliente);
            imovel imovel = catalogoImovel.buscarImovel(identificador_imovel);
            
            if (funcionario == null || cliente == null || imovel == null) {
                return false;
            }
            
            if (catalogoAgendamentoVisita.verificaConflitoVisita()) {
                return false;
            }
            
            if (catalogoAgendamentoVistoria.verificaConflitoVistoria()) {
                return false;
            }
            
            try {
                java.time.LocalDateTime dataHora = java.time.LocalDateTime.parse(data);
                AgendamentoVisita agendamento = factoryAgendamentoVisita.criarAgendamentoVisita(dataHora, funcionario, cliente, imovel);
                catalogoAgendamentoVisita.adicionarAgendamento(agendamento);
                
                return true;
            } catch (Exception e) {
                return false;
            }
	}

	public boolean criarAgendamentoVistoria(String data, String identificador_funcionario, String identificador_imovel) {
            Funcionario funcionario = catalogoFuncionario.buscarFuncionario(identificador_funcionario);
            imovel imovel = catalogoImovel.buscarImovel(identificador_imovel);
            
            if (funcionario == null || imovel == null) {
                return false;
            }
            
            if (catalogoAgendamentoVistoria.verificaConflitoVistoria()) {
                return false;
            }
            
            if (catalogoAgendamentoVisita.verificaConflitoVisita()) {
                return false;
            }
            
            if (!catalogoAgendamentoVistoria.verificaAtivacaoVistoria()) {
                return false;
            }
            
            try {
                java.time.LocalDateTime dataHora = java.time.LocalDateTime.parse(data);
                AgendamentoVistoria agendamento = factoryAgendamentoVistoria.criarAgendamentoVistoria(dataHora, funcionario, imovel);
                catalogoAgendamentoVistoria.adicionarAgendamento(agendamento);
                
                return true;
            } catch (Exception e) {
                return false;
            }
	}

	public boolean registrarContratoAluguel(double caucao, double desconto, double comissao, String locatario, String funcionario, imovel imovel) {
            try {
                Cliente clienteLocatario = catalogoCliente.buscarCliente(locatario);
                Funcionario funcionarioResp = catalogoFuncionario.buscarFuncionario(funcionario);
                
                if (clienteLocatario == null || funcionarioResp == null || imovel == null) {
                    logger.logTexto("Erro: Entidades não encontradas para contrato de aluguel");
                    return false;
                }
                
                if (caucao < 0 || desconto < 0 || desconto > 1 || comissao < 0) {
                    logger.logTexto("Erro: Dados inválidos para contrato de aluguel");
                    return false;
                }
                
                ContratoAluguel contrato = factoryContratoAluguel.criarContratoAluguel(
                    caucao, desconto, comissao, clienteLocatario, funcionarioResp, imovel
                );
                
                catalogoContratoAluguel.adicionarContrato(contrato);
                
                logger.logTexto("Contrato de aluguel registrado com sucesso");
                return true;
                
            } catch (Exception e) {
                logger.logTexto("Erro ao registrar contrato de aluguel: " + e.getMessage());
                return false;
            }
	}
        
        public boolean arquivarImovel(String identificadorImovel) {
            try {
                imovel imovel = catalogoImovel.buscarImovel(identificadorImovel);
                if (imovel == null) {
                    logger.logTexto("Erro: Imóvel não encontrado: " + identificadorImovel);
                    return false;
                }
                
                boolean sucesso = catalogoImovel.arquivarImovel(identificadorImovel);
                
                if (sucesso) {
                    Cliente proprietario = imovel.getProprietario();
                    if (proprietario != null) {
                        proprietario.notificarCliente("Seu imóvel " + imovel.getNome() + " foi arquivado");
                    }
                    
                    logger.logTexto("Imóvel arquivado com sucesso: " + identificadorImovel);
                    return true;
                } else {
                    logger.logTexto("Erro ao arquivar imóvel: " + identificadorImovel);
                    return false;
                }
                
            } catch (Exception e) {
                logger.logTexto("Erro no arquivamento de imóvel: " + e.getMessage());
                return false;
            }
        }
        
        public boolean arquivarCliente(String identificadorCliente) {
            try {
                Cliente cliente = catalogoCliente.buscarCliente(identificadorCliente);
                if (cliente == null) {
                    logger.logTexto("Erro: Cliente não encontrado: " + identificadorCliente);
                    return false;
                }
                
                boolean sucesso = catalogoCliente.arquivarCliente(identificadorCliente);
                
                if (sucesso) {
                    logger.logTexto("Cliente arquivado com sucesso: " + identificadorCliente);
                    return true;
                } else {
                    logger.logTexto("Erro ao arquivar cliente: " + identificadorCliente);
                    return false;
                }
                
            } catch (Exception e) {
                logger.logTexto("Erro no arquivamento de cliente: " + e.getMessage());
                return false;
            }
        }
        
        public boolean editarCliente(String identificador, String nome, String telefone, String email, String endereco, EnumGenero genero) {
            try {
                Cliente cliente = catalogoCliente.buscarCliente(identificador);
                if (cliente == null) {
                    logger.logTexto("Erro: Cliente não encontrado: " + identificador);
                    return false;
                }
                
                if (nome != null && !nome.trim().isEmpty()) {
                    cliente.setNome(nome);
                }
                if (telefone != null) {
                    cliente.setTelefone(telefone);
                }
                if (email != null) {
                    cliente.setEmail(email);
                }
                if (endereco != null) {
                    cliente.setEndereco(endereco);
                }
                if (genero != null) {
                    cliente.setGenero(genero);
                }
                
                logger.logTexto("Cliente editado com sucesso: " + identificador);
                return true;
                
            } catch (Exception e) {
                logger.logTexto("Erro na edição de cliente: " + e.getMessage());
                return false;
            }
        }
        
        public boolean editarImovel(String identificador, String nome, EnumImovel tipo, boolean ocupado, String cliente) {
            try {
                imovel imovel = catalogoImovel.buscarImovel(identificador);
                if (imovel == null) {
                    logger.logTexto("Erro: Imóvel não encontrado: " + identificador);
                    return false;
                }
                
                if (nome != null && !nome.trim().isEmpty()) {
                    imovel.setNome(nome);
                }
                if (tipo != null) {
                    imovel.setTipoImovel(tipo);
                }
                imovel.setOcupado(ocupado);
                
                
                
                logger.logTexto("Imóvel editado com sucesso (RF_Ed7): " + identificador + " -> " + nome);
                return true;
                
            } catch (Exception e) {
                logger.logTexto("Erro na edição de imóvel: " + e.getMessage());
                return false;
            }
        }
        
        public boolean editarImovel(String identificador, String nome, EnumImovel tipoImovel) {
            return editarImovel(identificador, nome, tipoImovel, false, null);
        }
        
        public Cliente buscarClientePorNome(String nome) {
            return catalogoCliente.buscarCliente(nome);
        }
        
        public imovel buscarImovel(String nome) {
            return catalogoImovel.buscarImovel(nome);
        }
        
        public boolean editarSeguro(String identificadorSeguro, String nome, Double valor, String descricao, Boolean ativo) {
            try {
                Seguro seguro = catalogoSeguro.buscarSeguro(identificadorSeguro);
                if (seguro == null) {
                    logger.logTexto("Erro: Seguro não encontrado: " + identificadorSeguro);
                    return false;
                }
                
                logger.logTexto("Seguro encontrado para edição: " + seguro.getNome());
                
                boolean alterado = false;
                
                if (nome != null && !nome.trim().isEmpty()) {
                    seguro.setNome(nome);
                    alterado = true;
                }
                
                if (valor != null && valor > 0) {
                    seguro.setValor(valor);
                    alterado = true;
                }
                
                if (descricao != null && descricao.length() <= 2500) { 
                    seguro.setDescricao(descricao);
                    alterado = true;
                }
                
                if (ativo != null) {
                    seguro.setAtivo(ativo);
                    alterado = true;
                }
                
                if (!alterado) {
                    logger.logTexto("Nenhuma alteração válida fornecida para o seguro: " + identificadorSeguro);
                    return false;
                }
                
                logger.logTexto("Seguro editado com sucesso: " + identificadorSeguro);
                
                notificarClientesSeguro(seguro, "Seu seguro foi atualizado: " + seguro.getNome());
                
                logger.logTexto("Edição de seguro registrada: " + identificadorSeguro + " - " + seguro.getNome());
                
                return true;
                
            } catch (Exception e) {
                logger.logTexto("Erro na edição de seguro: " + e.getMessage());
                return false;
            }
        }
        
 
        
        public boolean editarCobrancaAluguel(String identificadorCobranca, Double novoValor, LocalDateTime novoVencimento) {
            try {
                
                CobrancaAluguel cobranca = catalogoCliente.buscarCobrancaAluguel(identificadorCobranca);
                if (cobranca == null) {
                    logger.logTexto("Erro: Cobrança de aluguel não encontrada: " + identificadorCobranca);
                    return false;
                }
                
                if (cobranca.isPago()) {
                    logger.logTexto("Erro: Não é possível editar cobrança já paga: " + identificadorCobranca);
                    return false;
                }
                
                logger.logTexto("Cobrança de aluguel encontrada para edição: " + identificadorCobranca);
                
                boolean alterado = false;
                
                if (novoValor != null && novoValor > 0) {
                    cobranca.setValorAluguel(novoValor);
                    alterado = true;
                    logger.logTexto("Valor da cobrança alterado para: R$ " + novoValor);
                }
                
                if (novoVencimento != null) {
                    cobranca.setDiaPagamento(novoVencimento);
                    alterado = true;
                    logger.logTexto("Vencimento alterado para: " + novoVencimento.toLocalDate());
                }
                
                if (!alterado) {
                    logger.logTexto("Nenhuma alteração válida fornecida para cobrança: " + identificadorCobranca);
                    return false;
                }
                
                Cliente cliente = cobranca.getCliente();
                if (cliente != null) {
                    String mensagem = String.format("Sua cobrança de aluguel foi atualizada - Valor: R$ %.2f, Vencimento: %s", 
                                                   cobranca.getValorAluguel(), cobranca.getDiaPagamento().toLocalDate());
                    cliente.notificarCliente(mensagem);
                }
                
                logger.logTexto("Cobrança de aluguel editada com sucesso: " + identificadorCobranca);
                return true;
                
            } catch (Exception e) {
                logger.logTexto("Erro na edição de cobrança de aluguel: " + e.getMessage());
                return false;
            }
        }
        
        public boolean editarCobrancaMulta(String identificadorCobranca, Double novoValor, Integer novosDiasAtraso, Double novosJuros) {
            try {
                
                CobrancaMulta cobrancaMulta = catalogoCliente.buscarCobrancaMulta(identificadorCobranca);
                if (cobrancaMulta == null) {
                    logger.logTexto("Erro: Cobrança de multa não encontrada: " + identificadorCobranca);
                    return false;
                }
                
                if (cobrancaMulta.isPago()) {
                    logger.logTexto("Erro: Não é possível editar cobrança de multa já paga: " + identificadorCobranca);
                    return false;
                }
                
                logger.logTexto("Cobrança de multa encontrada para edição: " + identificadorCobranca);
                
                boolean alterado = false;
                
                if (novoValor != null && novoValor >= 0) {
                    cobrancaMulta.setValorAdicional(novoValor);
                    alterado = true;
                }
                
                if (novosDiasAtraso != null && novosDiasAtraso >= 0) {
                    cobrancaMulta.setDiasAtraso(novosDiasAtraso);
                    alterado = true;
                }
                
                if (novosJuros != null && novosJuros >= 0) {
                    cobrancaMulta.setJuros(novosJuros);
                    alterado = true;
                }
                
                if (!alterado) {
                    logger.logTexto("Nenhuma alteração válida fornecida para multa: " + identificadorCobranca);
                    return false;
                }
                
                double valorFinal = cobrancaMulta.getValorAdicional() * Math.pow(1 + cobrancaMulta.getJuros(), cobrancaMulta.getDiasAtraso());
                cobrancaMulta.setValorFinal(valorFinal);
                
                Cliente cliente = cobrancaMulta.getCliente();
                if (cliente != null) {
                    String mensagem = String.format("Sua cobrança de multa foi atualizada - Valor: R$ %.2f, Dias de atraso: %d", 
                                                   valorFinal, cobrancaMulta.getDiasAtraso());
                    cliente.notificarCliente(mensagem);
                }
                
                logger.logTexto("Cobrança de multa editada com sucesso: " + identificadorCobranca);
                return true;
                
            } catch (Exception e) {
                logger.logTexto("Erro na edição de cobrança de multa: " + e.getMessage());
                return false;
            }
        }
        
        public boolean processarPagamentoAluguel(String identificadorCobranca) {
            try {
                CobrancaAluguel cobranca = catalogoCliente.buscarCobrancaAluguel(identificadorCobranca);
                if (cobranca == null) {
                    logger.logTexto("Erro: Cobrança de aluguel não encontrada: " + identificadorCobranca);
                    return false;
                }
                
                if (cobranca.isPago()) {
                    logger.logTexto("Erro: Cobrança já foi paga: " + identificadorCobranca);
                    return false;
                }
                
                cobranca.pagar();
                
                Cliente cliente = cobranca.getCliente();
                if (cliente != null) {
                    String mensagem = String.format("Pagamento de aluguel confirmado - Valor: R$ %.2f - Data: %s", 
                                                   cobranca.getValorAluguel(), 
                                                   cobranca.getDiaPagamento().toString());
                    cliente.notificarCliente(mensagem);
                }
                
                logger.logTexto("Pagamento de aluguel processado com sucesso (RF_Co2): " + identificadorCobranca);
                return true;
                
            } catch (Exception e) {
                logger.logTexto("Erro ao processar pagamento de aluguel: " + e.getMessage());
                return false;
            }
        }
        
        public boolean processarPagamentoMulta(String identificadorCobranca) {
            try {
                CobrancaMulta cobranca = catalogoCliente.buscarCobrancaMulta(identificadorCobranca);
                if (cobranca == null) {
                    logger.logTexto("Erro: Cobrança de multa não encontrada: " + identificadorCobranca);
                    return false;
                }
                
                if (cobranca.isPago()) {
                    logger.logTexto("Erro: Multa já foi paga: " + identificadorCobranca);
                    return false;
                }
                
                cobranca.pagar();
                
                Cliente cliente = cobranca.getCliente();
                if (cliente != null) {
                    String mensagem = String.format("Pagamento de multa confirmado - Valor: R$ %.2f - Dias de atraso: %d", 
                                                   cobranca.getValorFinal(), 
                                                   cobranca.getDiasAtraso());
                    cliente.notificarCliente(mensagem);
                }
                
                logger.logTexto("Pagamento de multa processado com sucesso (RF_Co4): " + identificadorCobranca);
                return true;
                
            } catch (Exception e) {
                logger.logTexto("Erro ao processar pagamento de multa: " + e.getMessage());
                return false;
            }
        }
        
        public List<CobrancaAluguel> listarCobrancasAluguelPendentes() {
            try {
                return catalogoCliente.listarCobrancasAluguelPendentes();
            } catch (Exception e) {
                logger.logTexto("Erro ao listar cobranças de aluguel pendentes: " + e.getMessage());
                return new ArrayList<>();
            }
        }
        
        public List<CobrancaMulta> listarCobrancasMultaPendentes() {
            try {
                return catalogoCliente.listarCobrancasMultaPendentes();
            } catch (Exception e) {
                logger.logTexto("Erro ao listar cobranças de multa pendentes: " + e.getMessage());
                return new ArrayList<>();
            }
        }
        
        private void notificarClientesSeguro(Seguro seguro, String mensagem) {
            try {
                List<ContratoAluguel> contratosAfetados = catalogoContratoAluguel.buscarContratosPorSeguro(seguro.getId());
                
                for (ContratoAluguel contrato : contratosAfetados) {
                    if (contrato.getLocatario() != null) {
                        contrato.getLocatario().notificarCliente(mensagem);
                    }
                    
                    if (contrato.getImovel() != null && contrato.getImovel().getProprietario() != null) {
                        contrato.getImovel().getProprietario().notificarCliente(mensagem);
                    }
                }
                
                logger.logTexto("Clientes notificados sobre alteração no seguro: " + contratosAfetados.size() + " contratos afetados");
                
            } catch (Exception e) {
                logger.logTexto("Erro ao notificar clientes do seguro: " + e.getMessage());
            }
        }
        
        public boolean editarAgendamentoVisita(String identificadorAgendamento, LocalDateTime novaDataHora, String novoFuncionario, String novoCliente, String novoImovel) {
            try {
                AgendamentoVisita agendamento = catalogoAgendamentoVisita.buscarAgendamento(identificadorAgendamento);
                if (agendamento == null) {
                    logger.logTexto("Erro: Agendamento de visita não encontrado: " + identificadorAgendamento);
                    return false;
                }
                
                logger.logTexto("Agendamento de visita encontrado para edição: " + identificadorAgendamento);
                
                boolean alterado = false;
                String mensagemAlteracao = "Agendamento de visita atualizado: ";
                
                
                if (novaDataHora != null) {
                    if (!verificarConflitosVisita(novaDataHora, agendamento.getFuncionario(), agendamento)) {
                        logger.logTexto("Erro: Conflito de horário detectado para nova data: " + novaDataHora);
                        return false;
                    }
                    
                    agendamento.setDataHora(novaDataHora);
                    mensagemAlteracao += "Nova data: " + novaDataHora.toLocalDate() + " " + novaDataHora.toLocalTime() + "; ";
                    alterado = true;
                }
                
                if (novoFuncionario != null && !novoFuncionario.trim().isEmpty()) {
                    Funcionario funcionario = catalogoFuncionario.buscarFuncionario(novoFuncionario);
                    if (funcionario != null) {
                        agendamento.setFuncionario(funcionario);
                        mensagemAlteracao += "Novo funcionário: " + funcionario.getNome() + "; ";
                        alterado = true;
                    }
                }
                
                if (novoCliente != null && !novoCliente.trim().isEmpty()) {
                    Cliente cliente = catalogoCliente.buscarCliente(novoCliente);
                    if (cliente != null) {
                        agendamento.setCliente(cliente);
                        mensagemAlteracao += "Novo cliente: " + cliente.getNome() + "; ";
                        alterado = true;
                    }
                }
                
                if (novoImovel != null && !novoImovel.trim().isEmpty()) {
                    imovel imovel = catalogoImovel.buscarImovel(novoImovel);
                    if (imovel != null) {
                        agendamento.setImovel(imovel);
                        mensagemAlteracao += "Novo imóvel: " + imovel.getNome() + "; ";
                        alterado = true;
                    }
                }
                
                if (!alterado) {
                    logger.logTexto("Nenhuma alteração válida fornecida para agendamento: " + identificadorAgendamento);
                    return false;
                }
                
                logger.logTexto("Agendamento de visita editado com sucesso: " + identificadorAgendamento);
                
                if (agendamento.getFuncionario() != null) {
                    agendamento.getFuncionario().notificarFuncionario(mensagemAlteracao);
                }
                if (agendamento.getCliente() != null) {
                    agendamento.getCliente().notificarCliente(mensagemAlteracao);
                }
                
                logger.logTexto("Edição de agendamento de visita registrada: " + identificadorAgendamento + " - " + mensagemAlteracao);
                
                return true;
                
            } catch (Exception e) {
                logger.logTexto("Erro na edição de agendamento de visita: " + e.getMessage());
                return false;
            }
        }
        
        public boolean editarAgendamentoVistoria(String identificadorAgendamento, LocalDateTime novaDataHora, String novoFuncionario, String novoImovel) {
            try {
                AgendamentoVistoria agendamento = catalogoAgendamentoVistoria.buscarAgendamento(identificadorAgendamento);
                if (agendamento == null) {
                    logger.logTexto("Erro: Agendamento de vistoria não encontrado: " + identificadorAgendamento);
                    return false;
                }
                
                logger.logTexto("Agendamento de vistoria encontrado para edição: " + identificadorAgendamento);
                
                boolean alterado = false;
                String mensagemAlteracao = "Agendamento de vistoria atualizado: ";
                
                if (novaDataHora != null) {
                    if (!verificarConflitosVistoria(novaDataHora, agendamento.getFuncionario(), agendamento)) {
                        logger.logTexto("Erro: Conflito de horário detectado para nova data: " + novaDataHora);
                        return false;
                    }
                    
                    agendamento.setDataHora(novaDataHora);
                    mensagemAlteracao += "Nova data: " + novaDataHora.toLocalDate() + " " + novaDataHora.toLocalTime() + "; ";
                    alterado = true;
                }
                
                if (novoFuncionario != null && !novoFuncionario.trim().isEmpty()) {
                    Funcionario funcionario = catalogoFuncionario.buscarFuncionario(novoFuncionario);
                    if (funcionario != null) {
                        agendamento.setFuncionario(funcionario);
                        mensagemAlteracao += "Novo funcionário: " + funcionario.getNome() + "; ";
                        alterado = true;
                    }
                }
                
                if (novoImovel != null && !novoImovel.trim().isEmpty()) {
                    imovel imovel = catalogoImovel.buscarImovel(novoImovel);
                    if (imovel != null) {
                        agendamento.setImovel(imovel);
                        mensagemAlteracao += "Novo imóvel: " + imovel.getNome() + "; ";
                        alterado = true;
                    }
                }
                
                if (!alterado) {
                    logger.logTexto("Nenhuma alteração válida fornecida para vistoria: " + identificadorAgendamento);
                    return false;
                }
                
                logger.logTexto("Agendamento de vistoria editado com sucesso: " + identificadorAgendamento);
                
                if (agendamento.getFuncionario() != null) {
                    agendamento.getFuncionario().notificarFuncionario(mensagemAlteracao);
                }
                
                if (agendamento.getImovel() != null && agendamento.getImovel().getProprietario() != null) {
                    agendamento.getImovel().getProprietario().notificarCliente(mensagemAlteracao);
                }
                
                logger.logTexto("Edição de agendamento de vistoria registrada: " + identificadorAgendamento + " - " + mensagemAlteracao);
                
                return true;
                
            } catch (Exception e) {
                logger.logTexto("Erro na edição de agendamento de vistoria: " + e.getMessage());
                return false;
            }
        }
        
        private boolean verificarConflitosVisita(LocalDateTime novaDataHora, Funcionario funcionario, AgendamentoVisita agendamentoAtual) {
            return catalogoAgendamentoVisita.verificarDisponibilidade(novaDataHora, funcionario, agendamentoAtual.getId());
        }
        
        private boolean verificarConflitosVistoria(LocalDateTime novaDataHora, Funcionario funcionario, AgendamentoVistoria agendamentoAtual) {
            return catalogoAgendamentoVistoria.verificarDisponibilidade(novaDataHora, funcionario, agendamentoAtual.getId());
        }

}