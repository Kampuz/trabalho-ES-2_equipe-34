package Controle;

import Factory.FactoryFuncionario;
import Catalogos.CatalogoFuncionario;
import Conceitos.EnumCargo;
import Conceitos.EnumGenero;
import Conceitos.Funcionario;
import Persistencia.logger;
import java.time.LocalDateTime;
import java.awt.Graphics2D;

public class ControladorGerente {
    
    private static ControladorGerente instance;

	private ControladorCentral controladorCentral;

	private FactoryFuncionario factoryFuncionario;

	private CatalogoFuncionario catalogoFuncionario;
        
        private logger logger;
        
        private ControladorGerente() {
            this.factoryFuncionario = new FactoryFuncionario();
            this.catalogoFuncionario = CatalogoFuncionario.getInstance();
            this.logger = new logger();
        }
        
        public static synchronized ControladorGerente getInstance() {
            if (instance == null) {
                instance = new ControladorGerente();
            }
            return instance;
        }

        public boolean registrarFuncionario(String nome, LocalDateTime data_nascimento, String CPF, String telefone, String email, String endereco, EnumGenero genero, Graphics2D imagem, EnumCargo cargo, double salario) {
            try {
                Funcionario funcionario = factoryFuncionario.criarFuncionario(nome, data_nascimento, CPF, telefone, email, endereco, genero, imagem, cargo, salario);
                
                boolean adicionado = catalogoFuncionario.adicionarFuncionario(funcionario);
                
                if (!adicionado) {
                    return false;
                }
                
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        public Funcionario buscarFuncionarioPorNome(String nome) {
            return catalogoFuncionario.buscarFuncionario(nome);
        }
        
        public boolean editarFuncionarioProprio(String emailFuncionario, String novaSenha, String novoTelefone, String novoEmail, String novoEndereco) {
            try {
                
                Funcionario funcionario = catalogoFuncionario.buscarFuncionarioPorEmail(emailFuncionario);
                if (funcionario == null) {
                    logger.logTexto("Erro: Funcionário não encontrado: " + emailFuncionario);
                    return false;
                }
                
                logger.logTexto("Funcionário editando próprios dados: " + funcionario.getNome());
                
                boolean alterado = false;
                String mensagemAlteracao = "Dados atualizados: ";
                
                if (novaSenha != null && !novaSenha.trim().isEmpty()) {
                    if (!novaSenha.equals(funcionario.getSenha())) {
                        funcionario.setSenha(novaSenha);
                        mensagemAlteracao += "Senha; ";
                        alterado = true;
                    } else {
                        logger.logTexto("Erro RF_Ed1: Nova senha é idêntica à atual");
                        return false;
                    }
                }
                
                if (novoTelefone != null && !novoTelefone.trim().isEmpty()) {
                    funcionario.setTelefone(novoTelefone);
                    mensagemAlteracao += "Telefone; ";
                    alterado = true;
                }
                
                if (novoEmail != null && !novoEmail.trim().isEmpty()) {
                    funcionario.setEmail(novoEmail);
                    mensagemAlteracao += "E-mail; ";
                    alterado = true;
                }
                
                if (novoEndereco != null && !novoEndereco.trim().isEmpty()) {
                    funcionario.setEndereco(novoEndereco);
                    mensagemAlteracao += "Endereço; ";
                    alterado = true;
                }
                
                if (!alterado) {
                    logger.logTexto("Nenhuma alteração válida fornecida");
                    return false;
                }
                
                funcionario.notificarFuncionario(mensagemAlteracao);
                
                logger.logTexto("Funcionário editou próprios dados com sucesso: " + funcionario.getNome() + " - " + mensagemAlteracao);
                
                return true;
                
            } catch (Exception e) {
                logger.logTexto("Erro na edição própria de funcionário: " + e.getMessage());
                return false;
            }
        }
        
        public boolean editarFuncionarioPorGerente(String identificadorFuncionario, String nome, String telefone, String email, String endereco, Graphics2D foto, EnumGenero genero, EnumCargo cargo, Double salario) {
            try {
                Funcionario funcionario = catalogoFuncionario.buscarFuncionario(identificadorFuncionario);
                if (funcionario == null) {
                    logger.logTexto("Erro: Funcionário não encontrado: " + identificadorFuncionario);
                    return false;
                }
                
                if (funcionario.getCargo() == EnumCargo.GERENTE) {
                    logger.logTexto("Erro RF_Ed2: Gerente não pode editar outro gerente");
                    return false;
                }
                
                logger.logTexto("Gerente editando dados de funcionário: " + funcionario.getNome());
                
                boolean alterado = false;
                String mensagemAlteracao = "Seus dados foram atualizados pelo gerente: ";
                
                if (nome != null && !nome.trim().isEmpty()) {
                    funcionario.setNome(nome);
                    mensagemAlteracao += "Nome; ";
                    alterado = true;
                }
                
                if (telefone != null && !telefone.trim().isEmpty()) {
                    funcionario.setTelefone(telefone);
                    mensagemAlteracao += "Telefone; ";
                    alterado = true;
                }
                
                if (email != null && !email.trim().isEmpty()) {
                    funcionario.setEmail(email);
                    mensagemAlteracao += "E-mail; ";
                    alterado = true;
                }
                
                if (endereco != null && !endereco.trim().isEmpty()) {
                    funcionario.setEndereco(endereco);
                    mensagemAlteracao += "Endereço; ";
                    alterado = true;
                }
                
                if (foto != null) {
                    funcionario.setImagem(foto);
                    mensagemAlteracao += "Foto; ";
                    alterado = true;
                }
                
                if (genero != null) {
                    funcionario.setGenero(genero);
                    mensagemAlteracao += "Gênero; ";
                    alterado = true;
                }
                
                if (cargo != null) {
                    funcionario.setCargo(cargo);
                    mensagemAlteracao += "Cargo; ";
                    alterado = true;
                }
                
                if (salario != null && salario > 0) {
                    funcionario.setSalario(salario);
                    mensagemAlteracao += "Salário; ";
                    alterado = true;
                }
                
                if (!alterado) {
                    logger.logTexto("Nenhuma alteração válida fornecida para funcionário");
                    return false;
                }
                
                funcionario.notificarFuncionario(mensagemAlteracao);
                
                logger.logTexto("Gerente editou funcionário com sucesso: " + funcionario.getNome() + " - " + mensagemAlteracao);
                
                return true;
                
            } catch (Exception e) {
                logger.logTexto("Erro na edição de funcionário por gerente: " + e.getMessage());
                return false;
            }
        }
        
        public boolean editarFuncionarioGerenteInicial(String identificadorFuncionario, String nome, String telefone, String email, String endereco, Graphics2D foto, EnumGenero genero, EnumCargo cargo, Double salario, String novaSenha) {
            try {
                Funcionario funcionario = catalogoFuncionario.buscarFuncionario(identificadorFuncionario);
                if (funcionario == null) {
                    logger.logTexto("Erro: Funcionário não encontrado: " + identificadorFuncionario);
                    return false;
                }
                
                logger.logTexto("Gerente inicial editando funcionário: " + funcionario.getNome());
                
                boolean alterado = false;
                String mensagemAlteracao = "Seus dados foram atualizados pelo gerente inicial: ";
                
                
                if (nome != null && !nome.trim().isEmpty()) {
                    funcionario.setNome(nome);
                    mensagemAlteracao += "Nome; ";
                    alterado = true;
                }
                
                if (novaSenha != null && !novaSenha.trim().isEmpty()) {
                    funcionario.setSenha(novaSenha);
                    mensagemAlteracao += "Senha; ";
                    alterado = true;
                }
                
                if (telefone != null && !telefone.trim().isEmpty()) {
                    funcionario.setTelefone(telefone);
                    mensagemAlteracao += "Telefone; ";
                    alterado = true;
                }
                
                if (email != null && !email.trim().isEmpty()) {
                    funcionario.setEmail(email);
                    mensagemAlteracao += "E-mail; ";
                    alterado = true;
                }
                
                if (endereco != null && !endereco.trim().isEmpty()) {
                    funcionario.setEndereco(endereco);
                    mensagemAlteracao += "Endereço; ";
                    alterado = true;
                }
                
                if (foto != null) {
                    funcionario.setImagem(foto);
                    mensagemAlteracao += "Foto; ";
                    alterado = true;
                }
                
                if (genero != null) {
                    funcionario.setGenero(genero);
                    mensagemAlteracao += "Gênero; ";
                    alterado = true;
                }
                
                if (cargo != null) {
                    funcionario.setCargo(cargo);
                    mensagemAlteracao += "Cargo; ";
                    alterado = true;
                }
                
                if (salario != null && salario > 0) {
                    funcionario.setSalario(salario);
                    mensagemAlteracao += "Salário; ";
                    alterado = true;
                }
                
                if (!alterado) {
                    logger.logTexto("Nenhuma alteração válida fornecida");
                    return false;
                }
                
                funcionario.notificarFuncionario(mensagemAlteracao);
                
                logger.logTexto("Gerente inicial editou funcionário com sucesso: " + funcionario.getNome() + " - " + mensagemAlteracao);
                
                return true;
                
            } catch (Exception e) {
                logger.logTexto("Erro na edição de funcionário por gerente inicial: " + e.getMessage());
                return false;
            }
        }
        
        public boolean registrarFuncionarioComSenha(String nome, String senha, LocalDateTime data_nascimento, String CPF, String telefone, String email, String endereco, EnumGenero genero, Graphics2D imagem, EnumCargo cargo, double salario) {
            try {
                Funcionario funcionario = factoryFuncionario.criarFuncionarioComSenha(nome, senha, data_nascimento, CPF, telefone, email, endereco, genero, imagem, cargo, salario);
                
                boolean adicionado = catalogoFuncionario.adicionarFuncionario(funcionario);
                
                if (!adicionado) {
                    logger.logTexto("Erro: Funcionário já existe ou erro na adição");
                    return false;
                }
                
                logger.logTexto("Funcionário registrado com senha: " + nome);
                return true;
                
            } catch (Exception e) {
                logger.logTexto("Erro no registro de funcionário com senha: " + e.getMessage());
                return false;
            }
        }
        
        public CatalogoFuncionario getCatalogoFuncionario() {
            return CatalogoFuncionario.getInstance();
        }
        
        public boolean arquivarFuncionario(String identificador) {
            try {
                boolean sucesso = catalogoFuncionario.arquivarFuncionario(identificador);
                if (sucesso) {
                    logger.logTexto("Funcionário arquivado com sucesso (RF_Ed3): " + identificador);
                } else {
                    logger.logTexto("Erro ao arquivar funcionário: " + identificador);
                }
                return sucesso;
            } catch (Exception e) {
                logger.logTexto("Erro ao arquivar funcionário: " + e.getMessage());
                return false;
            }
        }

}
