package Conceitos;

public enum EnumImovel {
    CASA,
    APARTAMENTO,
    CHACARA
}