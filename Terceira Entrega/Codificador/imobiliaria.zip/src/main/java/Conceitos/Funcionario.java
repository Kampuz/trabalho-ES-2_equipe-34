package Conceitos;

import java.util.Collection;
import java.time.LocalDateTime;
import java.awt.Graphics2D;
import java.util.Random;
import Catalogos.CatalogoFuncionario;
import Factory.FactoryFuncionario;

public class Funcionario extends Cliente {

	private EnumCargo cargo;

	private double salario;

	private String senha;

	private Graphics2D imagem;

	private CatalogoFuncionario catalogoFuncionario;

	private FactoryFuncionario factoryFuncionario;

	private Collection<AgendamentoVisita> agendamentoVisita;

	private Collection<AgendamentoVistoria> agendamentoVistoria;

	private Collection<ContratoAluguel> contratoAluguel;
        
        public Funcionario(String nome, EnumCargo cargo, double salario) {
            super(nome);
            this.cargo = cargo;
            this.salario = salario;
            this.senha = gerarSenhaAleatoria();
        }
        
        public Funcionario(String nome, LocalDateTime data_nascimento, String CPF, String telefone, String email, Endereco endereco, EnumGenero genero, Graphics2D imagem, EnumCargo cargo, double salario) {
            super(nome, data_nascimento, CPF, telefone, email, endereco, genero, imagem);
            this.cargo = cargo;
            this.salario = salario;
            this.senha = gerarSenhaAleatoria();
            this.imagem = imagem;
        }
        
        private String gerarSenhaAleatoria() {
            String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            Random random = new Random();
            StringBuilder senha = new StringBuilder();
            for (int i = 0; i < 8; i++) {
                senha.append(chars.charAt(random.nextInt(chars.length())));
            }
            return senha.toString();
        }
        
        public double getSalario() {
            return salario;
        }
        
        public EnumCargo getCargo() {
            return cargo;
        }
        
        public String getSenha() {
            return this.senha;
        }
        
        public void setSenha(String senha) {
            this.senha = senha;
        }
        
        public void setCargo(EnumCargo cargo) {
            this.cargo = cargo;
        }
        
        public void setSalario(double salario) {
            this.salario = salario;
        }
        
        public void notificarFuncionario(String texto) {
            System.out.println("[Notificação para funcionário " + getNome() + "] " + texto);
        }

}
