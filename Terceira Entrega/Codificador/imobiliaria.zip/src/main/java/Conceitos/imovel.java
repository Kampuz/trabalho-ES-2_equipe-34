package Conceitos;

import Factory.FactoryImovel;
import Catalogos.CatalogoImovel;
import java.awt.Graphics2D;

public class imovel {

	private String nome;

	private Cliente proprietario;

	private EnumImovel tipo_imovel;
        
        private boolean ocupado;

	private LaudoTecnico laudo_tecnico;

	private LaudoVistoria laudo_vistoria;
        
        private Graphics2D imagem;

	private FactoryImovel factoryImovel;

	private CatalogoImovel catalogoImovel;

	private LaudoTecnico laudoTecnico;

	private LaudoVistoria laudoVistoria;

	private Cliente cliente;

	private ContratoAluguel contratoAluguel;
        
        public imovel(String nome, Cliente proprietario, String tipo_imovel) {
            this.nome = nome;
            this.proprietario = proprietario;
            this.tipo_imovel = EnumImovel.valueOf(tipo_imovel);
            this.ocupado = false; // Por padrão, não ocupado
        }
        
        public imovel(String nome, Cliente proprietario, EnumImovel tipo_imovel, LaudoTecnico laudo_tecnico, LaudoVistoria laudo_vistoria, Graphics2D imagem) {
            this.nome = nome;
            this.proprietario = proprietario;
            this.tipo_imovel = tipo_imovel;
            this.laudo_tecnico = laudo_tecnico;
            this.laudo_vistoria = laudo_vistoria;
            this.imagem = imagem;
            this.ocupado = false; // Por padrão, não ocupado
        }
        
        public void setLaudoTecnico(LaudoTecnico laudo_tecnico) {
            this.laudo_tecnico = laudo_tecnico;
        }
        
        public void setLaudoVistoria(LaudoVistoria laudo_vistoria) {
            this.laudo_vistoria = laudo_vistoria;
        }

        public String getNome() {
            return nome;
        }
        
        public Cliente getProprietario() {
            return proprietario;
        }
        
        public EnumImovel getTipoImovel() {
            return tipo_imovel;
        }
        
        public void setNome(String nome) {
            this.nome = nome;
        }
        
        public void setTipoImovel(EnumImovel tipo_imovel) {
            this.tipo_imovel = tipo_imovel;
        }
        
        public boolean isOcupado() {
            return ocupado;
        }
        
        public void setOcupado(boolean ocupado) {
            this.ocupado = ocupado;
        }
        
        public double getValorBase() {
            if (laudo_tecnico != null) {
                return laudo_tecnico.getValorImovel();
            }
            return 1000.0; // Valor placeholder se não houver laudo
        }
        
        public double getValor() {
            return getValorBase();
        }
        
        public double calcularValorTotalSeguros() {
            
            return 50.0; // Valor placeholder para seguros
        }

}
