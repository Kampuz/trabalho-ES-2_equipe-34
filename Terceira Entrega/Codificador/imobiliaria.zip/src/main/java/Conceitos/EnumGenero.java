package Conceitos;

public enum EnumGenero {
    FEMININO,
    MASCULINO,
    OUTRO
}