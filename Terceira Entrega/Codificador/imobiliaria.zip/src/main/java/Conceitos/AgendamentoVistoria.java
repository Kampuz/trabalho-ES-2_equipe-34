package Conceitos;

import java.time.LocalDateTime;
import java.util.UUID;

public class AgendamentoVistoria {

    private UUID id;
    private LocalDateTime data_hora;
    private Cliente cliente;
    private Funcionario funcionario;
    private imovel imovel;

    public AgendamentoVistoria(LocalDateTime data_hora, Funcionario funcionario, imovel imovel) {
        this.id = UUID.randomUUID();
        this.data_hora = data_hora;
        this.funcionario = funcionario;
        this.imovel = imovel;
    }
    
    public UUID getId() {
        return id;
    }
    
    public LocalDateTime getDataHora() {
        return data_hora;
    }
    
    public Cliente getCliente() {
        return cliente;
    }
    
    public Funcionario getFuncionario() {
        return funcionario;
    }
    
    public imovel getImovel() {
        return imovel;
    }
    
    public void setDataHora(LocalDateTime data_hora) {
        this.data_hora = data_hora;
    }
    
    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }
    
    public void setFuncionario(Funcionario funcionario) {
        this.funcionario = funcionario;
    }
    
    public void setImovel(imovel imovel) {
        this.imovel = imovel;
    }
    
   
    public LocalDateTime getDataVistoria() {
        return data_hora;
    }
    
    public Funcionario getFuncionarioResponsavel() {
        return funcionario;
    }
    
  
    public void notificarEnvolvidos(String mensagem) {
        if (cliente != null) {
            cliente.notificarCliente(mensagem + " - Imóvel: " + (imovel != null ? imovel.getNome() : "N/A"));
        }
        if (funcionario != null) {
            System.out.println("[Notificação para funcionário " + funcionario.getNome() + "] " + mensagem);
        }
    }

}
