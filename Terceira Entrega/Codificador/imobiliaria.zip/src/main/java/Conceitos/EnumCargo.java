package Conceitos;

public enum EnumCargo {
    FUNCIONARIO,
    GERENTE
}