package Conceitos;

public class Endereco {
    private String rua;
    private String cep;
    private String numeroCase;
    private String complemento;
    
    public Endereco(String rua, String cep, String numeroCase, String complemento) {
        this.rua = rua;
        this.cep = cep;
        this.numeroCase = numeroCase;
        this.complemento = complemento;
    }
    
    public String getRua() {
        return rua;
    }
    
    public String getCep() {
        return cep;
    }
    
    public String getNumeroCase() {
        return numeroCase;
    }
    
    public String getComplemento() {
        return complemento;
    }
    
    public void setRua(String rua) {
        this.rua = rua;
    }
    
    public void setCep(String cep) {
        this.cep = cep;
    }
    
    public void setNumeroCase(String numeroCase) {
        this.numeroCase = numeroCase;
    }
    
    public void setComplemento(String complemento) {
        this.complemento = complemento;
    }
    
    @Override
    public String toString() {
        return rua + ", " + numeroCase + 
               (complemento != null && !complemento.isEmpty() ? ", " + complemento : "") + 
               " - CEP: " + cep;
    }
}