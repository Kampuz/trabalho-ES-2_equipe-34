package Conceitos;

import java.util.UUID;

public class Seguro {
    private UUID id;
    private String nome;
    private double valor;
    private String descricao;
    private boolean ativacao;
    
    public Seguro(String nome, double valor, String descricao) {
        this.id = UUID.randomUUID();
        this.nome = nome;
        this.valor = valor;
        this.setDescricao(descricao); // Usa o setter para validar o tamanho
        this.ativacao = false; // Por padrão, seguro inativo
    }
    
    public Seguro(String nome, double valor, String descricao, boolean ativacao) {
        this.id = UUID.randomUUID();
        this.nome = nome;
        this.valor = valor;
        this.setDescricao(descricao); // Usa o setter para validar o tamanho
        this.ativacao = ativacao;
    }

    public String getId() {
        return id.toString();
    }

    public String getNome() {
        return nome;
    }

    public double getValor() {
        return valor;
    }

    public String getDescricao() {
        return descricao;
    }
    
    public boolean isAtivacao() {
        return ativacao;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public void setDescricao(String descricao) {
        if (descricao != null && descricao.length() > 2500) {
            throw new IllegalArgumentException("Descrição do seguro não pode exceder 2500 caracteres");
        }
        this.descricao = descricao;
    }
    
    public void setAtivacao(boolean ativacao) {
        this.ativacao = ativacao;
    }
    
    public void setAtivo(Boolean ativo) {
        if (ativo != null) {
            this.ativacao = ativo;
        }
    }
    
}
