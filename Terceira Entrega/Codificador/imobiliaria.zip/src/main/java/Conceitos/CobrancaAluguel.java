package Conceitos;

import java.time.LocalDateTime;
import java.util.UUID;

public class CobrancaAluguel {

    private UUID id;
    private float valor;
    private LocalDateTime dia_pagamento;
    private Cliente cliente;
    private boolean pago;

    public CobrancaAluguel(double valor, LocalDateTime dia_pagamento, boolean pago) {
        this.id = UUID.randomUUID();
        this.valor = (float) valor;
        this.dia_pagamento = dia_pagamento;
        this.pago = pago;
    }

    public CobrancaAluguel(float valor, LocalDateTime dia_pagamento, Cliente cliente) {
        this.id = UUID.randomUUID();
        this.valor = valor;
        this.dia_pagamento = dia_pagamento;
        this.cliente = cliente;
        this.pago = false;
    }

    
    public UUID getId() {
        return id;
    }
    
    public void pagar() {
        this.pago = true;
    }
    
    public boolean isPago() {
        return pago;
    }
    
    public double getValorAluguel() {
        return valor;
    }
    
    public LocalDateTime getDiaPagamento() {
        return dia_pagamento;
    }
    
    public Cliente getCliente() {
        return cliente;
    }
    
    public void setValorAluguel(double valor) {
        this.valor = (float) valor;
    }
    
    public void setDiaPagamento(LocalDateTime dia_pagamento) {
        this.dia_pagamento = dia_pagamento;
    }

}
