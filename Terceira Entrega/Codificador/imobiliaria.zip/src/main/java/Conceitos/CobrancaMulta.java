package Conceitos;

import java.time.LocalDateTime;
import java.util.UUID;

public class CobrancaMulta {

    private UUID id;
    private double valorAdicional;
    private int diasAtraso;
    private double juros;
    private double valorFinal;
    private Cliente cliente;
    private boolean pago;

    public CobrancaMulta(double valorAdicional, int diasAtraso, double juros, Cliente cliente) {
        this.id = UUID.randomUUID();
        this.valorAdicional = valorAdicional;
        this.diasAtraso = diasAtraso;
        this.juros = juros;
        this.cliente = cliente;
        this.pago = false;
        calcularValorFinal();
    }
    
    private void calcularValorFinal() {
        this.valorFinal = valorAdicional * Math.pow(1 + juros, diasAtraso);
    }
    
    public UUID getId() {
        return id;
    }
    
    public boolean isPago() {
        return pago;
    }
    
    public double getValorAdicional() {
        return valorAdicional;
    }
    
    public int getDiasAtraso() {
        return diasAtraso;
    }
    
    public double getJuros() {
        return juros;
    }
    
    public double getValorFinal() {
        return valorFinal;
    }
    
    public Cliente getCliente() {
        return cliente;
    }
    
    public void setValorAdicional(double valorAdicional) {
        this.valorAdicional = valorAdicional;
        calcularValorFinal();
    }
    
    public void setDiasAtraso(int diasAtraso) {
        this.diasAtraso = diasAtraso;
        calcularValorFinal();
    }
    
    public void setJuros(double juros) {
        this.juros = juros;
        calcularValorFinal();
    }
    
    public void setValorFinal(double valorFinal) {
        this.valorFinal = valorFinal;
    }
    
    public void pagar() {
        this.pago = true;
    }

}