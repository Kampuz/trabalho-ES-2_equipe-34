package Conceitos;

import java.util.ArrayList;
import java.util.Collection;
import java.util.UUID;
import java.time.LocalDateTime;
import java.awt.Graphics2D;
import Catalogos.CatalogoCliente;
import Factory.FactoryCliente;
import Factory.FactoryImovel;

public class Cliente {

	private String nome;

	private LocalDateTime data_nascimento;

	private String CPFouCNPJ;

	private String telefone;

	private String email;

	private Endereco endereco;

	private EnumGenero genero;

	private Graphics2D imagem;

	private ArrayList<cobrancas> cobrancas;

	private ArrayList<cobrancas> historico_cobrancas;

	private CatalogoCliente catalogoCliente;

	private FactoryImovel factoryImovel;

	private FactoryCliente factoryCliente;

	private imovel imovel;

	private Collection<AgendamentoVisita> agendamentoVisita;

	private Collection<ContratoAluguel> contratoAluguel;
        
        public Cliente(String nome) {
            this.nome = nome;
            this.cobrancas = new ArrayList<>();
            this.historico_cobrancas = new ArrayList<>();
        }
        
        public Cliente(String nome, LocalDateTime data_nascimento, String CPFouCNPJ, String telefone, String email, Endereco endereco, EnumGenero genero, Graphics2D imagem) {
            this.nome = nome;
            this.data_nascimento = data_nascimento;
            this.CPFouCNPJ = CPFouCNPJ;
            this.telefone = telefone;
            this.email = email;
            this.endereco = endereco;
            this.genero = genero;
            this.imagem = imagem;
            this.cobrancas = new ArrayList<>();
            this.historico_cobrancas = new ArrayList<>();
        }

	public void notificarCliente(String texto) {
            System.out.println("[Notificação para " + nome + "] " + texto);
	}

	public void criarCobrancaAluguel() {
	}

	public void criarCobrancaMulta() {
	}

	public void pagarCobranca(UUID id) {
	}
        
        public String getNome() {
            return nome;
        }
        
        public String getCPFouCNPJ() {
            return CPFouCNPJ;
        }
        
        public String getTelefone() {
            return telefone;
        }
        
        public String getEmail() {
            return email;
        }
        
        public String getEndereco() {
            return endereco != null ? endereco.toString() : "";
        }
        
        public EnumGenero getGenero() {
            return genero;
        }
        
        public void setNome(String nome) {
            this.nome = nome;
        }
        
        public void setTelefone(String telefone) {
            this.telefone = telefone;
        }
        
        public void setEmail(String email) {
            this.email = email;
        }
        
        public Endereco getEnderecoCompleto() {
            return endereco;
        }
        
        public void setEndereco(Endereco endereco) {
            this.endereco = endereco;
        }
        
        public void setEndereco(String endereco) {
            
            this.endereco = new Endereco(endereco, "", "", "");
        }
        
        public void setGenero(EnumGenero genero) {
            this.genero = genero;
        }
        
        public void setImagem(Graphics2D imagem) {
            this.imagem = imagem;
        }
        
  
        
        public void logTexto(String texto) {
            System.out.println("[Cliente " + nome + "] " + texto);
        }
        
        
        public java.util.List<CobrancaAluguel> getCobrancasAtrasadas() {
            
            return new java.util.ArrayList<>();
        }
        
        public boolean temContratoAluguelAtivo() {
            return contratoAluguel != null && !contratoAluguel.isEmpty();
        }
        
        public ContratoAluguel getContratoAluguelAtivo() {
            if (contratoAluguel != null && !contratoAluguel.isEmpty()) {
                return contratoAluguel.iterator().next(); // Primeiro contrato ativo
            }
            return null;
        }
        
        public boolean temCobrancaAluguelAtrasada() {
            return !getCobrancasAtrasadas().isEmpty();
        }
        
        public CobrancaAluguel getCobrancaAluguelAtrasada() {
            java.util.List<CobrancaAluguel> atrasadas = getCobrancasAtrasadas();
            return atrasadas.isEmpty() ? null : atrasadas.get(0);
        }
        
        public void criarCobrancaAluguel(double valor) {
            LocalDateTime dataVencimento = LocalDateTime.now().plusDays(30); // 30 dias para pagamento
            CobrancaAluguel novaCobranca = new CobrancaAluguel((float)valor, dataVencimento, this);
        }
        
        public void criarCobrancaMulta(double valor) {
            LocalDateTime dataVencimento = LocalDateTime.now().plusDays(7); // 7 dias para pagamento da multa
            CobrancaMulta novaMulta = new CobrancaMulta(valor, calcularDiasAtraso(getCobrancaAluguelAtrasada()), 0.01, this);
        }
        
        public int calcularDiasAtraso(CobrancaAluguel cobranca) {
            if (cobranca == null) return 0;
            LocalDateTime agora = LocalDateTime.now();
            LocalDateTime vencimento = cobranca.getDiaPagamento();
            return (int) java.time.temporal.ChronoUnit.DAYS.between(vencimento, agora);
        }
        
        
        public void verificarPagamentosAtrasados() {
            if (temCobrancaAluguelAtrasada()) {
                notificarCliente("Você possui pagamentos em atraso. Entre em contato conosco.");
            }
        }

}
