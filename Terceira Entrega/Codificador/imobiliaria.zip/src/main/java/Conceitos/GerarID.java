package Conceitos;

import java.util.UUID;

public class GerarID {

    public static String gerarID() {
        return UUID.randomUUID().toString();
    }

}