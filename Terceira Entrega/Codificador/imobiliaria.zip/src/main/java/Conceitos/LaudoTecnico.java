package Conceitos;

public class LaudoTecnico {

	private String nome_responsavel;
	private String endereco;
	private double valor;
	private double area_total;
	private double area_interna;
        
        public LaudoTecnico(String nome, String endereco, float valor_imovel, float area) {
                this.nome_responsavel = nome;
                this.endereco = endereco;
                this.valor = valor_imovel;
                this.area_total = area;
                this.area_interna = area;
	}
        
        public LaudoTecnico(String nome_responsavel, String endereco, double valor, double area_total, double area_interna) {
                this.nome_responsavel = nome_responsavel;
                this.endereco = endereco;
                this.valor = valor;
                this.area_total = area_total;
                this.area_interna = area_interna;
	}
        
        public String getNome() {
            return nome_responsavel;
        }
        
        public String getNomeResponsavel() {
            return nome_responsavel;
        }
        
        public double getValorImovel() {
            return valor;
        }
        
        public String getEndereco() {
            return endereco;
        }
        
        public double getAreaTotal() {
            return area_total;
        }
        
        public double getAreaInterna() {
            return area_interna;
        }
        
        
        public void setNomeResponsavel(String nome_responsavel) {
            this.nome_responsavel = nome_responsavel;
        }
        
        public void setEndereco(String endereco) {
            this.endereco = endereco;
        }
        
        public void setValor(double valor) {
            this.valor = valor;
        }
        
        public void setAreaTotal(double area_total) {
            this.area_total = area_total;
        }
        
        public void setAreaInterna(double area_interna) {
            this.area_interna = area_interna;
        }

}
