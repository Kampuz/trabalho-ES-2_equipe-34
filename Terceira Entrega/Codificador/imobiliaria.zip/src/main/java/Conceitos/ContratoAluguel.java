package Conceitos;

import java.util.UUID;

public class ContratoAluguel {

    private UUID id;
    private double caucao;
    private double desconto;
    private double comissao;
    private Cliente locatario;
    private Funcionario funcionario;
    private imovel imovel;

    public ContratoAluguel(double caucao, double desconto, double comissao, Cliente locatario, Funcionario funcionario, imovel imovel) {
        this.id = UUID.randomUUID();
        this.caucao = caucao;
        this.desconto = desconto;
        this.comissao = comissao;
        this.locatario = locatario;
        this.funcionario = funcionario;
        this.imovel = imovel;
    }
    
    public UUID getId() {
        return id;
    }
    
    public double getCaucao() {
        return caucao;
    }
    
    public double getDesconto() {
        return desconto;
    }
    
    public double getComissao() {
        return comissao;
    }
    
    public Cliente getLocatario() {
        return locatario;
    }
    
    public Funcionario getFuncionario() {
        return funcionario;
    }
    
    public imovel getImovel() {
        return imovel;
    }
    
    public double calcularValorSeguros() {
        
        return imovel.calcularValorTotalSeguros();
    }
    
    public double getComissaoImobiliaria() {
        return comissao;
    }
    
    public double getValorTotalSeguros() {
        return calcularValorSeguros();
    }

}