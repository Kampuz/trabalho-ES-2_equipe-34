package Factory;

import Conceitos.ContratoAluguel;
import Conceitos.Cliente;
import Conceitos.Funcionario;
import Conceitos.imovel;

public class FactoryContratoAluguel {

    public ContratoAluguel criarContratoAluguel(double caucao, double desconto, double comissao, Cliente locatario, Funcionario funcionario, imovel imovel) {
        return new ContratoAluguel(caucao, desconto, comissao, locatario, funcionario, imovel);
    }

}