package Factory;

import Conceitos.AgendamentoVistoria;
import Conceitos.Funcionario;
import Conceitos.imovel;
import java.time.LocalDateTime;

public class FactoryAgendamentoVistoria {

    public AgendamentoVistoria criarAgendamentoVistoria(LocalDateTime data, Funcionario funcionario, imovel imovel) {
        return new AgendamentoVistoria(data, funcionario, imovel);
    }

}