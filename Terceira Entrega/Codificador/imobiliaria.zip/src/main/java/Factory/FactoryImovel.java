package Factory;

import Conceitos.imovel;
import Conceitos.Cliente;
import Conceitos.EnumImovel;
import Conceitos.LaudoTecnico;
import Conceitos.LaudoVistoria;
import java.awt.Graphics2D;

public class FactoryImovel {

    public imovel criarImovel(String nome, Cliente proprietario, String tipo_imovel) {
        return new imovel(nome, proprietario, tipo_imovel);
    }
    
    public imovel criarImovel(String nome, Cliente proprietario, EnumImovel tipo_imovel, boolean ocupado, LaudoTecnico laudo_tecnico, LaudoVistoria laudo_vistoria, Graphics2D imagem) {
        imovel novoImovel = new imovel(nome, proprietario, tipo_imovel, laudo_tecnico, laudo_vistoria, imagem);
        novoImovel.setOcupado(ocupado);
        return novoImovel;
    }

}
