package Factory;

import Conceitos.AgendamentoVisita;
import Conceitos.Cliente;
import Conceitos.Funcionario;
import Conceitos.imovel;
import java.time.LocalDateTime;

public class FactoryAgendamentoVisita {

    public AgendamentoVisita criarAgendamentoVisita(LocalDateTime data, Funcionario funcionario, Cliente cliente, imovel imovel) {
        return new AgendamentoVisita(data, funcionario, cliente, imovel);
    }

}