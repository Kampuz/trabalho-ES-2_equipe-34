package Factory;

import Conceitos.LaudoTecnico;

public class FactoryLaudoTecnico {

    public LaudoTecnico criarLaudoTecnico(String nome, String endereco, float valor_imovel, float area) {
        return new LaudoTecnico(nome, endereco, valor_imovel, area);
    }
    
    public LaudoTecnico criarLaudoTecnico(String nome_responsavel, String endereco, double valor, double area_total, double area_interna) {
        return new LaudoTecnico(nome_responsavel, endereco, valor, area_total, area_interna);
    }

}