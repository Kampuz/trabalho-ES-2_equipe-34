package Factory;

import Conceitos.LaudoVistoria;

public class FactoryLaudoVistoria {

    public LaudoVistoria criarLaudoVistoria(String nome, String descricao) {
        return new LaudoVistoria(nome, descricao);
    }

}