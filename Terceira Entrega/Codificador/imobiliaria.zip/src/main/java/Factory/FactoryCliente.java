package Factory;

import Conceitos.Cliente;
import Conceitos.Endereco;
import Conceitos.EnumGenero;
import java.time.LocalDateTime;
import java.awt.Graphics2D;

public class FactoryCliente {

    public Cliente criarCliente(String nome, String email, String celular) {
        Cliente cliente = new Cliente(nome);
        return cliente;
    }
    
    public Cliente criarCliente(String nome, LocalDateTime data_nascimento, String CPFouCNPJ, String telefone, String email, String endereco, EnumGenero genero, Graphics2D imagem) {
        Endereco enderecoObj = new Endereco(endereco, "", "", "");
        return new Cliente(nome, data_nascimento, CPFouCNPJ, telefone, email, enderecoObj, genero, imagem);
    }

}
