package Factory;

import Conceitos.EnumCargo;
import Conceitos.EnumGenero;
import Conceitos.Funcionario;
import Conceitos.Endereco;
import java.time.LocalDateTime;
import java.awt.Graphics2D;

public class FactoryFuncionario {

    public Funcionario criarFuncionario(String nome, EnumCargo cargo, double salario) {
        return new Funcionario(nome, cargo, salario);
    }
    
    public Funcionario criarFuncionario(String nome, LocalDateTime data_nascimento, String CPF, String telefone, String email, String endereco, EnumGenero genero, Graphics2D imagem, EnumCargo cargo, double salario) {
        Endereco enderecoObj = new Endereco(endereco, "", "", "");
        return new Funcionario(nome, data_nascimento, CPF, telefone, email, enderecoObj, genero, imagem, cargo, salario);
    }
    
    public Funcionario criarFuncionarioComSenha(String nome, String senha, LocalDateTime data_nascimento, String CPF, String telefone, String email, String endereco, EnumGenero genero, Graphics2D imagem, EnumCargo cargo, double salario) {
        Endereco enderecoObj = new Endereco(endereco, "", "", "");
        Funcionario funcionario = new Funcionario(nome, data_nascimento, CPF, telefone, email, enderecoObj, genero, imagem, cargo, salario);
        funcionario.setSenha(senha);
        return funcionario;
    }

}
