
import Conceitos.Cliente;
import Catalogos.CatalogoCliente;
import Persistencia.logger;
import java.util.UUID;

/**
 * Sistema de pagamento conforme diagramas de sequência
 */
public class SistemaDePagamento {
    private CatalogoCliente catalogoCliente;
    
    public SistemaDePagamento() {
        this.catalogoCliente = CatalogoCliente.getInstance();
    }
    
   
    public void pagarCobranca(String identificadorCliente, UUID id) {
        Cliente cliente = catalogoCliente.buscarCliente(identificadorCliente);
        
        if (cliente != null) {
            cliente.pagarCobranca(id);
            logger.log("Pagamento processado para cliente: " + identificadorCliente + " cobrança ID: " + id.toString());
        } else {
            logger.log("Cliente não encontrado: " + identificadorCliente);
        }
    }
}
