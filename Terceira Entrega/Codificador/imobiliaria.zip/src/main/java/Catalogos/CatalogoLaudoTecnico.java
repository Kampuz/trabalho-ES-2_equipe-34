package Catalogos;

import java.util.ArrayList;
import Conceitos.LaudoTecnico;

public class CatalogoLaudoTecnico {
    
    private static CatalogoLaudoTecnico instance;

    private ArrayList<LaudoTecnico> laudos;

    
    private CatalogoLaudoTecnico() {
        this.laudos = new ArrayList<>();
    }
    
    
    public static synchronized CatalogoLaudoTecnico getInstance() {
        if (instance == null) {
            instance = new CatalogoLaudoTecnico();
        }
        return instance;
    }

    public void adicionarLaudo(LaudoTecnico laudo) {
        laudos.add(laudo);
    }
    
    public LaudoTecnico buscarLaudoTecnico(int posicao) {
        if (posicao >= 0 && posicao < laudos.size()) {
            return laudos.get(posicao);
        }
        return null;
    }
}