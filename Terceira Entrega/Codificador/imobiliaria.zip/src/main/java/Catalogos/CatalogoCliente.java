package Catalogos;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import Conceitos.Cliente;
import Conceitos.CobrancaAluguel;
import Conceitos.CobrancaMulta;
import Conceitos.ContratoAluguel;
import Controle.ControladorTimer;
import Conceitos.GerarID;

public class CatalogoCliente {
    
    private static CatalogoCliente instance;

	private ArrayList<Cliente> clientes;
        
        
        private ArrayList<CobrancaAluguel> todasCobrancasAluguel;
        private ArrayList<CobrancaMulta> todasCobrancasMulta;

	private CatalogoLaudoTecnico catalogoLaudoTecnico;

	private Collection<Cliente> cliente;

	private ControladorTimer controladorTimer;
        
        private CatalogoCliente() {
            this.clientes = new ArrayList<>();
            this.todasCobrancasAluguel = new ArrayList<>();
            this.todasCobrancasMulta = new ArrayList<>();
        }
        
        public static synchronized CatalogoCliente getInstance() {
            if (instance == null) {
                instance = new CatalogoCliente();
            }
            return instance;
        }

	public Cliente buscarCliente(String identificador) {
            for(Cliente cliente : clientes) {
                if(cliente.getNome().equals(identificador)) {
                    return cliente;
                }
            }
            return null;
	}

	public boolean registrarCliente(Cliente cliente) {
            
            if (cliente.getCPFouCNPJ() != null && !cliente.getCPFouCNPJ().isEmpty()) {
                for (Cliente clienteExistente : clientes) {
                    if (clienteExistente.getCPFouCNPJ() != null && 
                        clienteExistente.getCPFouCNPJ().equals(cliente.getCPFouCNPJ())) {
                        return false; // CPF/CNPJ já existe
                    }
                }
            }
            
            clientes.add(cliente);
            return true;
	}

	public void cobrarAluguel() {
            
            for(Cliente cliente : clientes) {
                
                if (cliente.temContratoAluguelAtivo()) {
                    double valorAluguel = calcularValorAluguel(cliente);
                    cliente.criarCobrancaAluguel(valorAluguel);
                    cliente.notificarCliente("Cobrança de aluguel criada - Valor: R$ " + valorAluguel);
                    cliente.logTexto("Cobrança de aluguel processada para cliente: " + cliente.getNome());
                }
            }
	}

	public void buscarAluguel() {
	}

	public void cobrarMulta() {
            
            for(Cliente cliente : clientes) {
                
                if (cliente.temCobrancaAluguelAtrasada()) {
                    double valorMulta = calcularValorMulta(cliente);
                    cliente.criarCobrancaMulta(valorMulta);
                    
                    cliente.notificarCliente("Multa aplicada por atraso - Valor: R$ " + valorMulta);
                    cliente.logTexto("Cobrança de multa processada para cliente: " + cliente.getNome());
                }
            }
	}

	
	public String listar() {
            StringBuilder result = new StringBuilder();
            for(Cliente cliente : clientes) {
                result.append("Nome: ").append(cliente.getNome()).append("\n");
            }
            return result.toString();
	}

	public ArrayList<Cliente> getClientes() {
            return new ArrayList<>(clientes);
	}

	public void salvar() {
	}
        
        
        public String criar(Object dadosCliente) {
            String idCliente = GerarID.gerarID();
            
            return idCliente;
        }
        
        private double calcularValorAluguel(Cliente cliente) {
            ContratoAluguel contrato = cliente.getContratoAluguelAtivo();
            if (contrato == null) return 0.0;
            
            double valorImovel = contrato.getImovel().getValor();
            double desconto = contrato.getDesconto();
            double valorSeguros = contrato.getValorTotalSeguros(); 
            double comissaoImobiliaria = contrato.getComissaoImobiliaria();
            
            return ((valorImovel * (1 - desconto)) + valorSeguros) * (1 + comissaoImobiliaria);
        }
        
        private double calcularValorMulta(Cliente cliente) {
            CobrancaAluguel cobrancaAtrasada = cliente.getCobrancaAluguelAtrasada();
            if (cobrancaAtrasada == null) return 0.0;
            
            double valorAdicionalInicial = cobrancaAtrasada.getValorAluguel() * 0.02; // 2% do valor do aluguel como base
            double juros = 0.01; // 1% ao dia
            int diasAtraso = cliente.calcularDiasAtraso(cobrancaAtrasada);
            
            return valorAdicionalInicial * Math.pow(1 + juros, diasAtraso);
        }
        
        public void verificarNotificacoes() {
            for(Cliente cliente : clientes) {
                
            }
        }
        
        public String gerarRelatorioCustosMensais() {
            StringBuilder relatorio = new StringBuilder();
            relatorio.append("RELATÓRIO DE CUSTOS MENSAIS\n");
            relatorio.append("============================\n\n");
            
            double totalImpostos = 0.0;
            double totalContasLuz = 0.0;
            double totalContasAgua = 0.0;
            
            
            totalImpostos = 500.0;
            totalContasLuz = 300.0;
            totalContasAgua = 200.0;
            
            relatorio.append("Impostos sobre imóveis: R$ ").append(String.format("%.2f", totalImpostos)).append("\n");
            relatorio.append("Contas de energia elétrica: R$ ").append(String.format("%.2f", totalContasLuz)).append("\n");
            relatorio.append("Contas de água: R$ ").append(String.format("%.2f", totalContasAgua)).append("\n");
            relatorio.append("\nTOTAL CUSTOS MENSAIS: R$ ").append(String.format("%.2f", totalImpostos + totalContasLuz + totalContasAgua));
            
            return relatorio.toString();
        }
        
        public String gerarRelatorioGeral() {
            StringBuilder relatorio = new StringBuilder();
            relatorio.append("RELATÓRIO GERAL - CUSTOS E GANHOS\n");
            relatorio.append("=================================\n\n");
            
            
            double custosSalarios = calcularSalarios();
            double custosImpostos = 500.0; // placeholder
            double custosContasAgua = 200.0; // placeholder
            double custosContasEnergia = 300.0; // placeholder
            double custosManutencao = 150.0; // placeholder
            
            double totalCustos = custosSalarios + custosImpostos + custosContasAgua + custosContasEnergia + custosManutencao;
            
            
            double totalGanhos = calcularGanhosMensais();
            
            relatorio.append("CUSTOS MENSAIS:\n");
            relatorio.append("- Salários: R$ ").append(String.format("%.2f", custosSalarios)).append("\n");
            relatorio.append("- Impostos sobre imóveis: R$ ").append(String.format("%.2f", custosImpostos)).append("\n");
            relatorio.append("- Contas de água: R$ ").append(String.format("%.2f", custosContasAgua)).append("\n");
            relatorio.append("- Contas de energia: R$ ").append(String.format("%.2f", custosContasEnergia)).append("\n");
            relatorio.append("- Manutenção: R$ ").append(String.format("%.2f", custosManutencao)).append("\n");
            relatorio.append("TOTAL CUSTOS: R$ ").append(String.format("%.2f", totalCustos)).append("\n\n");
            
            relatorio.append("GANHOS MENSAIS:\n");
            relatorio.append("- Comissões da imobiliária: R$ ").append(String.format("%.2f", totalGanhos)).append("\n");
            relatorio.append("TOTAL GANHOS: R$ ").append(String.format("%.2f", totalGanhos)).append("\n\n");
            
            relatorio.append("RESULTADO DO MÊS: R$ ").append(String.format("%.2f", totalGanhos - totalCustos));
            
            return relatorio.toString();
        }
        
        private double calcularSalarios() {
            
            return 3000.0; // placeholder
        }
        
        private double calcularGanhosMensais() {
            double totalGanhos = 0.0;
            
            for (Cliente cliente : clientes) {
                if (cliente.temContratoAluguelAtivo()) {
                    ContratoAluguel contrato = cliente.getContratoAluguelAtivo();
                    double valorAluguel = calcularValorAluguel(cliente);
                    
                    
                    double valorBase = contrato.getImovel().getValor() * (1 - contrato.getDesconto()) + contrato.getValorTotalSeguros();
                    double comissao = valorAluguel - valorBase;
                    
                    totalGanhos += comissao;
                }
            }
            
            return totalGanhos;
        }
        
        public boolean valida() {
            return true;
        }
        
        public CobrancaAluguel buscarCobrancaAluguel(String identificador) {
            try {
                for (CobrancaAluguel cobranca : todasCobrancasAluguel) {
                    if (cobranca.getId().toString().equals(identificador) || 
                        cobranca.getId().toString().startsWith(identificador)) {
                        return cobranca;
                    }
                }
                return null;
            } catch (Exception e) {
                return null;
            }
        }
        
        public CobrancaMulta buscarCobrancaMulta(String identificador) {
            try {
                for (CobrancaMulta cobranca : todasCobrancasMulta) {
                    if (cobranca.getId().toString().equals(identificador) || 
                        cobranca.getId().toString().startsWith(identificador)) {
                        return cobranca;
                    }
                }
                return null;
            } catch (Exception e) {
                return null;
            }
        }
        
        public boolean adicionarCobrancaAluguel(CobrancaAluguel cobranca) {
            try {
                return todasCobrancasAluguel.add(cobranca);
            } catch (Exception e) {
                return false;
            }
        }
        
        public boolean adicionarCobrancaMulta(CobrancaMulta cobranca) {
            try {
                return todasCobrancasMulta.add(cobranca);
            } catch (Exception e) {
                return false;
            }
        }
        
        public java.util.List<Cliente> buscarClientesComAtraso(java.time.LocalDateTime agora) {
            
            return new ArrayList<>();
        }
        
        public boolean arquivarCliente(String identificador) {
            
            return false;
        }
        
        public List<CobrancaAluguel> listarCobrancasAluguelPendentes() {
            List<CobrancaAluguel> cobrancasPendentes = new ArrayList<>();
            
            for (CobrancaAluguel cobranca : todasCobrancasAluguel) {
                if (!cobranca.isPago()) {
                    cobrancasPendentes.add(cobranca);
                }
            }
            
            return cobrancasPendentes;
        }
        
        public List<CobrancaMulta> listarCobrancasMultaPendentes() {
            List<CobrancaMulta> cobrancasPendentes = new ArrayList<>();
            
            for (CobrancaMulta cobranca : todasCobrancasMulta) {
                if (!cobranca.isPago()) {
                    cobrancasPendentes.add(cobranca);
                }
            }
            
            return cobrancasPendentes;
        }

}
