package Catalogos;

import java.util.ArrayList;
import Conceitos.imovel;
import Conceitos.GerarID;

public class CatalogoImovel {
    
    
    private static CatalogoImovel instance;

	private ArrayList<imovel> imoveis;

	private imovel imovel;

        
        private CatalogoImovel() {
            this.imoveis = new ArrayList<>();
        }
        
       
        public static synchronized CatalogoImovel getInstance() {
            if (instance == null) {
                instance = new CatalogoImovel();
            }
            return instance;
        }
	public void adicionarImovel(imovel imovel) {
            this.imoveis.add(imovel);
	}

	public imovel buscarImovel(String nome) {
            System.out.println("🔍 DEBUG CatalogoImovel.buscarImovel: buscando [" + nome + "]");
            System.out.println("🔍 DEBUG Total imóveis no catálogo: " + imoveis.size());
            
            for(int i = 0; i < imoveis.size(); i++) {
                String nomeImovel = imoveis.get(i).getNome();
                System.out.println("🔍 DEBUG [" + i + "] Comparando [" + nome + "] com [" + nomeImovel + "]");
                
                if(nomeImovel != null && nomeImovel.equals(nome)) {
                    System.out.println("✅ DEBUG Imóvel encontrado na posição " + i + ": " + nomeImovel);
                    return imoveis.get(i);
                }
            }
            
            System.out.println("❌ DEBUG Imóvel não encontrado: " + nome);
            System.out.println("🔍 DEBUG Imóveis disponíveis:");
            for(int i = 0; i < imoveis.size(); i++) {
                System.out.println("  [" + i + "] " + imoveis.get(i).getNome());
            }
            
            return null;
	}
        
       
        public String criar(Object dadosImovel) {
            String idImovel = GerarID.gerarID();
            return idImovel;
        }
        
        
        public boolean arquivarImovel(String identificador) {
            
            return false;
        }
        
        public String listar() {
            System.out.println("🔍 DEBUG CatalogoImovel.listar: total de " + imoveis.size() + " imóveis");
            
            if (imoveis.isEmpty()) {
                System.out.println("❌ DEBUG Lista vazia - nenhum imóvel cadastrado");
                return "";
            }
            
            StringBuilder result = new StringBuilder();
            for(int i = 0; i < imoveis.size(); i++) {
                imovel imovel = imoveis.get(i);
                String linha = "Nome: " + imovel.getNome() + 
                              " | Proprietário: " + (imovel.getProprietario() != null ? imovel.getProprietario().getNome() : "N/A") + 
                              " | Tipo: " + imovel.getTipoImovel() +
                              " | Ocupado: " + (imovel.isOcupado() ? "Sim" : "Não") + "\n";
                
                System.out.println("[" + i + "] " + linha.trim());
                result.append(linha);
            }
            
            String resultado = result.toString();
            System.out.println("Resultado final da listagem (" + resultado.length() + " chars): [" + resultado + "]");
            return resultado;
        }

        public ArrayList<imovel> getImoveis() {
            return new ArrayList<>(imoveis);
        }

}
