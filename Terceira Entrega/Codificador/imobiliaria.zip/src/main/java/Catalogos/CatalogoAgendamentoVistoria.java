package Catalogos;

import java.util.ArrayList;
import Conceitos.AgendamentoVistoria;

public class CatalogoAgendamentoVistoria {
    
    private static CatalogoAgendamentoVistoria instancia;
    private ArrayList<AgendamentoVistoria> agendamentosVistoria;
    
    private CatalogoAgendamentoVistoria() {
        this.agendamentosVistoria = new ArrayList<>();
    }
    
    public static CatalogoAgendamentoVistoria getInstance() {
        if (instancia == null) {
            instancia = new CatalogoAgendamentoVistoria();
        }
        return instancia;
    }
    
    public void adicionarAgendamento(AgendamentoVistoria agendamento) {
        agendamentosVistoria.add(agendamento);
    }
    
    public boolean verificaAtivacaoVistoria() {
        return true;
    }
    
    public String agendaVistoria(String IDImovel) {
        return "VistoriaAgendada";
    }
    
    public boolean verificaConflitoVistoria() {
        return false;
    }
    
    public void salvar() {
    }
    
    public AgendamentoVistoria buscarAgendamento(String identificador) {
        for (AgendamentoVistoria agendamento : agendamentosVistoria) {
            if (agendamento.getId().toString().equals(identificador)) {
                return agendamento;
            }
        }
        return null;
    }
    
    public boolean verificarDisponibilidade(java.time.LocalDateTime novaDataHora, Conceitos.Funcionario funcionario, java.util.UUID agendamentoAtualId) {
        for (AgendamentoVistoria agendamento : agendamentosVistoria) {
            if (agendamentoAtualId != null && agendamento.getId().equals(agendamentoAtualId)) {
                continue;
            }
            
            if (agendamento.getDataVistoria().equals(novaDataHora)) {
                
                if (agendamento.getFuncionarioResponsavel().equals(funcionario)) {
                    return false;
                }
            }
        }
        return true;
    }
    
    public ArrayList<AgendamentoVistoria> listarTodos() {
        return new ArrayList<>(agendamentosVistoria);
    }
    
    public void verificarNotificacoes() {
        java.time.LocalDateTime agora = java.time.LocalDateTime.now();
        
        for (AgendamentoVistoria agendamento : agendamentosVistoria) {
            java.time.LocalDateTime dataVistoria = agendamento.getDataVistoria();
            long horasRestantes = java.time.temporal.ChronoUnit.HOURS.between(agora, dataVistoria);
            
            if (horasRestantes == 1) {
                agendamento.notificarEnvolvidos("Vistoria agendada em 1 hora");
            } else if (horasRestantes == 24) {
                agendamento.notificarEnvolvidos("Vistoria agendada em 1 dia");
            } else if (horasRestantes == 72) {
                agendamento.notificarEnvolvidos("Vistoria agendada em 3 dias");
            } else if (horasRestantes == 120) {
                agendamento.notificarEnvolvidos("Vistoria agendada em 5 dias");
            }
        }
    }
}