package Catalogos;

import java.util.ArrayList;
import Conceitos.Funcionario;
import Conceitos.EnumCargo;
import Controle.ControladorGerente;

public class CatalogoFuncionario {
    
    
    private static CatalogoFuncionario instance;

	private ArrayList<Funcionario> funcionarios;

	private Funcionario funcionario;

	private ControladorGerente controladorGerente;

        
        private CatalogoFuncionario() {
            this.funcionarios = new ArrayList<>();
        }
        
        public static synchronized CatalogoFuncionario getInstance() {
            if (instance == null) {
                instance = new CatalogoFuncionario();
            }
            return instance;
        }
	public boolean adicionarFuncionario(Funcionario funcionario) {
            if (funcionario.getCPFouCNPJ() != null && !funcionario.getCPFouCNPJ().isEmpty()) {
                for (Funcionario funcExistente : funcionarios) {
                    if (funcExistente.getCPFouCNPJ() != null && 
                        funcExistente.getCPFouCNPJ().equals(funcionario.getCPFouCNPJ())) {
                        return false; // CPF já existe
                    }
                }
            }
            
            funcionarios.add(funcionario);
            return true;
	}
        
	public Funcionario buscarFuncionario(String nome) {
            for(int i = 0; i < funcionarios.size(); i++) {
                if(funcionarios.get(i).getNome().equals(nome)) {
                    return funcionarios.get(i);
                }
            }
            return null;
	}
        public double calcularGastos() {
            double gasto = 0;
            for(int i = 0;i < funcionarios.size();i++) {
                gasto = gasto + funcionarios.get(i).getSalario();
            }
            return gasto;
        }

        public String listar() {
            StringBuilder value = new StringBuilder("");
            for(int i = 0;i < funcionarios.size();i++) {
                funcionario = funcionarios.get(i);
                value.append("Nome: ").append(funcionario.getNome()).append(";Salário:").append(funcionario.getSalario()).append("\n");
            }
            return value.toString();
        }

        public ArrayList<Funcionario> getFuncionarios() {
            return new ArrayList<>(funcionarios);
        }
        
        public void notificarFuncionario(Object dadosAgendamento) {
            System.out.println("Funcionário notificado sobre agendamento");
        }
        
        public Funcionario buscarFuncionarioPorEmail(String email) {
            for (Funcionario func : funcionarios) {
                if (func.getEmail() != null && func.getEmail().equals(email)) {
                    return func;
                }
            }
            return null;
        }
        
        public boolean temFuncionarios() {
            return !funcionarios.isEmpty();
        }
        
        public Funcionario login(String email, String senha) {
            if (email == null || email.isEmpty() || senha == null || senha.isEmpty()) {
                return null;
            }
            
            for (Funcionario func : funcionarios) {
                if (func.getEmail() != null && func.getEmail().equals(email) &&
                    func.getSenha() != null && func.getSenha().equals(senha)) {
                    return func;
                }
            }
            return null;
        }
        
        
        public boolean arquivarFuncionario(String identificador) {
            try {
                Funcionario funcionario = buscarFuncionario(identificador);
                if (funcionario == null) {
                    return false;
                }
                
                if (funcionario.getCargo() == EnumCargo.GERENTE) {
                    return false; // Gerentes não podem ser arquivados
                }
                
                return funcionarios.remove(funcionario);
            } catch (Exception e) {
                return false;
            }
        }

}
