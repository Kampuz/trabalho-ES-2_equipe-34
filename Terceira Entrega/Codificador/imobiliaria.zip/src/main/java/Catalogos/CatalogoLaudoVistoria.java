package Catalogos;

import java.util.ArrayList;
import Conceitos.LaudoVistoria;

public class CatalogoLaudoVistoria {
    
    
    private static CatalogoLaudoVistoria instance;

    private ArrayList<LaudoVistoria> laudos;

    
    private CatalogoLaudoVistoria() {
        this.laudos = new ArrayList<>();
    }
    
    
    public static synchronized CatalogoLaudoVistoria getInstance() {
        if (instance == null) {
            instance = new CatalogoLaudoVistoria();
        }
        return instance;
    }

    public void adicionarLaudo(LaudoVistoria laudo) {
        laudos.add(laudo);
    }
    
    public LaudoVistoria buscarLaudoVistoria(int posicao) {
        if (posicao >= 0 && posicao < laudos.size()) {
            return laudos.get(posicao);
        }
        return null;
    }

}