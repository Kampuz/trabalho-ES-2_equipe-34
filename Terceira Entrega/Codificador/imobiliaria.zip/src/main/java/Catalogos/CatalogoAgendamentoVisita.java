package Catalogos;

import java.util.ArrayList;
import Conceitos.AgendamentoVisita;

public class CatalogoAgendamentoVisita {
    
    private static CatalogoAgendamentoVisita instancia;
    private ArrayList<AgendamentoVisita> agendamentosVisita;
    
    private CatalogoAgendamentoVisita() {
        this.agendamentosVisita = new ArrayList<>();
    }
    
    public static CatalogoAgendamentoVisita getInstance() {
        if (instancia == null) {
            instancia = new CatalogoAgendamentoVisita();
        }
        return instancia;
    }
    
    public void adicionarAgendamento(AgendamentoVisita agendamento) {
        this.agendamentosVisita.add(agendamento);
    }
    
    public boolean verificaConflitoVisita() {
        return false;
    }
    
    public void agendamentoVisita(Object dadosAgendamento, boolean notificar, boolean representaFuncionario) {
    }
    
    public void salvar() {
    }
    
    public AgendamentoVisita buscarAgendamento(String identificador) {
        for (AgendamentoVisita agendamento : agendamentosVisita) {
            if (agendamento.getId().toString().equals(identificador)) {
                return agendamento;
            }
        }
        return null;
    }
    
    public boolean verificarDisponibilidade(java.time.LocalDateTime novaDataHora, Conceitos.Funcionario funcionario, java.util.UUID agendamentoAtualId) {
        for (AgendamentoVisita agendamento : agendamentosVisita) {
            if (agendamentoAtualId != null && agendamento.getId().equals(agendamentoAtualId)) {
                continue;
            }
            
            if (agendamento.getDataVisita().equals(novaDataHora)) {
                
                if (agendamento.getFuncionarioResponsavel().equals(funcionario)) {
                    return false;
                }
            }
        }
        return true;
    }
    
    public ArrayList<AgendamentoVisita> listarTodos() {
        return new ArrayList<>(agendamentosVisita);
    }
    
    public void verificarNotificacoes() {
        java.time.LocalDateTime agora = java.time.LocalDateTime.now();
        
        for (AgendamentoVisita agendamento : agendamentosVisita) {
            java.time.LocalDateTime dataVisita = agendamento.getDataVisita();
            long horasRestantes = java.time.temporal.ChronoUnit.HOURS.between(agora, dataVisita);
            
            if (horasRestantes == 1) {
                agendamento.notificarEnvolvidos("Visita agendada em 1 hora");
            } else if (horasRestantes == 24) {
                agendamento.notificarEnvolvidos("Visita agendada em 1 dia");
            } else if (horasRestantes == 72) {
                agendamento.notificarEnvolvidos("Visita agendada em 3 dias");  
            } else if (horasRestantes == 120) {
                agendamento.notificarEnvolvidos("Visita agendada em 5 dias");
            }
        }
    }
}