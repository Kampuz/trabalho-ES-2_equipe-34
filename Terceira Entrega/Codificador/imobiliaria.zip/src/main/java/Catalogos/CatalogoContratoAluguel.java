package Catalogos;

import java.util.ArrayList;
import Conceitos.ContratoAluguel;

public class CatalogoContratoAluguel {

    private ArrayList<ContratoAluguel> contratos;

    public CatalogoContratoAluguel() {
        this.contratos = new ArrayList<>();
    }

    public void adicionarContrato(ContratoAluguel contrato) {
        contratos.add(contrato);
    }

    public String criaContrato(Object dadosContrato) {
        ContratoAluguel novoContrato = new ContratoAluguel(
            1000.0, // caução placeholder
            0.05,   // desconto placeholder
            0.10,   // comissão placeholder  
            null,   // cliente placeholder
            null,   // funcionário placeholder
            null    // imóvel placeholder
        );
        contratos.add(novoContrato);
        return novoContrato.getId().toString();
    }
    
    public java.util.List<ContratoAluguel> buscarContratosAtivos() {
        return new ArrayList<>(contratos);
    }
    
    public java.util.List<ContratoAluguel> buscarContratosPorSeguro(String seguroId) {
        java.util.List<ContratoAluguel> resultado = new ArrayList<>();
        for (ContratoAluguel contrato : contratos) {
            
        }
        return resultado;
    }

}