package Catalogos;

import java.util.ArrayList;
import Conceitos.Seguro;

public class CatalogoSeguro {

    private static CatalogoSeguro instance;
    private ArrayList<Seguro> seguros;
    
    private CatalogoSeguro() {
        this.seguros = new ArrayList<>();
    }
    
    public static CatalogoSeguro getInstance() {
        if (instance == null) {
            instance = new CatalogoSeguro();
        }
        return instance;
    }
    
    public void registrarSeguro(Seguro seguro) {
        seguros.add(seguro);
    }
    
    public void criaSeguro(Object dadosSeguro) {
        Seguro novoSeguro = new Seguro(
            "Seguro Padrão",    // nome placeholder
            100.0,              // valor placeholder
            "Descrição do seguro", // descrição placeholder
            false               // não ativado por padrão
        );
        seguros.add(novoSeguro);
    }
    
    public Seguro buscarSeguro(String identificador) {
        for (Seguro seguro : seguros) {
            if (seguro.getId().toString().equals(identificador) || 
                seguro.getNome().equals(identificador)) {
                return seguro;
            }
        }
        return null;
    }
    
    public java.util.List<Seguro> listarSeguros() {
        return new ArrayList<>(seguros);
    }
    
    public boolean removerSeguro(String identificador) {
        return seguros.removeIf(seguro -> 
            seguro.getId().toString().equals(identificador) || 
            seguro.getNome().equals(identificador)
        );
    }

}