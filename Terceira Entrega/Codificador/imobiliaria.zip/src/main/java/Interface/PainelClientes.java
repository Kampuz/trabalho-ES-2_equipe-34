package Interface;

import Controle.ControladorCentral;
import Conceitos.*;
import Catalogos.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class PainelClientes extends JPanel {
    
    private ControladorCentral controladorCentral;
    private JFrame parentFrame;
    private static final Color COR_PRIMARIA = new Color(41, 98, 255);
    
    public PainelClientes(ControladorCentral controlador, JFrame parent) {
        this.controladorCentral = controlador;
        this.parentFrame = parent;
        criarInterface();
    }
    
    private void criarInterface() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        JPanel botoes = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton btnCadastrar = criarBotao("Cadastrar Cliente", COR_PRIMARIA);
        JButton btnListar = criarBotao("Listar Clientes", Color.GRAY);
        JButton btnEditar = criarBotao("Editar Cliente", Color.GRAY);
        JButton btnBuscar = criarBotao("Buscar Cliente", new Color(0, 150, 136));
        JButton btnVisualizar = criarBotao("Visualizar Cliente", new Color(102, 51, 153));
        JButton btnContrato = criarBotao("Criar Contrato", new Color(255, 140, 0));
        JButton btnArquivarCliente = criarBotao("Arquivar Cliente", new Color(220, 53, 69));
        
        btnCadastrar.addActionListener(e -> abrirFormularioCadastroCliente());
        btnListar.addActionListener(e -> listarClientes());
        btnEditar.addActionListener(e -> editarCliente());
        btnBuscar.addActionListener(e -> buscarCliente());
        btnVisualizar.addActionListener(e -> visualizarCliente());
        btnContrato.addActionListener(e -> criarNovoContrato());
        btnArquivarCliente.addActionListener(e -> arquivarCliente());
        
        botoes.add(btnCadastrar);
        botoes.add(btnListar);
        botoes.add(btnEditar);
        botoes.add(btnBuscar);
        botoes.add(btnVisualizar);
        botoes.add(btnArquivarCliente);
        botoes.add(btnContrato);
        
        JPanel conteudo = new JPanel(new BorderLayout());
        JTable tabela = new JTable();
        JScrollPane scroll = new JScrollPane(tabela);
        conteudo.add(scroll, BorderLayout.CENTER);
        
        add(botoes, BorderLayout.NORTH);
        add(conteudo, BorderLayout.CENTER);
    }
    
    private JButton criarBotao(String texto, Color cor) {
        JButton botao = new JButton(texto);
        botao.setBackground(cor);
        botao.setForeground(Color.WHITE);
        botao.setFont(new Font("Arial", Font.BOLD, 12));
        botao.setFocusPainted(false);
        botao.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16));
        botao.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        botao.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                botao.setBackground(cor.darker());
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                botao.setBackground(cor);
            }
        });
        
        return botao;
    }
    
    private void abrirFormularioCadastroCliente() {
        new FormularioCadastroCliente((SistemaImobiliarioGUI)parentFrame).setVisible(true);
    }
    
    private void listarClientes() {
        try {
            String listaClientes = controladorCentral.consultaListagem(0);
            
            if (listaClientes == null || listaClientes.trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, 
                    "Nenhum cliente cadastrado no sistema.", 
                    "Lista de Clientes", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            
            // Criar dialog personalizado com funcionalidades de acompanhamento
            JDialog dialogLista = new JDialog((JFrame)parentFrame, "Lista Completa de Clientes", true);
            dialogLista.setSize(800, 600);
            dialogLista.setLocationRelativeTo(parentFrame);
            dialogLista.setLayout(new BorderLayout());
            
            // Painel superior com estatísticas
            JPanel painelInfo = new JPanel(new FlowLayout(FlowLayout.LEFT));
            painelInfo.setBorder(BorderFactory.createTitledBorder("Estatísticas"));
            
            int totalClientes = contarLinhas(listaClientes);
            JLabel lblInfo = new JLabel("Total de Clientes: " + totalClientes + " | Sistema atualizado em: " + 
                java.time.LocalDateTime.now().format(java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")));
            painelInfo.add(lblInfo);
            
            // Área de texto formatada
            JTextArea areaLista = new JTextArea();
            areaLista.setEditable(false);
            areaLista.setFont(new Font("Courier New", Font.PLAIN, 12));
            
            StringBuilder listaFormatada = new StringBuilder();
            listaFormatada.append("=== RELATÓRIO DETALHADO DE CLIENTES ===\n\n");
            listaFormatada.append("Total de Clientes Cadastrados: ").append(totalClientes).append("\n");
            listaFormatada.append("Data/Hora do Relatório: ").append(java.time.LocalDateTime.now().format(
                java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"))).append("\n\n");
            listaFormatada.append("--- DADOS DOS CLIENTES ---\n");
            listaFormatada.append(listaClientes);
            
            areaLista.setText(listaFormatada.toString());
            
            JScrollPane scrollPane = new JScrollPane(areaLista);
            
            // Painel de controles
            JPanel painelControles = new JPanel(new FlowLayout());
            JButton btnFechar = criarBotao("Fechar", Color.GRAY);
            JButton btnAcompanhar = criarBotao("Acompanhamento Detalhado", COR_PRIMARIA);
            JButton btnAtualizar = criarBotao("Atualizar Lista", new Color(0, 150, 136));
            
            btnFechar.addActionListener(e -> dialogLista.dispose());
            
            btnAtualizar.addActionListener(e -> {
                String novaLista = controladorCentral.consultaListagem(0);
                if (novaLista != null) {
                    int novoTotal = contarLinhas(novaLista);
                    lblInfo.setText("Total de Clientes: " + novoTotal + " | Sistema atualizado em: " + 
                        java.time.LocalDateTime.now().format(java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")));
                    
                    StringBuilder novaFormatada = new StringBuilder();
                    novaFormatada.append("=== RELATÓRIO DETALHADO DE CLIENTES ===\n\n");
                    novaFormatada.append("Total de Clientes Cadastrados: ").append(novoTotal).append("\n");
                    novaFormatada.append("Data/Hora do Relatório: ").append(java.time.LocalDateTime.now().format(
                        java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"))).append("\n\n");
                    novaFormatada.append("--- DADOS DOS CLIENTES ---\n");
                    novaFormatada.append(novaLista);
                    
                    areaLista.setText(novaFormatada.toString());
                }
            });
            
            btnAcompanhar.addActionListener(e -> {
                StringBuilder acompanhamento = new StringBuilder();
                acompanhamento.append("=== ACOMPANHAMENTO DETALHADO DE CLIENTES ===\n\n");
                acompanhamento.append("Total Cadastrado: ").append(totalClientes).append("\n");
                acompanhamento.append("Sistema: Operacional\n");
                acompanhamento.append("Última atualização: ").append(java.time.LocalDateTime.now().format(
                    java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"))).append("\n");
                
                JOptionPane.showMessageDialog(dialogLista, 
                    new JScrollPane(new JTextArea(acompanhamento.toString(), 10, 50)), 
                    "Acompanhamento Detalhado", JOptionPane.INFORMATION_MESSAGE);
            });
            
            painelControles.add(btnAtualizar);
            painelControles.add(btnAcompanhar);
            painelControles.add(btnFechar);
            
            dialogLista.add(painelInfo, BorderLayout.NORTH);
            dialogLista.add(scrollPane, BorderLayout.CENTER);
            dialogLista.add(painelControles, BorderLayout.SOUTH);
            
            dialogLista.setVisible(true);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "Erro ao listar clientes: " + e.getMessage(), 
                "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private int contarLinhas(String texto) {
        if (texto == null || texto.trim().isEmpty()) return 0;
        return texto.split("\n").length;
    }
    
    private void editarCliente() {
        try {
            String identificador = JOptionPane.showInputDialog(
                this, 
                "Digite o nome ou email do cliente que deseja editar:",
                "Editar Cliente",
                JOptionPane.QUESTION_MESSAGE
            );
            
            if (identificador == null || identificador.trim().isEmpty()) {
                return;
            }
            
            Cliente cliente = CatalogoCliente.getInstance().buscarCliente(identificador.trim());
            
            if (cliente == null) {
                JOptionPane.showMessageDialog(
                    this,
                    "Cliente não encontrado: " + identificador,
                    "Erro",
                    JOptionPane.ERROR_MESSAGE
                );
                return;
            }
            
            mostrarDialogEdicaoCliente(cliente);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(
                this,
                "Erro ao editar cliente: " + e.getMessage(),
                "Erro",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }
    
    private void mostrarDialogEdicaoCliente(Cliente cliente) {
        JDialog dialog = new JDialog((JFrame)parentFrame, "Editar Cliente - " + cliente.getNome(), true);
        dialog.setSize(500, 450);
        dialog.setLocationRelativeTo(parentFrame);
        
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.WEST;
        
        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(new JLabel("Nome:*"), gbc);
        JTextField nomeField = new JTextField(cliente.getNome(), 20);
        gbc.gridx = 1;
        panel.add(nomeField, gbc);
        
        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(new JLabel("Email:"), gbc);
        JTextField emailField = new JTextField(cliente.getEmail(), 20);
        gbc.gridx = 1;
        panel.add(emailField, gbc);
        
        gbc.gridx = 0; gbc.gridy = 2;
        panel.add(new JLabel("Telefone:"), gbc);
        JTextField telefoneField = new JTextField(cliente.getTelefone(), 20);
        gbc.gridx = 1;
        panel.add(telefoneField, gbc);
        
        gbc.gridx = 0; gbc.gridy = 3;
        panel.add(new JLabel("CPF/CNPJ:"), gbc);
        JTextField cpfField = new JTextField(cliente.getCPFouCNPJ(), 20);
        cpfField.setEditable(false);
        cpfField.setToolTipText("CPF/CNPJ não pode ser alterado");
        gbc.gridx = 1;
        panel.add(cpfField, gbc);
        
        JPanel botoesPanel = new JPanel(new FlowLayout());
        JButton btnSalvar = criarBotao("Salvar", COR_PRIMARIA);
        JButton btnCancelar = criarBotao("Cancelar", Color.GRAY);
        
        btnSalvar.addActionListener(e -> {
            try {
                String novoNome = nomeField.getText().trim();
                String novoEmail = emailField.getText().trim();
                String novoTelefone = telefoneField.getText().trim();
                
                if (novoNome.isEmpty()) {
                    JOptionPane.showMessageDialog(dialog, 
                        "Nome é obrigatório!", "Erro", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                boolean sucesso = controladorCentral.editarCliente(
                    cliente.getNome(),
                    novoNome,
                    novoEmail,
                    novoTelefone,
                    null,
                    null
                );
                
                if (sucesso) {
                    JOptionPane.showMessageDialog(dialog, "Cliente atualizado com sucesso!");
                    dialog.dispose();
                } else {
                    JOptionPane.showMessageDialog(dialog, "Erro ao atualizar cliente", 
                        "Erro", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(dialog, "Erro: " + ex.getMessage(), 
                    "Erro", JOptionPane.ERROR_MESSAGE);
            }
        });
        
        btnCancelar.addActionListener(e -> dialog.dispose());
        
        botoesPanel.add(btnSalvar);
        botoesPanel.add(btnCancelar);
        
        gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 2;
        panel.add(botoesPanel, gbc);
        
        dialog.add(panel);
        dialog.setVisible(true);
    }
    
    private void arquivarCliente() {
        try {
            String nomeCliente = JOptionPane.showInputDialog(
                this, 
                "Digite o nome do cliente que deseja arquivar:\n\n" +
                "⚠️ ATENÇÃO: Esta operação é irreversível!\n" +
                "O cliente será marcado como arquivado.",
                "Arquivar Cliente",
                JOptionPane.WARNING_MESSAGE
            );
            
            if (nomeCliente == null || nomeCliente.trim().isEmpty()) {
                return;
            }
            
            int confirmacao = JOptionPane.showConfirmDialog(
                this,
                "Tem certeza que deseja arquivar o cliente?\n\n" +
                "Cliente: " + nomeCliente + "\n\n" +
                "Esta operação é irreversível!",
                "Confirmar Arquivamento",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE
            );
            
            if (confirmacao == JOptionPane.YES_OPTION) {
                boolean sucesso = controladorCentral.arquivarCliente(nomeCliente);
                
                if (sucesso) {
                    JOptionPane.showMessageDialog(this, "Cliente arquivado com sucesso!");
                } else {
                    JOptionPane.showMessageDialog(this, 
                        "Erro ao arquivar cliente!\nVerifique se o nome está correto.", 
                        "Erro", JOptionPane.ERROR_MESSAGE);
                }
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Erro inesperado: " + e.getMessage(),
                "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void buscarCliente() {
        try {
            String identificador = JOptionPane.showInputDialog(
                this,
                "Digite o identificador do cliente:",
                "Buscar Cliente",
                JOptionPane.QUESTION_MESSAGE
            );
            
            if (identificador == null || identificador.trim().isEmpty()) {
                return;
            }
            
            Cliente cliente = controladorCentral.buscarClientePorNome(identificador);
            
            if (cliente == null) {
                JOptionPane.showMessageDialog(this, "Cliente não encontrado.", "Busca", JOptionPane.WARNING_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, 
                    "Cliente encontrado:\n\n" +
                    "Nome: " + cliente.getNome() + "\n" +
                    "Email: " + cliente.getEmail() + "\n" +
                    "Telefone: " + cliente.getTelefone() + "\n" +
                    "CPF/CNPJ: " + cliente.getCPFouCNPJ(), 
                    "Cliente Encontrado", JOptionPane.INFORMATION_MESSAGE);
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Erro ao buscar cliente: " + e.getMessage(),
                "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void criarNovoContrato() {
        try {
            if (CatalogoCliente.getInstance().listar().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Não há clientes cadastrados no sistema!");
                return;
            }
            
            if (CatalogoImovel.getInstance().getImoveis().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Não há imóveis cadastrados no sistema!");
                return;
            }
            
            JDialog dialog = new JDialog((JFrame)parentFrame, "Criar Contrato de Aluguel", true);
            dialog.setSize(500, 400);
            dialog.setLocationRelativeTo(parentFrame);
            dialog.setLayout(new BorderLayout());
            
            JPanel painelPrincipal = new JPanel(new GridBagLayout());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(10, 10, 10, 10);
            gbc.anchor = GridBagConstraints.WEST;
            
            gbc.gridx = 0; gbc.gridy = 0;
            painelPrincipal.add(new JLabel("Cliente:"), gbc);
            
            JComboBox<Cliente> comboCliente = new JComboBox<>();
            for (Cliente cliente : CatalogoCliente.getInstance().getClientes()) {
                comboCliente.addItem(cliente);
            }
            gbc.gridx = 1;
            painelPrincipal.add(comboCliente, gbc);
            
            gbc.gridx = 0; gbc.gridy = 1;
            painelPrincipal.add(new JLabel("Imóvel:"), gbc);
            
            JComboBox<imovel> comboImovel = new JComboBox<>();
            for (imovel imovelItem : CatalogoImovel.getInstance().getImoveis()) {
                comboImovel.addItem(imovelItem);
            }
            gbc.gridx = 1;
            painelPrincipal.add(comboImovel, gbc);
            
            gbc.gridx = 0; gbc.gridy = 2;
            painelPrincipal.add(new JLabel("Desconto (%):"), gbc);
            JTextField descontoField = new JTextField("0", 15);
            gbc.gridx = 1;
            painelPrincipal.add(descontoField, gbc);
            
            gbc.gridx = 0; gbc.gridy = 3;
            painelPrincipal.add(new JLabel("Comissão (%):"), gbc);
            JTextField comissaoField = new JTextField("5", 15);
            gbc.gridx = 1;
            painelPrincipal.add(comissaoField, gbc);
            
            JPanel painelBotoes = new JPanel(new FlowLayout());
            JButton btnCancelar = criarBotao("Cancelar", Color.GRAY);
            JButton btnSalvar = criarBotao("Criar Contrato", COR_PRIMARIA);
            
            btnCancelar.addActionListener(e -> dialog.dispose());
            
            btnSalvar.addActionListener(e -> {
                try {
                    Cliente clienteSelecionado = (Cliente) comboCliente.getSelectedItem();
                    imovel imovelSelecionado = (imovel) comboImovel.getSelectedItem();
                    double desconto = Double.parseDouble(descontoField.getText()) / 100.0;
                    double comissao = Double.parseDouble(comissaoField.getText()) / 100.0;
                    
                    JOptionPane.showMessageDialog(dialog, "Funcionalidade de contrato em desenvolvimento!");
                    dialog.dispose();
                    
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(dialog, "Erro: " + ex.getMessage());
                }
            });
            
            painelBotoes.add(btnCancelar);
            painelBotoes.add(btnSalvar);
            
            dialog.add(painelPrincipal, BorderLayout.CENTER);
            dialog.add(painelBotoes, BorderLayout.SOUTH);
            
            dialog.setVisible(true);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Erro ao criar contrato: " + e.getMessage(),
                "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void visualizarCliente() {
        try {
            String nomeCliente = JOptionPane.showInputDialog(
                this,
                "Digite o nome do cliente para visualizar detalhes completos:",
                "Visualizar Cliente",
                JOptionPane.QUESTION_MESSAGE
            );
            
            if (nomeCliente == null || nomeCliente.trim().isEmpty()) {
                return;
            }
            
            Cliente cliente = controladorCentral.buscarClientePorNome(nomeCliente.trim());
            
            if (cliente != null) {
                // Criar janela de visualização detalhada
                JDialog dialog = new JDialog((JFrame)parentFrame, "Detalhes do Cliente", true);
                dialog.setSize(450, 350);
                dialog.setLocationRelativeTo(parentFrame);
                dialog.setLayout(new BorderLayout());
                
                JPanel painelInfo = new JPanel();
                painelInfo.setLayout(new BoxLayout(painelInfo, BoxLayout.Y_AXIS));
                painelInfo.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
                
                painelInfo.add(criarLabelInfo("👤 Nome:", cliente.getNome()));
                painelInfo.add(Box.createVerticalStrut(10));
                painelInfo.add(criarLabelInfo("📧 Email:", cliente.getEmail()));
                painelInfo.add(Box.createVerticalStrut(10));
                painelInfo.add(criarLabelInfo("📞 Telefone:", cliente.getTelefone()));
                painelInfo.add(Box.createVerticalStrut(10));
                painelInfo.add(criarLabelInfo("📍 Endereço:", cliente.getEndereco()));
                painelInfo.add(Box.createVerticalStrut(10));
                painelInfo.add(criarLabelInfo("👫 Gênero:", cliente.getGenero() != null ? cliente.getGenero().toString() : "Não informado"));
                
                JButton btnFechar = criarBotao("Fechar", Color.GRAY);
                btnFechar.addActionListener(e -> dialog.dispose());
                
                JPanel painelBotao = new JPanel();
                painelBotao.add(btnFechar);
                
                dialog.add(painelInfo, BorderLayout.CENTER);
                dialog.add(painelBotao, BorderLayout.SOUTH);
                
                dialog.setVisible(true);
                
            } else {
                JOptionPane.showMessageDialog(this,
                    "❌ Cliente não encontrado!\n\n" +
                    "Nome buscado: " + nomeCliente + "\n\n" +
                    "Dicas:\n" +
                    "• Verifique se o nome está correto\n" +
                    "• A busca é case-sensitive\n" +
                    "• Use o nome completo cadastrado",
                    "Cliente Não Encontrado",
                    JOptionPane.WARNING_MESSAGE);
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Erro ao visualizar cliente: " + e.getMessage(),
                "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private JPanel criarLabelInfo(String titulo, String valor) {
        JPanel painel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel lblTitulo = new JLabel(titulo);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 12));
        JLabel lblValor = new JLabel(valor);
        lblValor.setFont(new Font("Arial", Font.PLAIN, 12));
        
        painel.add(lblTitulo);
        painel.add(lblValor);
        return painel;
    }
}