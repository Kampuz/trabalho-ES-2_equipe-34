package Interface;

import Controle.ControladorCentral;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class PainelRelatorios extends JPanel {
    
    private ControladorCentral controladorCentral;
    private JFrame parentFrame;
    private static final Color COR_PRIMARIA = new Color(41, 98, 255);
    
    public PainelRelatorios(ControladorCentral controlador, JFrame parent) {
        this.controladorCentral = controlador;
        this.parentFrame = parent;
        criarInterface();
    }
    
    private void criarInterface() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Painel principal com relatórios
        JPanel painelPrincipal = new JPanel(new GridLayout(1, 3, 20, 20));
        
        JPanel relImoveis = criarCardRelatorio("Relatório de Imóveis", 
            "Listagem completa de imóveis cadastrados", 
            e -> gerarRelatorioImoveis());
        
        JPanel relFinanceiro = criarCardRelatorio("Relatório Financeiro", 
            "Receitas, despesas e comissões do período", 
            e -> gerarRelatorioFinanceiro());
        
        JPanel relContratos = criarCardRelatorio("Relatório de Contratos", 
            "Contratos ativos, vencidos e renovações", 
            e -> gerarRelatorioContratos());
        
        painelPrincipal.add(relImoveis);
        painelPrincipal.add(relFinanceiro);
        painelPrincipal.add(relContratos);
        
        add(painelPrincipal, BorderLayout.CENTER);
    }
    
    private JPanel criarCardRelatorio(String titulo, String descricao, ActionListener acao) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1));
        card.setBackground(Color.WHITE);
        
        JLabel lblTitulo = new JLabel(titulo);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 14));
        lblTitulo.setBorder(BorderFactory.createEmptyBorder(10, 10, 5, 10));
        
        JLabel lblDescricao = new JLabel("<html>" + descricao + "</html>");
        lblDescricao.setFont(new Font("Arial", Font.PLAIN, 11));
        lblDescricao.setBorder(BorderFactory.createEmptyBorder(0, 10, 10, 10));
        
        JButton btnGerar = criarBotao("Gerar Relatório", COR_PRIMARIA);
        btnGerar.addActionListener(acao);
        
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        btnPanel.add(btnGerar);
        
        card.add(lblTitulo, BorderLayout.NORTH);
        card.add(lblDescricao, BorderLayout.CENTER);
        card.add(btnPanel, BorderLayout.SOUTH);
        
        return card;
    }
    
    private JButton criarBotao(String texto, Color cor) {
        JButton botao = new JButton(texto);
        botao.setBackground(cor);
        botao.setForeground(Color.WHITE);
        botao.setFont(new Font("Arial", Font.BOLD, 12));
        botao.setFocusPainted(false);
        botao.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16));
        botao.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        botao.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                botao.setBackground(cor.darker());
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                botao.setBackground(cor);
            }
        });
        
        return botao;
    }
    
    private void gerarRelatorioImoveis() {
        try {
            String relatorio = controladorCentral.consultaListagem(2);
            
            if (relatorio == null || relatorio.trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Nenhum imóvel cadastrado para gerar relatório.");
                return;
            }
            
            JTextArea areaTexto = new JTextArea("=== RELATÓRIO DE IMÓVEIS ===\n\n" + relatorio);
            areaTexto.setEditable(false);
            areaTexto.setFont(new Font("Courier New", Font.PLAIN, 12));
            
            JScrollPane scrollPane = new JScrollPane(areaTexto);
            scrollPane.setPreferredSize(new Dimension(600, 400));
            
            JOptionPane.showMessageDialog(this, scrollPane, "Relatório de Imóveis", JOptionPane.INFORMATION_MESSAGE);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Erro ao gerar relatório de imóveis: " + e.getMessage(), 
                "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void gerarRelatorioFinanceiro() {
        try {
            String custosRelatorio = controladorCentral.gerarRelatorioCustosMensais();
            String geralRelatorio = controladorCentral.gerarRelatorioGeral();
            
            StringBuilder relatorioCompleto = new StringBuilder();
            relatorioCompleto.append("=== RELATÓRIO FINANCEIRO COMPLETO ===\n\n");
            
            relatorioCompleto.append("--- CUSTOS MENSAIS ---\n");
            if (custosRelatorio != null && !custosRelatorio.trim().isEmpty()) {
                relatorioCompleto.append(custosRelatorio);
            } else {
                relatorioCompleto.append("Nenhum custo registrado no sistema.\n");
            }
            
            relatorioCompleto.append("\n--- RELATÓRIO GERAL ---\n");
            if (geralRelatorio != null && !geralRelatorio.trim().isEmpty()) {
                relatorioCompleto.append(geralRelatorio);
            } else {
                relatorioCompleto.append("Nenhum dado geral disponível no sistema.\n");
            }
            
            // Adicionar informações de cobranças pendentes
            relatorioCompleto.append("\n--- COBRANÇAS PENDENTES ---\n");
            try {
                var cobrancasAluguel = controladorCentral.listarCobrancasAluguelPendentes();
                var cobrancasMulta = controladorCentral.listarCobrancasMultaPendentes();
                
                relatorioCompleto.append("Cobranças de Aluguel Pendentes: ").append(cobrancasAluguel.size()).append("\n");
                relatorioCompleto.append("Cobranças de Multa Pendentes: ").append(cobrancasMulta.size()).append("\n");
                
                if (!cobrancasAluguel.isEmpty()) {
                    relatorioCompleto.append("\nDetalhes das Cobranças de Aluguel:\n");
                    for (var cobranca : cobrancasAluguel) {
                        relatorioCompleto.append("- ID: ").append(cobranca.getId())
                                        .append(", Valor: R$ ").append(String.format("%.2f", cobranca.getValorAluguel()))
                                        .append(", Status: ").append(cobranca.isPago() ? "Pago" : "Pendente")
                                        .append("\n");
                    }
                }
                
                if (!cobrancasMulta.isEmpty()) {
                    relatorioCompleto.append("\nDetalhes das Cobranças de Multa:\n");
                    for (var cobranca : cobrancasMulta) {
                        relatorioCompleto.append("- ID: ").append(cobranca.getId())
                                        .append(", Valor Adicional: R$ ").append(String.format("%.2f", cobranca.getValorAdicional()))
                                        .append(", Dias Atraso: ").append(cobranca.getDiasAtraso())
                                        .append(", Status: ").append(cobranca.isPago() ? "Pago" : "Pendente")
                                        .append("\n");
                    }
                }
                
            } catch (Exception e) {
                relatorioCompleto.append("Erro ao carregar cobranças pendentes: ").append(e.getMessage()).append("\n");
            }
            
            JTextArea areaTexto = new JTextArea(relatorioCompleto.toString());
            areaTexto.setEditable(false);
            areaTexto.setFont(new Font("Courier New", Font.PLAIN, 12));
            
            JScrollPane scrollPane = new JScrollPane(areaTexto);
            scrollPane.setPreferredSize(new Dimension(800, 500));
            
            JOptionPane.showMessageDialog(this, scrollPane, "Relatório Financeiro", JOptionPane.INFORMATION_MESSAGE);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Erro ao gerar relatório financeiro: " + e.getMessage(), 
                "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void gerarRelatorioContratos() {
        try {
            StringBuilder relatorio = new StringBuilder();
            relatorio.append("=== RELATÓRIO DE CONTRATOS ===\n\n");
            
            // Verificar contratos através da consulta de listagem
            String clientesInfo = controladorCentral.consultaListagem(0);
            String funcionariosInfo = controladorCentral.consultaListagem(1);
            String imoveisInfo = controladorCentral.consultaListagem(2);
            
            relatorio.append("--- RESUMO GERAL ---\n");
            
            // Contar entidades no sistema
            int numClientes = contarLinhas(clientesInfo);
            int numFuncionarios = contarLinhas(funcionariosInfo);
            int numImoveis = contarLinhas(imoveisInfo);
            
            relatorio.append("Total de Clientes: ").append(numClientes).append("\n");
            relatorio.append("Total de Funcionários: ").append(numFuncionarios).append("\n");
            relatorio.append("Total de Imóveis: ").append(numImoveis).append("\n\n");
            
            // Análise de contratos potenciais
            relatorio.append("--- ANÁLISE DE CONTRATOS ---\n");
            if (numClientes > 0 && numImoveis > 0) {
                relatorio.append("✅ Sistema pronto para criação de contratos\n");
                relatorio.append("- Clientes disponíveis para locação: ").append(numClientes).append("\n");
                relatorio.append("- Imóveis disponíveis para contrato: ").append(numImoveis).append("\n");
            } else {
                relatorio.append("❌ Sistema não possui dados suficientes para contratos\n");
                if (numClientes == 0) relatorio.append("- Cadastre clientes primeiro\n");
                if (numImoveis == 0) relatorio.append("- Cadastre imóveis primeiro\n");
            }
            
            JTextArea areaTexto = new JTextArea(relatorio.toString());
            areaTexto.setEditable(false);
            areaTexto.setFont(new Font("Courier New", Font.PLAIN, 12));
            
            JScrollPane scrollPane = new JScrollPane(areaTexto);
            scrollPane.setPreferredSize(new Dimension(700, 450));
            
            JOptionPane.showMessageDialog(this, scrollPane, "Relatório de Contratos", JOptionPane.INFORMATION_MESSAGE);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Erro ao gerar relatório de contratos: " + e.getMessage(), 
                "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private int contarLinhas(String texto) {
        if (texto == null || texto.trim().isEmpty()) return 0;
        return texto.split("\n").length;
    }
}
