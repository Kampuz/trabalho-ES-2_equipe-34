package Interface;

import Controle.ControladorCentral;
import Conceitos.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class FormularioCadastroImovelRequisitos extends JDialog {
    
    private SistemaImobiliarioGUI parent;
    private ControladorCentral controladorCentral;
    
    private JTextField txtNome;
    private JTextField txtClienteProprietario;
    private JCheckBox chkOcupado;
    private JComboBox<EnumImovel> cboTipo;
    private JTextField txtIndiceLaudoTecnico;
    private JTextField txtIndiceLaudoVistoria;
    
    public FormularioCadastroImovelRequisitos(SistemaImobiliarioGUI parent) {
        super(parent, "Cadastro de Imóvel - Conforme RF_Ca3.2", true);
        this.parent = parent;
        this.controladorCentral = parent.getControladorCentral();
        
        configurarDialog();
        criarInterface();
        preencherDadosTeste();
    }
    
    private void configurarDialog() {
        setSize(600, 500);
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    }
    
    private void criarInterface() {
        setLayout(new BorderLayout());
        
        JPanel cabecalho = new JPanel();
        cabecalho.setBackground(new Color(41, 98, 255));
        cabecalho.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        
        JLabel titulo = new JLabel("Cadastro de Imóvel - RF_Ca3.2");
        titulo.setFont(new Font("Arial", Font.BOLD, 18));
        titulo.setForeground(Color.WHITE);
        cabecalho.add(titulo);
        
        add(cabecalho, BorderLayout.NORTH);
        
        JPanel formulario = criarFormulario();
        JScrollPane scroll = new JScrollPane(formulario);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        add(scroll, BorderLayout.CENTER);
        
        JPanel botoes = criarPainelBotoes();
        add(botoes, BorderLayout.SOUTH);
    }
    
    private JPanel criarFormulario() {
        JPanel painel = new JPanel(new GridBagLayout());
        painel.setBorder(BorderFactory.createEmptyBorder(20, 20, 10, 20));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.WEST;
        
        int linha = 0;
        
        
        
        gbc.gridx = 0; gbc.gridy = linha; gbc.weightx = 0; gbc.fill = GridBagConstraints.NONE;
        JLabel lblNome = new JLabel("Nome do Imóvel:*");
        lblNome.setForeground(Color.RED);
        lblNome.setFont(new Font("Arial", Font.BOLD, 14));
        painel.add(lblNome, gbc);
        
        txtNome = new JTextField(30);
        txtNome.setToolTipText("Nome identificador do imóvel (obrigatório)");
        gbc.gridx = 1; gbc.weightx = 1; gbc.fill = GridBagConstraints.HORIZONTAL;
        painel.add(txtNome, gbc);
        
        linha++;
        
        gbc.gridx = 0; gbc.gridy = linha; gbc.weightx = 0; gbc.fill = GridBagConstraints.NONE;
        JLabel lblCliente = new JLabel("Cliente Proprietário:*");
        lblCliente.setForeground(Color.RED);
        lblCliente.setFont(new Font("Arial", Font.BOLD, 14));
        painel.add(lblCliente, gbc);
        
        txtClienteProprietario = new JTextField(30);
        txtClienteProprietario.setToolTipText("Nome do cliente proprietário (deve estar cadastrado no sistema)");
        gbc.gridx = 1; gbc.weightx = 1; gbc.fill = GridBagConstraints.HORIZONTAL;
        painel.add(txtClienteProprietario, gbc);
        
        linha++;
        
        gbc.gridx = 0; gbc.gridy = linha; gbc.weightx = 0; gbc.fill = GridBagConstraints.NONE;
        JLabel lblOcupado = new JLabel("Status:*");
        lblOcupado.setFont(new Font("Arial", Font.BOLD, 14));
        painel.add(lblOcupado, gbc);
        
        chkOcupado = new JCheckBox("Imóvel está ocupado");
        chkOcupado.setToolTipText("Marque se o imóvel está ocupado atualmente");
        chkOcupado.setFont(new Font("Arial", Font.PLAIN, 12));
        gbc.gridx = 1; gbc.weightx = 1; gbc.fill = GridBagConstraints.HORIZONTAL;
        painel.add(chkOcupado, gbc);
        
        linha++;
        
        gbc.gridx = 0; gbc.gridy = linha; gbc.weightx = 0; gbc.fill = GridBagConstraints.NONE;
        JLabel lblTipo = new JLabel("Tipo do Imóvel:*");
        lblTipo.setFont(new Font("Arial", Font.BOLD, 14));
        painel.add(lblTipo, gbc);
        
        cboTipo = new JComboBox<>(EnumImovel.values());
        cboTipo.setToolTipText("Selecione: CASA, APARTAMENTO ou CHACARA");
        gbc.gridx = 1; gbc.weightx = 1; gbc.fill = GridBagConstraints.HORIZONTAL;
        painel.add(cboTipo, gbc);
        
        linha++;
        
        gbc.gridx = 0; gbc.gridy = linha; gbc.weightx = 0; gbc.fill = GridBagConstraints.NONE;
        JLabel lblLaudoTec = new JLabel("Índice Laudo Técnico:*");
        lblLaudoTec.setForeground(Color.RED);
        lblLaudoTec.setFont(new Font("Arial", Font.BOLD, 14));
        painel.add(lblLaudoTec, gbc);
        
        txtIndiceLaudoTecnico = new JTextField(30);
        txtIndiceLaudoTecnico.setToolTipText("Índice do laudo técnico (0, 1, 2...) - deve existir no sistema");
        gbc.gridx = 1; gbc.weightx = 1; gbc.fill = GridBagConstraints.HORIZONTAL;
        painel.add(txtIndiceLaudoTecnico, gbc);
        
        linha++;
        
        gbc.gridx = 0; gbc.gridy = linha; gbc.weightx = 0; gbc.fill = GridBagConstraints.NONE;
        JLabel lblLaudoVist = new JLabel("Índice Laudo Vistoria:");
        lblLaudoVist.setFont(new Font("Arial", Font.BOLD, 14));
        painel.add(lblLaudoVist, gbc);
        
        txtIndiceLaudoVistoria = new JTextField(30);
        txtIndiceLaudoVistoria.setToolTipText("Índice do laudo de vistoria (OPCIONAL - deixe vazio se não houver)");
        gbc.gridx = 1; gbc.weightx = 1; gbc.fill = GridBagConstraints.HORIZONTAL;
        painel.add(txtIndiceLaudoVistoria, gbc);
        
        linha++;
        
        gbc.gridx = 0; gbc.gridy = linha; gbc.gridwidth = 2; gbc.weightx = 1; gbc.fill = GridBagConstraints.HORIZONTAL;
        JPanel separador = new JPanel(new BorderLayout());
        separador.setBorder(BorderFactory.createTitledBorder("RF_Ca3.2 - Requisitos do Sistema"));
        
        JTextArea infoArea = new JTextArea(5, 50);
        infoArea.setEditable(false);
        infoArea.setOpaque(false);
        infoArea.setFont(new Font("Arial", Font.ITALIC, 11));
        infoArea.setText(
            "REQUISITOS OBRIGATÓRIOS (Documento de Requisitos - RF_Ca3.2):\n" +
            "✓ Nome não vazio  ✓ Cliente não vazio  ✓ Ocupado (true/false)\n" +
            "✓ Tipo (casa/apartamento/chácara)  ✓ Laudo técnico não vazio\n" + 
            "◦ Laudo vistoria (OPCIONAL - pode ficar vazio)\n" +
            "DADOS DISPONÍVEIS: Clientes: João Silva Demo, Maria Santos Demo | Laudos: 0, 1"
        );
        separador.add(infoArea, BorderLayout.CENTER);
        
        painel.add(separador, gbc);
        gbc.gridwidth = 1; // reset
        
        return painel;
    }
    
    private JPanel criarPainelBotoes() {
        JPanel painel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        painel.setBorder(BorderFactory.createEmptyBorder(10, 20, 20, 20));
        
        JButton btnLimpar = new JButton("Limpar");
        btnLimpar.addActionListener(e -> limparFormulario());
        
        JButton btnCancelar = new JButton("Cancelar");
        btnCancelar.addActionListener(e -> dispose());
        
        JButton btnSalvar = new JButton("Cadastrar Imóvel");
        btnSalvar.setBackground(new Color(34, 197, 94));
        btnSalvar.setForeground(Color.WHITE);
        btnSalvar.setFont(new Font("Arial", Font.BOLD, 12));
        btnSalvar.addActionListener(e -> cadastrarImovel());
        
        painel.add(btnLimpar);
        painel.add(btnCancelar);
        painel.add(btnSalvar);
        
        return painel;
    }
    
    private void preencherDadosTeste() {
        txtNome.setText("Casa Residencial Exemplo");        // Nome do imóvel
        txtClienteProprietario.setText("João Silva Demo");  // Cliente que sabemos que existe
        chkOcupado.setSelected(false);                       // Imóvel não ocupado 
        cboTipo.setSelectedItem(EnumImovel.CASA);           // Tipo casa
        txtIndiceLaudoTecnico.setText("0");                  // Primeiro laudo técnico (índice 0)
        txtIndiceLaudoVistoria.setText("");                  // Vazio - campo opcional
    }
    
    private void limparFormulario() {
        txtNome.setText("");
        txtClienteProprietario.setText("");
        chkOcupado.setSelected(false);
        cboTipo.setSelectedIndex(0);
        txtIndiceLaudoTecnico.setText("");
        txtIndiceLaudoVistoria.setText("");
        txtNome.requestFocus();
    }
    
    private void cadastrarImovel() {
        try {
            
            if (!validarCamposObrigatorios()) {
                return;
            }
            
            String nome = txtNome.getText().trim();
            String clienteProprietario = txtClienteProprietario.getText().trim();
            boolean ocupado = chkOcupado.isSelected();
            EnumImovel tipo = (EnumImovel) cboTipo.getSelectedItem();
            
            int indiceLaudoTecnico = Integer.parseInt(txtIndiceLaudoTecnico.getText().trim());
            
            int indiceLaudoVistoria = -1;
            String laudoVistoriaText = txtIndiceLaudoVistoria.getText().trim();
            if (!laudoVistoriaText.isEmpty()) {
                indiceLaudoVistoria = Integer.parseInt(laudoVistoriaText);
            }
            
            boolean sucesso = controladorCentral.registrarImovel(
                nome,
                clienteProprietario,
                tipo,
                ocupado,
                indiceLaudoTecnico,
                indiceLaudoVistoria,
                null
            );
            
            if (sucesso) {
                String laudoVistoriaInfo = (indiceLaudoVistoria >= 0) ? 
                    "Laudo Vistoria: " + indiceLaudoVistoria : 
                    "Laudo Vistoria: Não informado";
                
                JOptionPane.showMessageDialog(this,
                    "Imóvel cadastrado com sucesso conforme RF_Ca3.2!\n" +
                    "Nome: " + nome + "\n" +
                    "Proprietário: " + clienteProprietario + "\n" +
                    "Ocupado: " + (ocupado ? "Sim" : "Não") + "\n" +
                    "Tipo: " + tipo + "\n" +
                    "Laudo Técnico: " + indiceLaudoTecnico + "\n" +
                    laudoVistoriaInfo,
                    "Sucesso",
                    JOptionPane.INFORMATION_MESSAGE);
                
                limparFormulario();
                
                if (parent != null) {
                    parent.atualizarInterface();
                }
                
            } else {
                JOptionPane.showMessageDialog(this,
                    "Erro ao cadastrar imóvel!\n\n" +
                    "Verifique se:\n" +
                    "• Cliente proprietário está cadastrado no sistema\n" +
                    "• Índices dos laudos existem no sistema\n" +
                    "• Todos os campos obrigatórios foram preenchidos",
                    "Erro",
                    JOptionPane.ERROR_MESSAGE);
            }
            
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this,
                "Índices dos laudos devem ser números válidos!",
                "Erro de Validação",
                JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Erro inesperado: " + e.getMessage(),
                "Erro",
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private boolean validarCamposObrigatorios() {
        if (txtNome.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "Campo 'Nome do Imóvel' é obrigatório! (RF_Ca3.2)",
                "Erro de Validação",
                JOptionPane.ERROR_MESSAGE);
            txtNome.requestFocus();
            return false;
        }
        
        if (txtClienteProprietario.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "Campo 'Cliente Proprietário' é obrigatório! (RF_Ca3.2)",
                "Erro de Validação",
                JOptionPane.ERROR_MESSAGE);
            txtClienteProprietario.requestFocus();
            return false;
        }
        
        if (txtIndiceLaudoTecnico.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "Campo 'Índice Laudo Técnico' é obrigatório! (RF_Ca3.2)",
                "Erro de Validação",
                JOptionPane.ERROR_MESSAGE);
            txtIndiceLaudoTecnico.requestFocus();
            return false;
        }
        
        try {
            int laudoTec = Integer.parseInt(txtIndiceLaudoTecnico.getText().trim());
            
            if (laudoTec < 0) {
                JOptionPane.showMessageDialog(this,
                    "Índice do laudo técnico deve ser número positivo (0, 1, 2...)!",
                    "Erro de Validação",
                    JOptionPane.ERROR_MESSAGE);
                return false;
            }
            
            String laudoVistoriaText = txtIndiceLaudoVistoria.getText().trim();
            if (!laudoVistoriaText.isEmpty()) {
                int laudoVist = Integer.parseInt(laudoVistoriaText);
                if (laudoVist < 0) {
                    JOptionPane.showMessageDialog(this,
                        "Índice do laudo de vistoria deve ser número positivo (0, 1, 2...) ou deixe vazio!",
                        "Erro de Validação",
                        JOptionPane.ERROR_MESSAGE);
                    return false;
                }
            }
            
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this,
                "Índices dos laudos devem ser números válidos!\n" +
                "Laudo técnico: obrigatório\n" +
                "Laudo vistoria: opcional (deixe vazio se não houver)",
                "Erro de Validação",
                JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        return true;
    }
}