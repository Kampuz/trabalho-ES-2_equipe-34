package Interface;

import Controle.ControladorCentral;
import Conceitos.*;
import Catalogos.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.List;

public class PainelPagamentos extends JPanel {
    
    private ControladorCentral controladorCentral;
    private JFrame parentFrame;
    private static final Color COR_PRIMARIA = new Color(41, 98, 255);
    private static final Color COR_SUCESSO = new Color(40, 167, 69);
    
    public PainelPagamentos(ControladorCentral controlador, JFrame parent) {
        this.controladorCentral = controlador;
        this.parentFrame = parent;
        criarInterface();
    }
    
    private void criarInterface() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        JLabel titulo = new JLabel("💳 Sistema de Pagamentos", JLabel.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 18));
        titulo.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));
        
        JPanel botoes = new JPanel(new GridLayout(3, 2, 10, 10));
        
        JButton btnPagarAluguel = criarBotao("💰 Pagar Aluguel", COR_SUCESSO);
        JButton btnPagarMulta = criarBotao("💸 Pagar Multa", COR_SUCESSO);
        JButton btnListarPendentes = criarBotao("📋 Listar Pendências", new Color(0, 123, 255));
        
        JButton btnEditarAluguel = criarBotao("✏️ Editar Cobrança Aluguel", new Color(255, 140, 0));
        JButton btnEditarMulta = criarBotao("✏️ Editar Cobrança Multa", new Color(255, 140, 0));
        JButton btnCriarCobrancaTeste = criarBotao("🧪 Criar Cobrança Teste", Color.GRAY);
        
        btnPagarAluguel.addActionListener(e -> processarPagamentoAluguel());
        btnPagarMulta.addActionListener(e -> processarPagamentoMulta());
        btnListarPendentes.addActionListener(e -> listarCobrancasPendentes());
        btnEditarAluguel.addActionListener(e -> editarCobrancaAluguel());
        btnEditarMulta.addActionListener(e -> editarCobrancaMulta());
        btnCriarCobrancaTeste.addActionListener(e -> criarCobrancasTeste());
        
        botoes.add(btnPagarAluguel);
        botoes.add(btnPagarMulta);
        botoes.add(btnListarPendentes);
        botoes.add(btnEditarAluguel);
        botoes.add(btnEditarMulta);
        botoes.add(btnCriarCobrancaTeste);
        
        add(titulo, BorderLayout.NORTH);
        add(botoes, BorderLayout.CENTER);
    }
    
    private JButton criarBotao(String texto, Color cor) {
        JButton botao = new JButton(texto);
        botao.setBackground(cor);
        botao.setForeground(Color.WHITE);
        botao.setFont(new Font("Arial", Font.BOLD, 12));
        botao.setFocusPainted(false);
        botao.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16));
        botao.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        botao.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                botao.setBackground(cor.darker());
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                botao.setBackground(cor);
            }
        });
        
        return botao;
    }
    
    private void processarPagamentoAluguel() {
        try {
            String identificador = JOptionPane.showInputDialog(
                this,
                "Digite o ID da cobrança de aluguel para processar o pagamento:\n\n" +
                "💡 Use 'Listar Pendências' para ver os IDs disponíveis\n" +
                "Formato: Digite os primeiros caracteres do UUID",
                "Processar Pagamento - Aluguel",
                JOptionPane.QUESTION_MESSAGE
            );
            
            if (identificador == null || identificador.trim().isEmpty()) {
                return;
            }
            
            boolean sucesso = controladorCentral.processarPagamentoAluguel(identificador.trim());
            
            if (sucesso) {
                JOptionPane.showMessageDialog(this,
                    "✅ Pagamento de aluguel processado com sucesso!\n\n" +
                    "ID: " + identificador + "\n" +
                    "Status: PAGO ✅",
                    "Pagamento Processado",
                    JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this,
                    "❌ Erro ao processar pagamento!\n\n" +
                    "Possíveis causas:\n" +
                    "• Cobrança não encontrada\n" +
                    "• Cobrança já está paga\n" +
                    "• ID inválido",
                    "Erro no Pagamento",
                    JOptionPane.ERROR_MESSAGE);
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Erro inesperado: " + e.getMessage(),
                "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void processarPagamentoMulta() {
        try {
            String identificador = JOptionPane.showInputDialog(
                this,
                "Digite o ID da cobrança de multa para processar o pagamento:\n\n" +
                "💡 Use 'Listar Pendências' para ver os IDs disponíveis\n" +
                "Formato: Digite os primeiros caracteres do UUID",
                "Processar Pagamento - Multa",
                JOptionPane.QUESTION_MESSAGE
            );
            
            if (identificador == null || identificador.trim().isEmpty()) {
                return;
            }
            
            boolean sucesso = controladorCentral.processarPagamentoMulta(identificador.trim());
            
            if (sucesso) {
                JOptionPane.showMessageDialog(this,
                    "✅ Pagamento de multa processado com sucesso!\n\n" +
                    "ID: " + identificador + "\n" +
                    "Status: PAGO ✅",
                    "Pagamento Processado",
                    JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this,
                    "❌ Erro ao processar pagamento!\n\n" +
                    "Possíveis causas:\n" +
                    "• Cobrança não encontrada\n" +
                    "• Cobrança já está paga\n" +
                    "• ID inválido",
                    "Erro no Pagamento",
                    JOptionPane.ERROR_MESSAGE);
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Erro inesperado: " + e.getMessage(),
                "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void listarCobrancasPendentes() {
        try {
            List<CobrancaAluguel> aluguelPendente = controladorCentral.listarCobrancasAluguelPendentes();
            List<CobrancaMulta> multaPendente = controladorCentral.listarCobrancasMultaPendentes();
            
            StringBuilder relatorio = new StringBuilder();
            relatorio.append("📋 COBRANÇAS PENDENTES\n");
            relatorio.append("=" + "=".repeat(50) + "\n\n");
            
            relatorio.append("💰 ALUGUÉIS PENDENTES:\n");
            if (aluguelPendente.isEmpty()) {
                relatorio.append("   ✅ Nenhuma cobrança de aluguel pendente!\n");
            } else {
                for (CobrancaAluguel cobranca : aluguelPendente) {
                    relatorio.append(String.format("   📋 ID: %s\n", 
                        cobranca.getId().toString().substring(0, 8) + "..."));
                    relatorio.append(String.format("      💵 Valor: R$ %.2f\n", cobranca.getValorAluguel()));
                    relatorio.append(String.format("      📅 Vencimento: %s\n", cobranca.getDiaPagamento()));
                    if (cobranca.getCliente() != null) {
                        relatorio.append(String.format("      👤 Cliente: %s\n", cobranca.getCliente().getNome()));
                    }
                    relatorio.append("\n");
                }
            }
            
            relatorio.append("\n💸 MULTAS PENDENTES:\n");
            if (multaPendente.isEmpty()) {
                relatorio.append("   ✅ Nenhuma cobrança de multa pendente!\n");
            } else {
                for (CobrancaMulta cobranca : multaPendente) {
                    relatorio.append(String.format("   📋 ID: %s\n", 
                        cobranca.getId().toString().substring(0, 8) + "..."));
                    relatorio.append(String.format("      💵 Valor Final: R$ %.2f\n", cobranca.getValorFinal()));
                    relatorio.append(String.format("      📈 Valor Base: R$ %.2f\n", cobranca.getValorAdicional()));
                    relatorio.append(String.format("      ⏰ Dias Atraso: %d\n", cobranca.getDiasAtraso()));
                    relatorio.append(String.format("      📊 Juros: %.2f%%\n", cobranca.getJuros() * 100));
                    if (cobranca.getCliente() != null) {
                        relatorio.append(String.format("      👤 Cliente: %s\n", cobranca.getCliente().getNome()));
                    }
                    relatorio.append("\n");
                }
            }
            
            relatorio.append("\n💡 Para processar pagamento, copie os primeiros 8 caracteres do ID");
            
            JTextArea areaTexto = new JTextArea(relatorio.toString());
            areaTexto.setEditable(false);
            areaTexto.setFont(new Font("Courier New", Font.PLAIN, 12));
            areaTexto.setBackground(new Color(248, 249, 250));
            
            JScrollPane scrollPane = new JScrollPane(areaTexto);
            scrollPane.setPreferredSize(new Dimension(600, 400));
            
            JOptionPane.showMessageDialog(this, scrollPane,
                "Cobranças Pendentes", JOptionPane.INFORMATION_MESSAGE);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Erro ao listar cobranças: " + e.getMessage(),
                "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void editarCobrancaAluguel() {
        try {
            String identificador = JOptionPane.showInputDialog(
                this,
                "Digite o ID da cobrança de aluguel para editar:\n\n" +
                "💡 Use 'Listar Pendências' para ver os IDs disponíveis",
                "Editar Cobrança de Aluguel",
                JOptionPane.QUESTION_MESSAGE
            );
            
            if (identificador == null || identificador.trim().isEmpty()) {
                return;
            }
            
            String novoValorStr = JOptionPane.showInputDialog(
                this,
                "Digite o novo valor da cobrança:\n\n" +
                "Formato: 1500.50 (use ponto para decimais)",
                "Novo Valor",
                JOptionPane.QUESTION_MESSAGE
            );
            
            if (novoValorStr == null || novoValorStr.trim().isEmpty()) {
                return;
            }
            
            Double novoValor = Double.parseDouble(novoValorStr.trim());
            
            boolean sucesso = controladorCentral.editarCobrancaAluguel(identificador.trim(), novoValor, null);
            
            if (sucesso) {
                JOptionPane.showMessageDialog(this,
                    "✅ Cobrança de aluguel editada com sucesso!\n\n" +
                    "ID: " + identificador + "\n" +
                    "Novo valor: R$ " + String.format("%.2f", novoValor),
                    "Cobrança Editada",
                    JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this,
                    "❌ Erro ao editar cobrança!\n\n" +
                    "Possíveis causas:\n" +
                    "• Cobrança não encontrada\n" +
                    "• Cobrança já está paga\n" +
                    "• ID inválido",
                    "Erro na Edição",
                    JOptionPane.ERROR_MESSAGE);
            }
            
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this,
                "Valor inválido! Use formato: 1500.50",
                "Erro", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Erro inesperado: " + e.getMessage(),
                "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void editarCobrancaMulta() {
        try {
            String identificador = JOptionPane.showInputDialog(
                this,
                "Digite o ID da cobrança de multa para editar:\n\n" +
                "💡 Use 'Listar Pendências' para ver os IDs disponíveis",
                "Editar Cobrança de Multa",
                JOptionPane.QUESTION_MESSAGE
            );
            
            if (identificador == null || identificador.trim().isEmpty()) {
                return;
            }
            
            JDialog dialog = new JDialog((JFrame)parentFrame, "Editar Multa - " + identificador.substring(0, Math.min(8, identificador.length())), true);
            dialog.setSize(400, 300);
            dialog.setLocationRelativeTo(parentFrame);
            
            JPanel panel = new JPanel(new GridBagLayout());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(10, 10, 10, 10);
            gbc.anchor = GridBagConstraints.WEST;
            
            gbc.gridx = 0; gbc.gridy = 0;
            panel.add(new JLabel("Valor Adicional:"), gbc);
            JTextField valorField = new JTextField("", 15);
            gbc.gridx = 1;
            panel.add(valorField, gbc);
            
            gbc.gridx = 0; gbc.gridy = 1;
            panel.add(new JLabel("Dias de Atraso:"), gbc);
            JTextField diasField = new JTextField("", 15);
            gbc.gridx = 1;
            panel.add(diasField, gbc);
            
            gbc.gridx = 0; gbc.gridy = 2;
            panel.add(new JLabel("Juros (0.01 = 1%):"), gbc);
            JTextField jurosField = new JTextField("", 15);
            gbc.gridx = 1;
            panel.add(jurosField, gbc);
            
            JPanel botoesPanel = new JPanel(new FlowLayout());
            JButton btnSalvar = criarBotao("Salvar", COR_PRIMARIA);
            JButton btnCancelar = criarBotao("Cancelar", Color.GRAY);
            
            btnSalvar.addActionListener(e -> {
                try {
                    Double novoValor = valorField.getText().trim().isEmpty() ? null : Double.parseDouble(valorField.getText().trim());
                    Integer novosDias = diasField.getText().trim().isEmpty() ? null : Integer.parseInt(diasField.getText().trim());
                    Double novosJuros = jurosField.getText().trim().isEmpty() ? null : Double.parseDouble(jurosField.getText().trim());
                    
                    boolean sucesso = controladorCentral.editarCobrancaMulta(identificador.trim(), novoValor, novosDias, novosJuros);
                    
                    if (sucesso) {
                        JOptionPane.showMessageDialog(dialog, "Cobrança de multa editada com sucesso!");
                        dialog.dispose();
                    } else {
                        JOptionPane.showMessageDialog(dialog, "Erro ao editar cobrança de multa!", 
                            "Erro", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(dialog, "Valores inválidos! Use números válidos.", 
                        "Erro", JOptionPane.ERROR_MESSAGE);
                }
            });
            
            btnCancelar.addActionListener(e -> dialog.dispose());
            
            botoesPanel.add(btnSalvar);
            botoesPanel.add(btnCancelar);
            
            gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
            panel.add(botoesPanel, gbc);
            
            dialog.add(panel);
            dialog.setVisible(true);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Erro inesperado: " + e.getMessage(),
                "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void criarCobrancasTeste() {
        try {
            int confirmacao = JOptionPane.showConfirmDialog(
                this,
                "Deseja criar cobranças de teste para demonstração?\n\n" +
                "Isto irá adicionar:\n" +
                "• 2 cobranças de aluguel pendentes\n" +
                "• 1 cobrança de multa pendente\n\n" +
                "Útil para testar o sistema de pagamentos.",
                "Criar Cobranças de Teste",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
            );
            
            if (confirmacao == JOptionPane.YES_OPTION) {
                Cliente clienteTeste = new Cliente("Cliente Teste - Pagamentos");
                
                CobrancaAluguel aluguel1 = new CobrancaAluguel(1500.0f, java.time.LocalDateTime.now().plusDays(5), clienteTeste);
                CobrancaAluguel aluguel2 = new CobrancaAluguel(2200.50f, java.time.LocalDateTime.now().minusDays(2), clienteTeste);
                CobrancaMulta multa1 = new CobrancaMulta(150.0, 5, 0.02, clienteTeste);
                
                boolean sucesso1 = controladorCentral.getCatalogoCliente().adicionarCobrancaAluguel(aluguel1);
                boolean sucesso2 = controladorCentral.getCatalogoCliente().adicionarCobrancaAluguel(aluguel2);
                boolean sucesso3 = controladorCentral.getCatalogoCliente().adicionarCobrancaMulta(multa1);
                
                if (sucesso1 && sucesso2 && sucesso3) {
                    JOptionPane.showMessageDialog(this,
                        "✅ Cobranças de teste criadas com sucesso!\n\n" +
                        "📋 IDs criados:\n" +
                        "Aluguel 1: " + aluguel1.getId().toString().substring(0, 8) + "...\n" +
                        "Aluguel 2: " + aluguel2.getId().toString().substring(0, 8) + "...\n" +
                        "Multa 1: " + multa1.getId().toString().substring(0, 8) + "...\n\n" +
                        "Use 'Listar Pendências' para ver detalhes.",
                        "Cobranças Criadas",
                        JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(this,
                        "❌ Erro ao criar algumas cobranças de teste",
                        "Erro", JOptionPane.ERROR_MESSAGE);
                }
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Erro ao criar cobranças de teste: " + e.getMessage(),
                "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private JPanel criarLabelInfo(String titulo, String valor) {
        JPanel painel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel lblTitulo = new JLabel(titulo);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 12));
        JLabel lblValor = new JLabel(valor);
        lblValor.setFont(new Font("Arial", Font.PLAIN, 12));
        
        painel.add(lblTitulo);
        painel.add(lblValor);
        return painel;
    }
}