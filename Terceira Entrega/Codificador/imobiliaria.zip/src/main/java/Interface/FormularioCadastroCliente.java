package Interface;

import Controle.ControladorCentral;
import Conceitos.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class FormularioCadastroCliente extends JDialog {
    
    private SistemaImobiliarioGUI parent;
    private ControladorCentral controladorCentral;
    
    private JTextField txtNome;
    private JTextField txtCPF_CNPJ;
    private JTextField txtTelefone;
    private JTextField txtEmail;
    private JTextField txtEndereco;
    private JFormattedTextField txtDataNascimento;
    private JComboBox<EnumGenero> cboGenero;
    private JTextArea txtObservacoes;
    
    public FormularioCadastroCliente(SistemaImobiliarioGUI parent) {
        super(parent, "Cadastro de Cliente", true);
        this.parent = parent;
        this.controladorCentral = parent.getControladorCentral(); // Usa a mesma instância
        
        configurarDialog();
        criarInterface();
    }
    
    private void configurarDialog() {
        setSize(500, 600);
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    }
    
    private void criarInterface() {
        setLayout(new BorderLayout());
        
        JPanel cabecalho = new JPanel();
        cabecalho.setBackground(new Color(41, 98, 255));
        cabecalho.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        
        JLabel titulo = new JLabel("Cadastro de Cliente");
        titulo.setFont(new Font("Arial", Font.BOLD, 18));
        titulo.setForeground(Color.WHITE);
        cabecalho.add(titulo);
        
        add(cabecalho, BorderLayout.NORTH);
        
        JPanel formulario = criarFormulario();
        JScrollPane scroll = new JScrollPane(formulario);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        add(scroll, BorderLayout.CENTER);
        
        JPanel botoes = criarPainelBotoes();
        add(botoes, BorderLayout.SOUTH);
    }
    
    private JPanel criarFormulario() {
        JPanel painel = new JPanel(new GridBagLayout());
        painel.setBorder(BorderFactory.createEmptyBorder(20, 20, 10, 20));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 5, 8, 5);
        gbc.anchor = GridBagConstraints.WEST;
        
        int linha = 0;
        
        gbc.gridx = 0; gbc.gridy = linha; gbc.weightx = 0;
        painel.add(new JLabel("Nome Completo:*"), gbc);
        
        txtNome = new JTextField();
        txtNome.setPreferredSize(new Dimension(300, 25));
        gbc.gridx = 1; gbc.weightx = 1; gbc.fill = GridBagConstraints.HORIZONTAL;
        painel.add(txtNome, gbc);
        
        linha++;
        
        gbc.gridx = 0; gbc.gridy = linha; gbc.weightx = 0; gbc.fill = GridBagConstraints.NONE;
        painel.add(new JLabel("CPF/CNPJ:*"), gbc);
        
        txtCPF_CNPJ = new JTextField();
        txtCPF_CNPJ.setToolTipText("Digite apenas números");
        gbc.gridx = 1; gbc.weightx = 1; gbc.fill = GridBagConstraints.HORIZONTAL;
        painel.add(txtCPF_CNPJ, gbc);
        
        linha++;
        
        gbc.gridx = 0; gbc.gridy = linha; gbc.weightx = 0; gbc.fill = GridBagConstraints.NONE;
        painel.add(new JLabel("Data de Nascimento:"), gbc);
        
        try {
            txtDataNascimento = new JFormattedTextField(
                new javax.swing.text.MaskFormatter("##/##/####")
            );
            txtDataNascimento.setToolTipText("DD/MM/AAAA");
        } catch (Exception e) {
            txtDataNascimento = new JFormattedTextField();
        }
        
        gbc.gridx = 1; gbc.weightx = 1; gbc.fill = GridBagConstraints.HORIZONTAL;
        painel.add(txtDataNascimento, gbc);
        
        linha++;
        
        gbc.gridx = 0; gbc.gridy = linha; gbc.weightx = 0; gbc.fill = GridBagConstraints.NONE;
        painel.add(new JLabel("Gênero:"), gbc);
        
        cboGenero = new JComboBox<>(EnumGenero.values());
        gbc.gridx = 1; gbc.weightx = 1; gbc.fill = GridBagConstraints.HORIZONTAL;
        painel.add(cboGenero, gbc);
        
        linha++;
        
        gbc.gridx = 0; gbc.gridy = linha; gbc.weightx = 0; gbc.fill = GridBagConstraints.NONE;
        painel.add(new JLabel("Telefone:*"), gbc);
        
        txtTelefone = new JTextField();
        txtTelefone.setToolTipText("Formato: (11) 99999-9999");
        gbc.gridx = 1; gbc.weightx = 1; gbc.fill = GridBagConstraints.HORIZONTAL;
        painel.add(txtTelefone, gbc);
        
        linha++;
        
        gbc.gridx = 0; gbc.gridy = linha; gbc.weightx = 0; gbc.fill = GridBagConstraints.NONE;
        painel.add(new JLabel("Email:*"), gbc);
        
        txtEmail = new JTextField();
        txtEmail.setToolTipText("exemplo@email.com");
        gbc.gridx = 1; gbc.weightx = 1; gbc.fill = GridBagConstraints.HORIZONTAL;
        painel.add(txtEmail, gbc);
        
        linha++;
        
        gbc.gridx = 0; gbc.gridy = linha; gbc.weightx = 0; gbc.fill = GridBagConstraints.NONE;
        painel.add(new JLabel("Endereço:"), gbc);
        
        txtEndereco = new JTextField();
        gbc.gridx = 1; gbc.weightx = 1; gbc.fill = GridBagConstraints.HORIZONTAL;
        painel.add(txtEndereco, gbc);
        
        linha++;
        
        gbc.gridx = 0; gbc.gridy = linha; gbc.weightx = 0; gbc.fill = GridBagConstraints.NONE;
        painel.add(new JLabel("Observações:"), gbc);
        
        txtObservacoes = new JTextArea(4, 30);
        txtObservacoes.setLineWrap(true);
        txtObservacoes.setWrapStyleWord(true);
        txtObservacoes.setBorder(BorderFactory.createLoweredBevelBorder());
        
        JScrollPane scrollObservacoes = new JScrollPane(txtObservacoes);
        gbc.gridx = 1; gbc.weightx = 1; gbc.fill = GridBagConstraints.BOTH;
        gbc.weighty = 1;
        painel.add(scrollObservacoes, gbc);
        
        linha++;
        gbc.gridx = 0; gbc.gridy = linha; gbc.gridwidth = 2; gbc.weighty = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        JLabel nota = new JLabel("* Campos obrigatórios");
        nota.setFont(new Font("Arial", Font.ITALIC, 11));
        nota.setForeground(Color.GRAY);
        painel.add(nota, gbc);
        
        return painel;
    }
    
    private JPanel criarPainelBotoes() {
        JPanel painel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        painel.setBorder(BorderFactory.createEmptyBorder(10, 20, 20, 20));
        
        JButton btnLimpar = new JButton("Limpar");
        btnLimpar.addActionListener(e -> limparFormulario());
        
        JButton btnCancelar = new JButton("Cancelar");
        btnCancelar.addActionListener(e -> dispose());
        
        JButton btnSalvar = new JButton("Cadastrar Cliente");
        btnSalvar.setBackground(new Color(34, 197, 94));
        btnSalvar.setForeground(Color.WHITE);
        btnSalvar.setFont(new Font("Arial", Font.BOLD, 12));
        btnSalvar.addActionListener(e -> cadastrarCliente());
        
        painel.add(btnLimpar);
        painel.add(btnCancelar);
        painel.add(btnSalvar);
        
        return painel;
    }
    
    private void limparFormulario() {
        txtNome.setText("");
        txtCPF_CNPJ.setText("");
        txtTelefone.setText("");
        txtEmail.setText("");
        txtEndereco.setText("");
        txtDataNascimento.setText("");
        txtObservacoes.setText("");
        
        cboGenero.setSelectedIndex(0);
        txtNome.requestFocus();
    }
    
    private void cadastrarCliente() {
        try {
            if (!validarCampos()) {
                return;
            }
            
            String nome = txtNome.getText().trim();
            String cpfCnpj = txtCPF_CNPJ.getText().trim().replaceAll("[^0-9]", "");
            String telefone = txtTelefone.getText().trim();
            String email = txtEmail.getText().trim();
            String endereco = txtEndereco.getText().trim();
            EnumGenero genero = (EnumGenero) cboGenero.getSelectedItem();
            
            LocalDateTime dataNascimento = null;
            if (!txtDataNascimento.getText().trim().isEmpty()) {
                String dataStr = txtDataNascimento.getText().trim();
                if (dataStr.length() == 10) {
                    try {
                        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                        dataNascimento = LocalDateTime.parse(dataStr + " 00:00:00", 
                            DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"));
                    } catch (Exception e) {
                        mostrarErroValidacao("Data de nascimento inválida. Use o formato DD/MM/AAAA.");
                        txtDataNascimento.requestFocus();
                        return;
                    }
                }
            }
            
            boolean sucesso = false;
            if (dataNascimento != null) {
                sucesso = controladorCentral.registrarCliente(
                    nome, dataNascimento, cpfCnpj, telefone, 
                    email, endereco, genero, null // Graphics2D não implementado nesta versão
                );
            } else {
                controladorCentral.registrarCliente(nome, email, telefone);
                sucesso = true; // Método void, assumir sucesso
            }
            
            if (sucesso) {
                JOptionPane.showMessageDialog(this,
                    "Cliente cadastrado com sucesso!",
                    "Sucesso",
                    JOptionPane.INFORMATION_MESSAGE);
                
                limparFormulario();
                
                if (parent != null) {
                    parent.atualizarInterface();
                }
                
            } else {
                JOptionPane.showMessageDialog(this,
                    "Erro ao cadastrar cliente. Verifique os dados informados.",
                    "Erro",
                    JOptionPane.ERROR_MESSAGE);
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Erro inesperado: " + e.getMessage(),
                "Erro",
                JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
    
    private boolean validarCampos() {
        if (txtNome.getText().trim().isEmpty()) {
            mostrarErroValidacao("O campo 'Nome Completo' é obrigatório.");
            txtNome.requestFocus();
            return false;
        }
        
        if (txtNome.getText().trim().length() < 3) {
            mostrarErroValidacao("O nome deve ter pelo menos 3 caracteres.");
            txtNome.requestFocus();
            return false;
        }
        
        if (txtCPF_CNPJ.getText().trim().isEmpty()) {
            mostrarErroValidacao("O campo 'CPF/CNPJ' é obrigatório.");
            txtCPF_CNPJ.requestFocus();
            return false;
        }
        
        String cpfCnpj = txtCPF_CNPJ.getText().trim().replaceAll("[^0-9]", "");
        if (cpfCnpj.length() != 11 && cpfCnpj.length() != 14) {
            mostrarErroValidacao("CPF deve ter 11 dígitos ou CNPJ deve ter 14 dígitos.");
            txtCPF_CNPJ.requestFocus();
            return false;
        }
        
        if (txtTelefone.getText().trim().isEmpty()) {
            mostrarErroValidacao("O campo 'Telefone' é obrigatório.");
            txtTelefone.requestFocus();
            return false;
        }
        
        if (txtEmail.getText().trim().isEmpty()) {
            mostrarErroValidacao("O campo 'Email' é obrigatório.");
            txtEmail.requestFocus();
            return false;
        }
        
        if (!isEmailValido(txtEmail.getText().trim())) {
            mostrarErroValidacao("Email inválido. Use o formato: exemplo@dominio.com");
            txtEmail.requestFocus();
            return false;
        }
        
        if (!txtDataNascimento.getText().trim().isEmpty()) {
            String data = txtDataNascimento.getText().trim();
            if (!data.matches("\\d{2}/\\d{2}/\\d{4}")) {
                mostrarErroValidacao("Data de nascimento deve estar no formato DD/MM/AAAA.");
                txtDataNascimento.requestFocus();
                return false;
            }
            
            try {
                String[] partes = data.split("/");
                int dia = Integer.parseInt(partes[0]);
                int mes = Integer.parseInt(partes[1]);
                int ano = Integer.parseInt(partes[2]);
                
                if (dia < 1 || dia > 31 || mes < 1 || mes > 12 || ano < 1900 || ano > 2024) {
                    mostrarErroValidacao("Data de nascimento inválida.");
                    txtDataNascimento.requestFocus();
                    return false;
                }
                
                LocalDateTime hoje = LocalDateTime.now();
                if (ano > hoje.getYear() || 
                    (ano == hoje.getYear() && mes > hoje.getMonthValue()) ||
                    (ano == hoje.getYear() && mes == hoje.getMonthValue() && dia > hoje.getDayOfMonth())) {
                    mostrarErroValidacao("Data de nascimento não pode ser no futuro.");
                    txtDataNascimento.requestFocus();
                    return false;
                }
                
            } catch (Exception e) {
                mostrarErroValidacao("Data de nascimento inválida.");
                txtDataNascimento.requestFocus();
                return false;
            }
        }
        
        return true;
    }
    
    private boolean isEmailValido(String email) {
        String regex = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
        return email.matches(regex);
    }
    
    private void mostrarErroValidacao(String mensagem) {
        JOptionPane.showMessageDialog(this,
            mensagem,
            "Erro de Validação",
            JOptionPane.WARNING_MESSAGE);
    }
}