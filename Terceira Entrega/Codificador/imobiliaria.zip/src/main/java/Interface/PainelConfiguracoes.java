package Interface;

import Controle.ControladorCentral;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class PainelConfiguracoes extends JPanel {
    
    private ControladorCentral controladorCentral;
    private JFrame parentFrame;
    private static final Color COR_SUCESSO = new Color(34, 197, 94);
    
    public PainelConfiguracoes(ControladorCentral controlador, JFrame parent) {
        this.controladorCentral = controlador;
        this.parentFrame = parent;
        criarInterface();
    }
    
    private void criarInterface() {
        setLayout(new GridBagLayout());
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        
        JPanel configGeral = new JPanel(new GridLayout(4, 2, 10, 10));
        configGeral.setBorder(BorderFactory.createTitledBorder("Configurações Gerais"));
        
        configGeral.add(new JLabel("Taxa de Comissão (%):"));
        JTextField txtComissao = new JTextField("5.0");
        configGeral.add(txtComissao);
        
        configGeral.add(new JLabel("Taxa de Multa (%):"));
        JTextField txtMulta = new JTextField("10.0");
        configGeral.add(txtMulta);
        
        configGeral.add(new JLabel("Dia de Vencimento:"));
        JComboBox<Integer> cboDia = new JComboBox<>();
        for (int i = 1; i <= 31; i++) {
            cboDia.addItem(i);
        }
        cboDia.setSelectedItem(5);
        configGeral.add(cboDia);
        
        configGeral.add(new JLabel("Backup Automático:"));
        JCheckBox chkBackup = new JCheckBox("Ativado", true);
        configGeral.add(chkBackup);
        
        gbc.gridx = 0; gbc.gridy = 0;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0; gbc.weighty = 0.0;
        add(configGeral, gbc);
        
        JPanel botoes = new JPanel(new FlowLayout());
        JButton btnSalvar = criarBotao("Salvar", COR_SUCESSO);
        JButton btnBackup = criarBotao("Fazer Backup", Color.ORANGE);
        JButton btnRestaurar = criarBotao("Restaurar", Color.RED);
        
        btnSalvar.addActionListener(e -> salvarConfiguracoes());
        btnBackup.addActionListener(e -> fazerBackup());
        btnRestaurar.addActionListener(e -> restaurarBackup());
        
        botoes.add(btnSalvar);
        botoes.add(btnBackup);
        botoes.add(btnRestaurar);
        
        gbc.gridy = 1;
        gbc.weighty = 0.0;
        add(botoes, gbc);
        
        // Nova seção para Seguros
        JPanel seguroPanel = criarPainelSeguros();
        gbc.gridy = 2;
        gbc.weighty = 1.0;
        gbc.anchor = GridBagConstraints.NORTH;
        add(seguroPanel, gbc);
    }
    
    private JButton criarBotao(String texto, Color cor) {
        JButton botao = new JButton(texto);
        botao.setBackground(cor);
        botao.setForeground(Color.WHITE);
        botao.setFont(new Font("Arial", Font.BOLD, 12));
        botao.setFocusPainted(false);
        botao.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16));
        botao.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        botao.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                botao.setBackground(cor.darker());
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                botao.setBackground(cor);
            }
        });
        
        return botao;
    }
    
    private void salvarConfiguracoes() {
        JOptionPane.showMessageDialog(this, "Configurações salvas com sucesso!", 
            "Configurações", JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void fazerBackup() {
        JOptionPane.showMessageDialog(this, "Backup realizado com sucesso!", 
            "Backup", JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void restaurarBackup() {
        int confirmacao = JOptionPane.showConfirmDialog(this, 
            "Tem certeza que deseja restaurar o backup?\n" +
            "Esta operação irá sobrescrever os dados atuais.",
            "Confirmar Restauração", 
            JOptionPane.YES_NO_OPTION, 
            JOptionPane.WARNING_MESSAGE);
        
        if (confirmacao == JOptionPane.YES_OPTION) {
            JOptionPane.showMessageDialog(this, "Backup restaurado com sucesso!", 
                "Restauração", JOptionPane.INFORMATION_MESSAGE);
        }
    }
    
    private JPanel criarPainelSeguros() {
        JPanel painelSeguros = new JPanel(new BorderLayout(10, 10));
        painelSeguros.setBorder(BorderFactory.createTitledBorder("Gestão de Seguros"));
        
        // Botões para seguros
        JPanel botoesSeguros = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton btnCadastrarSeguro = criarBotao("Cadastrar Seguro", new Color(41, 98, 255));
        JButton btnListarSeguros = criarBotao("Listar Seguros", Color.GRAY);
        JButton btnBuscarSeguro = criarBotao("Buscar Seguro", new Color(0, 150, 136));
        
        btnCadastrarSeguro.addActionListener(e -> cadastrarSeguro());
        btnListarSeguros.addActionListener(e -> listarSeguros());
        btnBuscarSeguro.addActionListener(e -> buscarSeguro());
        
        botoesSeguros.add(btnCadastrarSeguro);
        botoesSeguros.add(btnListarSeguros);
        botoesSeguros.add(btnBuscarSeguro);
        
        painelSeguros.add(botoesSeguros, BorderLayout.NORTH);
        
        // Área de informações dos seguros
        JTextArea infoSeguros = new JTextArea(5, 40);
        infoSeguros.setEditable(false);
        infoSeguros.setBackground(new Color(248, 249, 252));
        infoSeguros.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        infoSeguros.setText("Área para visualização de informações de seguros.\n" +
                           "Use os botões acima para gerenciar seguros do sistema.");
        
        JScrollPane scrollInfo = new JScrollPane(infoSeguros);
        painelSeguros.add(scrollInfo, BorderLayout.CENTER);
        
        return painelSeguros;
    }
    
    private void cadastrarSeguro() {
        JDialog dialog = new JDialog((JFrame)parentFrame, "Cadastrar Seguro", true);
        dialog.setSize(450, 350);
        dialog.setLocationRelativeTo(parentFrame);
        dialog.setLayout(new BorderLayout());
        
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.WEST;
        
        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(new JLabel("Nome do Seguro:*"), gbc);
        JTextField nomeField = new JTextField(20);
        gbc.gridx = 1;
        panel.add(nomeField, gbc);
        
        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(new JLabel("Valor (R$):*"), gbc);
        JTextField valorField = new JTextField(20);
        gbc.gridx = 1;
        panel.add(valorField, gbc);
        
        gbc.gridx = 0; gbc.gridy = 2;
        panel.add(new JLabel("Descrição:"), gbc);
        JTextArea descricaoArea = new JTextArea(4, 20);
        descricaoArea.setLineWrap(true);
        descricaoArea.setWrapStyleWord(true);
        JScrollPane scrollDesc = new JScrollPane(descricaoArea);
        gbc.gridx = 1;
        panel.add(scrollDesc, gbc);
        
        gbc.gridx = 0; gbc.gridy = 3;
        panel.add(new JLabel("Ativo:"), gbc);
        JCheckBox ativoCheck = new JCheckBox();
        gbc.gridx = 1;
        panel.add(ativoCheck, gbc);
        
        JPanel botoesPanel = new JPanel(new FlowLayout());
        JButton btnSalvar = criarBotao("Salvar", COR_SUCESSO);
        JButton btnCancelar = criarBotao("Cancelar", Color.GRAY);
        
        btnSalvar.addActionListener(e -> {
            try {
                String nome = nomeField.getText().trim();
                String valorText = valorField.getText().trim();
                String descricao = descricaoArea.getText().trim();
                boolean ativo = ativoCheck.isSelected();
                
                if (nome.isEmpty() || valorText.isEmpty()) {
                    JOptionPane.showMessageDialog(dialog, "Nome e valor são obrigatórios!", 
                        "Erro", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                double valor = Double.parseDouble(valorText);
                boolean sucesso = controladorCentral.registrarSeguro(nome, valor, descricao, ativo);
                
                if (sucesso) {
                    JOptionPane.showMessageDialog(dialog, "Seguro cadastrado com sucesso!");
                    dialog.dispose();
                } else {
                    JOptionPane.showMessageDialog(dialog, "Erro ao cadastrar seguro", 
                        "Erro", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(dialog, "Valor deve ser numérico!", 
                    "Erro", JOptionPane.ERROR_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(dialog, "Erro: " + ex.getMessage(), 
                    "Erro", JOptionPane.ERROR_MESSAGE);
            }
        });
        
        btnCancelar.addActionListener(e -> dialog.dispose());
        
        botoesPanel.add(btnSalvar);
        botoesPanel.add(btnCancelar);
        
        dialog.add(panel, BorderLayout.CENTER);
        dialog.add(botoesPanel, BorderLayout.SOUTH);
        dialog.setVisible(true);
    }
    
    private void listarSeguros() {
        try {
            var seguros = Catalogos.CatalogoSeguro.getInstance().listarSeguros();
            
            if (seguros.isEmpty()) {
                JOptionPane.showMessageDialog(this, 
                    "Nenhum seguro cadastrado no sistema.",
                    "Lista de Seguros", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            
            JDialog dialogLista = new JDialog((JFrame)parentFrame, "Lista de Seguros", true);
            dialogLista.setSize(700, 500);
            dialogLista.setLocationRelativeTo(parentFrame);
            dialogLista.setLayout(new BorderLayout());
            
            // Painel de informações
            JPanel painelInfo = new JPanel(new FlowLayout(FlowLayout.LEFT));
            painelInfo.setBorder(BorderFactory.createTitledBorder("Informações"));
            JLabel lblInfo = new JLabel("Total de Seguros: " + seguros.size() + 
                " | Atualizado em: " + java.time.LocalDateTime.now().format(
                java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")));
            painelInfo.add(lblInfo);
            
            // Formatação da lista
            StringBuilder listaFormatada = new StringBuilder();
            listaFormatada.append("=== LISTA DE SEGUROS ===\n\n");
            listaFormatada.append("Total: ").append(seguros.size()).append(" seguro(s)\n");
            listaFormatada.append("Gerado em: ").append(java.time.LocalDateTime.now().format(
                java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"))).append("\n\n");
            
            listaFormatada.append("--- SEGUROS CADASTRADOS ---\n");
            for (int i = 0; i < seguros.size(); i++) {
                var seguro = seguros.get(i);
                listaFormatada.append("\n").append(i + 1).append(". ").append(seguro.getNome()).append("\n");
                listaFormatada.append("   ID: ").append(seguro.getId()).append("\n");
                listaFormatada.append("   Valor: R$ ").append(String.format("%.2f", seguro.getValor())).append("\n");
                listaFormatada.append("   Status: ").append(seguro.isAtivacao() ? "Ativo" : "Inativo").append("\n");
                if (seguro.getDescricao() != null && !seguro.getDescricao().trim().isEmpty()) {
                    listaFormatada.append("   Descrição: ").append(seguro.getDescricao()).append("\n");
                }
            }
            
            JTextArea areaLista = new JTextArea();
            areaLista.setEditable(false);
            areaLista.setFont(new Font("Courier New", Font.PLAIN, 11));
            areaLista.setText(listaFormatada.toString());
            
            JScrollPane scrollPane = new JScrollPane(areaLista);
            
            JPanel painelBotoes = new JPanel(new FlowLayout());
            JButton btnFechar = criarBotao("Fechar", Color.GRAY);
            JButton btnAtualizar = criarBotao("Atualizar", new Color(0, 150, 136));
            
            btnFechar.addActionListener(e -> dialogLista.dispose());
            btnAtualizar.addActionListener(e -> {
                dialogLista.dispose();
                listarSeguros();
            });
            
            painelBotoes.add(btnAtualizar);
            painelBotoes.add(btnFechar);
            
            dialogLista.add(painelInfo, BorderLayout.NORTH);
            dialogLista.add(scrollPane, BorderLayout.CENTER);
            dialogLista.add(painelBotoes, BorderLayout.SOUTH);
            
            dialogLista.setVisible(true);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "Erro ao listar seguros: " + e.getMessage(), 
                "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void buscarSeguro() {
        try {
            String identificador = JOptionPane.showInputDialog(
                this,
                "Digite o nome ou ID do seguro:",
                "Buscar Seguro",
                JOptionPane.QUESTION_MESSAGE
            );
            
            if (identificador == null || identificador.trim().isEmpty()) {
                return;
            }
            
            var seguro = Catalogos.CatalogoSeguro.getInstance().buscarSeguro(identificador);
            
            if (seguro == null) {
                JOptionPane.showMessageDialog(this, "Seguro não encontrado.", 
                    "Busca", JOptionPane.WARNING_MESSAGE);
            } else {
                StringBuilder info = new StringBuilder();
                info.append("Seguro encontrado:\n\n");
                info.append("Nome: ").append(seguro.getNome()).append("\n");
                info.append("ID: ").append(seguro.getId()).append("\n");
                info.append("Valor: R$ ").append(String.format("%.2f", seguro.getValor())).append("\n");
                info.append("Status: ").append(seguro.isAtivacao() ? "Ativo" : "Inativo").append("\n");
                if (seguro.getDescricao() != null && !seguro.getDescricao().trim().isEmpty()) {
                    info.append("Descrição: ").append(seguro.getDescricao()).append("\n");
                }
                
                JOptionPane.showMessageDialog(this, info.toString(), 
                    "Seguro Encontrado", JOptionPane.INFORMATION_MESSAGE);
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Erro ao buscar seguro: " + e.getMessage(),
                "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
}