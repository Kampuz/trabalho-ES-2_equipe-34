package Interface;

import Conceitos.EnumGenero;
import Conceitos.EnumCargo;
import java.time.LocalDateTime;
import java.awt.Graphics2D;

public class InterfaceGerente {

	private InterfaceCentral interfaceCentral;

        public InterfaceGerente() {
            this.interfaceCentral = new InterfaceCentral();
        }
        
        public InterfaceGerente(InterfaceCentral interfaceCentral) {
            this.interfaceCentral = interfaceCentral;
        }

	public boolean registrarFuncionario(String nome, LocalDateTime data_nascimento, String CPF, String telefone, String email, String endereco, EnumGenero genero, Graphics2D imagem, EnumCargo cargo, double salario) {
            return interfaceCentral.registrarFuncionario(nome, data_nascimento, CPF, telefone, email, endereco, genero, imagem, cargo, salario);
	}

	public boolean registrarGerente(String nome, LocalDateTime data_nascimento, String CPF, String telefone, String email, String endereco, EnumGenero genero, Graphics2D imagem, double salario) {
            return interfaceCentral.registrarGerente(nome, data_nascimento, CPF, telefone, email, endereco, genero, imagem, salario);
	}

}
