package Interface;

import Controle.ControladorCentral;
import Conceitos.*;
import Catalogos.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class PainelImoveis extends JPanel {
    
    private ControladorCentral controladorCentral;
    private JFrame parentFrame;
    private static final Color COR_PRIMARIA = new Color(41, 98, 255);
    
    public PainelImoveis(ControladorCentral controlador, JFrame parent) {
        this.controladorCentral = controlador;
        this.parentFrame = parent;
        criarInterface();
    }
    
    private void criarInterface() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        JPanel botoes = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton btnCadastrar = criarBotao("Cadastrar Imóvel", COR_PRIMARIA);
        JButton btnListar = criarBotao("Listar Imóveis", Color.GRAY);
        JButton btnEditar = criarBotao("Editar Imóvel", new Color(255, 140, 0));
        JButton btnBuscar = criarBotao("Buscar", Color.GRAY);
        JButton btnVisualizar = criarBotao("Visualizar Imóvel", new Color(102, 51, 153));
        JButton btnArquivar = criarBotao("Arquivar Imóvel", new Color(220, 53, 69));
        
        btnCadastrar.addActionListener(e -> abrirFormularioCadastroImovel());
        btnListar.addActionListener(e -> listarImoveis());
        btnEditar.addActionListener(e -> editarImovel());
        btnBuscar.addActionListener(e -> buscarImovel());
        btnVisualizar.addActionListener(e -> visualizarImovel());
        btnArquivar.addActionListener(e -> arquivarImovel());
        
        botoes.add(btnCadastrar);
        botoes.add(btnListar);
        botoes.add(btnEditar);
        botoes.add(btnBuscar);
        botoes.add(btnVisualizar);
        botoes.add(btnArquivar);
        
        JPanel conteudo = new JPanel(new BorderLayout());
        JTable tabela = new JTable();
        JScrollPane scroll = new JScrollPane(tabela);
        conteudo.add(scroll, BorderLayout.CENTER);
        
        add(botoes, BorderLayout.NORTH);
        add(conteudo, BorderLayout.CENTER);
    }
    
    private JButton criarBotao(String texto, Color cor) {
        JButton botao = new JButton(texto);
        botao.setBackground(cor);
        botao.setForeground(Color.WHITE);
        botao.setFont(new Font("Arial", Font.BOLD, 12));
        botao.setFocusPainted(false);
        botao.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16));
        botao.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        botao.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                botao.setBackground(cor.darker());
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                botao.setBackground(cor);
            }
        });
        
        return botao;
    }
    
    private void abrirFormularioCadastroImovel() {
        new FormularioCadastroImovelRequisitos((SistemaImobiliarioGUI)parentFrame).setVisible(true);
    }
    
    private void listarImoveis() {
        try {
            String listaImoveis = controladorCentral.consultaListagem(2);
            
            if (listaImoveis == null || listaImoveis.trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, 
                    "Nenhum imóvel cadastrado no sistema.",
                    "Lista de Imóveis", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            
            // Criar dialog personalizado com mais funcionalidades
            JDialog dialogLista = new JDialog((JFrame)parentFrame, "Lista Completa de Imóveis", true);
            dialogLista.setSize(800, 600);
            dialogLista.setLocationRelativeTo(parentFrame);
            dialogLista.setLayout(new BorderLayout());
            
            // Painel superior com informações
            JPanel painelInfo = new JPanel(new FlowLayout(FlowLayout.LEFT));
            painelInfo.setBorder(BorderFactory.createTitledBorder("Informações"));
            
            int totalImoveis = contarLinhas(listaImoveis);
            JLabel lblInfo = new JLabel("Total de Imóveis: " + totalImoveis + " | Última atualização: " + 
                java.time.LocalDateTime.now().format(java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")));
            painelInfo.add(lblInfo);
            
            // Área de texto com lista detalhada
            JTextArea areaLista = new JTextArea();
            areaLista.setEditable(false);
            areaLista.setFont(new Font("Courier New", Font.PLAIN, 12));
            
            // Formatear melhor a lista de imóveis
            StringBuilder listaFormatada = new StringBuilder();
            listaFormatada.append("=== RELATÓRIO DETALHADO DE IMÓVEIS ===\n\n");
            listaFormatada.append("Total de Imóveis Cadastrados: ").append(totalImoveis).append("\n");
            listaFormatada.append("Gerado em: ").append(java.time.LocalDateTime.now().format(
                java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"))).append("\n\n");
            listaFormatada.append("--- LISTA DETALHADA ---\n");
            listaFormatada.append(listaImoveis);
            
            areaLista.setText(listaFormatada.toString());
            
            JScrollPane scrollPane = new JScrollPane(areaLista);
            
            // Painel de botões
            JPanel painelBotoes = new JPanel(new FlowLayout());
            JButton btnFechar = criarBotao("Fechar", Color.GRAY);
            JButton btnExportar = criarBotao("Exportar Lista", COR_PRIMARIA);
            JButton btnAtualizar = criarBotao("Atualizar", new Color(0, 150, 136));
            
            btnFechar.addActionListener(e -> dialogLista.dispose());
            btnAtualizar.addActionListener(e -> {
                // Atualizar a lista
                String novaLista = controladorCentral.consultaListagem(2);
                if (novaLista != null) {
                    int novoTotal = contarLinhas(novaLista);
                    lblInfo.setText("Total de Imóveis: " + novoTotal + " | Última atualização: " + 
                        java.time.LocalDateTime.now().format(java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")));
                    
                    StringBuilder novaListaFormatada = new StringBuilder();
                    novaListaFormatada.append("=== RELATÓRIO DETALHADO DE IMÓVEIS ===\n\n");
                    novaListaFormatada.append("Total de Imóveis Cadastrados: ").append(novoTotal).append("\n");
                    novaListaFormatada.append("Gerado em: ").append(java.time.LocalDateTime.now().format(
                        java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"))).append("\n\n");
                    novaListaFormatada.append("--- LISTA DETALHADA ---\n");
                    novaListaFormatada.append(novaLista);
                    
                    areaLista.setText(novaListaFormatada.toString());
                }
            });
            
            btnExportar.addActionListener(e -> {
                JOptionPane.showMessageDialog(dialogLista, 
                    "Funcionalidade de exportação será implementada em versão futura.",
                    "Exportar", JOptionPane.INFORMATION_MESSAGE);
            });
            
            painelBotoes.add(btnAtualizar);
            painelBotoes.add(btnExportar);
            painelBotoes.add(btnFechar);
            
            dialogLista.add(painelInfo, BorderLayout.NORTH);
            dialogLista.add(scrollPane, BorderLayout.CENTER);
            dialogLista.add(painelBotoes, BorderLayout.SOUTH);
            
            dialogLista.setVisible(true);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "Erro ao listar imóveis: " + e.getMessage(), 
                "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private int contarLinhas(String texto) {
        if (texto == null || texto.trim().isEmpty()) return 0;
        return texto.split("\n").length;
    }
    
    private void editarImovel() {
        try {
            String nomeImovel = JOptionPane.showInputDialog(
                this, 
                "Digite o nome do imóvel que deseja editar:",
                "Editar Imóvel",
                JOptionPane.QUESTION_MESSAGE
            );
            
            if (nomeImovel == null || nomeImovel.trim().isEmpty()) {
                return;
            }
            
            imovel imovelEncontrado = controladorCentral.buscarImovel(nomeImovel);
            if (imovelEncontrado == null) {
                JOptionPane.showMessageDialog(
                    this,
                    "Imóvel não encontrado: " + nomeImovel,
                    "Imóvel Não Encontrado",
                    JOptionPane.ERROR_MESSAGE
                );
                return;
            }
            
            mostrarDialogEdicaoImovel(imovelEncontrado);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(
                this,
                "Erro ao editar imóvel: " + e.getMessage(),
                "Erro",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }
    
    private void mostrarDialogEdicaoImovel(imovel imovel) {
        JDialog dialog = new JDialog((JFrame)parentFrame, "Editar Imóvel - " + imovel.getNome(), true);
        dialog.setSize(500, 450);
        dialog.setLocationRelativeTo(parentFrame);
        
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.WEST;
        
        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(new JLabel("Nome:*"), gbc);
        JTextField nomeField = new JTextField(imovel.getNome(), 20);
        gbc.gridx = 1;
        panel.add(nomeField, gbc);
        
        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(new JLabel("Tipo:"), gbc);
        JComboBox<EnumImovel> tipoCombo = new JComboBox<>(EnumImovel.values());
        tipoCombo.setSelectedItem(imovel.getTipoImovel());
        gbc.gridx = 1;
        panel.add(tipoCombo, gbc);
        
        gbc.gridx = 0; gbc.gridy = 2;
        panel.add(new JLabel("Ocupado:"), gbc);
        JCheckBox ocupadoCheck = new JCheckBox();
        ocupadoCheck.setSelected(imovel.isOcupado());
        gbc.gridx = 1;
        panel.add(ocupadoCheck, gbc);
        
        gbc.gridx = 0; gbc.gridy = 3;
        panel.add(new JLabel("Proprietário:"), gbc);
        JTextField clienteField = new JTextField(imovel.getProprietario() != null ? imovel.getProprietario().getNome() : "", 20);
        clienteField.setEditable(false);
        clienteField.setToolTipText("Edição de proprietário não implementada");
        gbc.gridx = 1;
        panel.add(clienteField, gbc);
        
        JPanel botoesPanel = new JPanel(new FlowLayout());
        JButton btnSalvar = criarBotao("Salvar", COR_PRIMARIA);
        JButton btnCancelar = criarBotao("Cancelar", Color.GRAY);
        
        btnSalvar.addActionListener(e -> {
            try {
                String novoNome = nomeField.getText().trim();
                String novoCliente = clienteField.getText().trim();
                EnumImovel novoTipo = (EnumImovel) tipoCombo.getSelectedItem();
                boolean novoOcupado = ocupadoCheck.isSelected();
                
                if (novoNome.isEmpty()) {
                    JOptionPane.showMessageDialog(dialog, 
                        "Nome é obrigatório!", "Erro", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                boolean sucesso = controladorCentral.editarImovel(
                    imovel.getNome(),
                    novoNome,
                    novoTipo,
                    novoOcupado,
                    novoCliente
                );
                
                if (sucesso) {
                    JOptionPane.showMessageDialog(dialog, "Imóvel atualizado com sucesso!");
                    dialog.dispose();
                } else {
                    JOptionPane.showMessageDialog(dialog, "Erro ao atualizar imóvel", 
                        "Erro", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(dialog, "Erro: " + ex.getMessage(), 
                    "Erro", JOptionPane.ERROR_MESSAGE);
            }
        });
        
        btnCancelar.addActionListener(e -> dialog.dispose());
        
        botoesPanel.add(btnSalvar);
        botoesPanel.add(btnCancelar);
        
        gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 2;
        panel.add(botoesPanel, gbc);
        
        dialog.add(panel);
        dialog.setVisible(true);
    }
    
    private void arquivarImovel() {
        try {
            String nomeImovel = JOptionPane.showInputDialog(
                this, 
                "Digite o nome do imóvel que deseja arquivar:\n\n" +
                "⚠️ ATENÇÃO: Esta operação é irreversível!\n" +
                "O imóvel será marcado como arquivado.",
                "Arquivar Imóvel",
                JOptionPane.WARNING_MESSAGE
            );
            
            if (nomeImovel == null || nomeImovel.trim().isEmpty()) {
                return;
            }
            
            int confirmacao = JOptionPane.showConfirmDialog(
                this,
                "Tem certeza que deseja arquivar o imóvel?\n\n" +
                "Imóvel: " + nomeImovel + "\n\n" +
                "Esta operação é irreversível!",
                "Confirmar Arquivamento",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE
            );
            
            if (confirmacao == JOptionPane.YES_OPTION) {
                boolean sucesso = controladorCentral.arquivarImovel(nomeImovel);
                
                if (sucesso) {
                    JOptionPane.showMessageDialog(this, "Imóvel arquivado com sucesso!");
                } else {
                    JOptionPane.showMessageDialog(this, 
                        "Erro ao arquivar imóvel!\nVerifique se o nome está correto.", 
                        "Erro", JOptionPane.ERROR_MESSAGE);
                }
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Erro inesperado: " + e.getMessage(),
                "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void buscarImovel() {
        try {
            String identificador = JOptionPane.showInputDialog(
                this,
                "Digite o identificador do imóvel:",
                "Buscar Imóvel",
                JOptionPane.QUESTION_MESSAGE
            );
            
            if (identificador == null || identificador.trim().isEmpty()) {
                return;
            }
            
            imovel imovelEncontrado = controladorCentral.buscarImovel(identificador);
            
            if (imovelEncontrado == null) {
                JOptionPane.showMessageDialog(this, "Imóvel não encontrado.", "Busca", JOptionPane.WARNING_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, 
                    "Imóvel encontrado:\n\n" +
                    "Nome: " + imovelEncontrado.getNome() + "\n" +
                    "Tipo: " + imovelEncontrado.getTipoImovel() + "\n" +
                    "Ocupado: " + (imovelEncontrado.isOcupado() ? "Sim" : "Não"), 
                    "Imóvel Encontrado", JOptionPane.INFORMATION_MESSAGE);
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Erro ao buscar imóvel: " + e.getMessage(),
                "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void visualizarImovel() {
        try {
            String identificador = JOptionPane.showInputDialog(
                this,
                "Digite o identificador do imóvel para visualizar detalhes completos:",
                "Visualizar Imóvel",
                JOptionPane.QUESTION_MESSAGE
            );
            
            if (identificador == null || identificador.trim().isEmpty()) {
                return;
            }
            
            imovel imovel = controladorCentral.buscarImovel(identificador.trim());
            
            if (imovel != null) {
                // Criar janela de visualização detalhada
                JDialog dialog = new JDialog((JFrame)parentFrame, "Detalhes do Imóvel", true);
                dialog.setSize(500, 400);
                dialog.setLocationRelativeTo(parentFrame);
                dialog.setLayout(new BorderLayout());
                
                JPanel painelInfo = new JPanel();
                painelInfo.setLayout(new BoxLayout(painelInfo, BoxLayout.Y_AXIS));
                painelInfo.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
                
                painelInfo.add(criarLabelInfo("🏠 Nome:", imovel.getNome()));
                painelInfo.add(Box.createVerticalStrut(10));
                painelInfo.add(criarLabelInfo("💰 Valor:", "R$ " + String.format("%.2f", imovel.getValor())));
                painelInfo.add(Box.createVerticalStrut(10));
                painelInfo.add(criarLabelInfo("🏷️ Tipo:", imovel.getTipoImovel().toString()));
                
                JButton btnFechar = criarBotao("Fechar", Color.GRAY);
                btnFechar.addActionListener(e -> dialog.dispose());
                
                JPanel painelBotao = new JPanel();
                painelBotao.add(btnFechar);
                
                dialog.add(painelInfo, BorderLayout.CENTER);
                dialog.add(painelBotao, BorderLayout.SOUTH);
                
                dialog.setVisible(true);
                
            } else {
                JOptionPane.showMessageDialog(this,
                    "❌ Imóvel não encontrado!\n\n" +
                    "Identificador buscado: " + identificador + "\n\n" +
                    "Dicas:\n" +
                    "• Verifique se o identificador está correto\n" +
                    "• A busca é case-sensitive\n" +
                    "• Use o identificador completo",
                    "Imóvel Não Encontrado",
                    JOptionPane.WARNING_MESSAGE);
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Erro ao visualizar imóvel: " + e.getMessage(),
                "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private JPanel criarLabelInfo(String titulo, String valor) {
        JPanel painel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel lblTitulo = new JLabel(titulo);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 12));
        JLabel lblValor = new JLabel(valor);
        lblValor.setFont(new Font("Arial", Font.PLAIN, 12));
        
        painel.add(lblTitulo);
        painel.add(lblValor);
        return painel;
    }
}