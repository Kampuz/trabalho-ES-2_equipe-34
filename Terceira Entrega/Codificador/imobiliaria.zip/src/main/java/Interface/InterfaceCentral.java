package Interface;

import Controle.ControladorCentral;
import Conceitos.Cliente;
import Conceitos.Funcionario;
import Conceitos.imovel;
import Conceitos.LaudoTecnico;
import Conceitos.LaudoVistoria;
import Conceitos.EnumGenero;
import Conceitos.EnumImovel;
import Conceitos.EnumCargo;
import java.time.LocalDateTime;
import java.awt.Graphics2D;

public class InterfaceCentral {

    private ControladorCentral controladorCentral;

    public InterfaceCentral() {
        this.controladorCentral = new ControladorCentral();
    }
    public boolean criarAgendamentoVisita(Cliente cliente, Funcionario funcionario, imovel imovel, LocalDateTime data_hora) {
        return controladorCentral.criarAgendamentoVisita(cliente, funcionario, imovel, data_hora);
    }

    public boolean criarAgendamentoVistoria(Cliente cliente, Funcionario funcionario, imovel imovel, LocalDateTime data_hora) {
        return controladorCentral.criarAgendamentoVistoria(cliente, funcionario, imovel, data_hora);
    }
    public boolean registrarCliente(String nome, LocalDateTime data_nascimento, String CPFouCNPJ, String telefone, String email, String endereco, EnumGenero genero, Graphics2D imagem) {
        return controladorCentral.registrarCliente(nome, data_nascimento, CPFouCNPJ, telefone, email, endereco, genero, imagem);
    }

    public void registrarCliente(String nome, String email, String celular) {
        controladorCentral.registrarCliente(nome, email, celular);
    }
    public void registrarAluguel(int caucao, float comissao_imobiliaria, float desconto, Funcionario funcionario_responsavel, imovel imovel, Cliente locatario) {
        controladorCentral.registrarAluguel(caucao, comissao_imobiliaria, desconto, funcionario_responsavel, imovel, locatario);
    }
    public boolean registrarFuncionario(String nome, LocalDateTime data_nascimento, String CPF, String telefone, String email, String endereco, EnumGenero genero, Graphics2D imagem, EnumCargo cargo, double salario) {
        return controladorCentral.registrarFuncionario(nome, data_nascimento, CPF, telefone, email, endereco, genero, imagem, cargo, salario);
    }

    public boolean registrarGerente(String nome, LocalDateTime data_nascimento, String CPF, String telefone, String email, String endereco, EnumGenero genero, Graphics2D imagem, double salario) {
        return controladorCentral.registrarGerente(nome, data_nascimento, CPF, telefone, email, endereco, genero, imagem, salario);
    }
    public boolean registrarImovel(String nome, String cliente, EnumImovel tipo_imovel, boolean ocupado, int laudo_tecnico, int laudo_vistoria, Graphics2D imagem) {
        return controladorCentral.registrarImovel(nome, cliente, tipo_imovel, ocupado, laudo_tecnico, laudo_vistoria, imagem);
    }
    public boolean registrarLaudoVistoria(String nome_responsavel, String descricao) {
        return controladorCentral.registrarLaudoVistoria(nome_responsavel, descricao);
    }

    public boolean registrarLaudoTecnico(String nome_responsavel, String endereco, double valor, double area_total, double area_interna) {
        return controladorCentral.registrarLaudoTecnico(nome_responsavel, endereco, valor, area_total, area_interna);
    }
    public boolean registrarSeguro(String nome, double valor, String descricao) {
        return controladorCentral.registrarSeguro(nome, valor, descricao);
    }

    public boolean registrarSeguro(String nome, double valor, String descricao, boolean ativacao) {
        return controladorCentral.registrarSeguro(nome, valor, descricao, ativacao);
    }
    public void pagarCobranca(Cliente cliente) {
    }

    public int mostrarCobrancas(String texto) {
        return 0;
    }
    public double consultaGastosMensais() {
        return controladorCentral.consultaGastosMensais();
    }

    public String consultaIdentificador(int objetivo, String identificador) {
        return controladorCentral.consultaIdentificador(objetivo, identificador);
    }

    public String consultaListagem(int objetivo) {
        return controladorCentral.consultaListagem(objetivo);
    }

    public ControladorCentral getControladorCentral() {
        return controladorCentral;
    }
    public void inicializarSistema() {
    }

    public void finalizarSistema() {
    }
}