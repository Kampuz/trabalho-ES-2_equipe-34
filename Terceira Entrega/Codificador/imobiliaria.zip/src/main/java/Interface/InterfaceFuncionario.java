package Interface;

import Conceitos.Cliente;
import Conceitos.Funcionario;
import Conceitos.imovel;
import Conceitos.LaudoTecnico;
import Conceitos.LaudoVistoria;
import Conceitos.EnumGenero;
import Conceitos.EnumImovel;
import java.time.LocalDateTime;
import java.awt.Graphics2D;

public class InterfaceFuncionario {

	private InterfaceCentral interfaceCentral;

        public InterfaceFuncionario() {
            this.interfaceCentral = new InterfaceCentral();
        }
        
        public InterfaceFuncionario(InterfaceCentral interfaceCentral) {
            this.interfaceCentral = interfaceCentral;
        }

	public boolean criarAgendamentoVisita(Cliente cliente, Funcionario funcionario, imovel imovel, LocalDateTime data_hora) {
            return interfaceCentral.criarAgendamentoVisita(cliente, funcionario, imovel, data_hora);
	}

	public boolean criarAgendamentoVistoria(Cliente cliente, Funcionario funcionario, imovel imovel, LocalDateTime data_hora) {
            return interfaceCentral.criarAgendamentoVistoria(cliente, funcionario, imovel, data_hora);
	}

	public boolean registrarCliente(String nome, LocalDateTime data_nascimento, String CPFouCNPJ, String telefone, String email, String endereco, EnumGenero genero, Graphics2D imagem) {
            return interfaceCentral.registrarCliente(nome, data_nascimento, CPFouCNPJ, telefone, email, endereco, genero, imagem);
	}

	public void registrarCliente(String nome, String email, String celular) {
            interfaceCentral.registrarCliente(nome, email, celular);

	}

	public void registrarAluguel(int caucao, float comissao_imobiliaria, float desconto, Funcionario funcionario_responsavel, imovel imovel, Cliente locatario) {
            interfaceCentral.registrarAluguel(caucao, comissao_imobiliaria, desconto, funcionario_responsavel, imovel, locatario);

	}

	public boolean registrarImovel(String nome, String cliente, EnumImovel tipo_imovel, boolean ocupado, int laudo_tecnico, int laudo_vistoria, Graphics2D imagem) {
            return interfaceCentral.registrarImovel(nome, cliente, tipo_imovel, ocupado, laudo_tecnico, laudo_vistoria, imagem);
	}

	public boolean registrarLaudoVistoria(String nome_responsavel, String descricao) {
            return interfaceCentral.registrarLaudoVistoria(nome_responsavel, descricao);
	}

	public boolean registrarLaudoTecnico(String nome_responsavel, String endereco, double valor, double area_total, double area_interna) {
            return interfaceCentral.registrarLaudoTecnico(nome_responsavel, endereco, valor, area_total, area_interna);
	}
        
        public boolean registrarSeguro(String nome, double valor, String descricao) {
            return interfaceCentral.registrarSeguro(nome, valor, descricao);
        }
        
        public boolean registrarSeguro(String nome, double valor, String descricao, boolean ativacao) {
            return interfaceCentral.registrarSeguro(nome, valor, descricao, ativacao);
        }
        
        public double consultaGastosMensais() {
            return interfaceCentral.consultaGastosMensais();
        }
        public String consultaIdentificador(int objetivo, String identificador) {
            return interfaceCentral.consultaIdentificador(objetivo, identificador);
        }
        public String consultaListagem(int objetivo) {
            return interfaceCentral.consultaListagem(objetivo);
        }

}
