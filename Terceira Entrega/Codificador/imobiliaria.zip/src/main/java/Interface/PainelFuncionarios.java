package Interface;

import Controle.ControladorCentral;
import Conceitos.*;
import Catalogos.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.time.LocalDateTime;

public class PainelFuncionarios extends JPanel {
    
    private ControladorCentral controladorCentral;
    private JFrame parentFrame;
    private static final Color COR_PRIMARIA = new Color(41, 98, 255);
    
    public PainelFuncionarios(ControladorCentral controlador, JFrame parent) {
        this.controladorCentral = controlador;
        this.parentFrame = parent;
        criarInterface();
    }
    
    private void criarInterface() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        JPanel botoes = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton btnCadastrar = criarBotao("Cadastrar Funcionário", COR_PRIMARIA);
        JButton btnListar = criarBotao("Listar Funcionários", Color.GRAY);
        JButton btnEditar = criarBotao("Editar Funcionário", Color.GRAY);
        JButton btnBuscar = criarBotao("Buscar Funcionário", new Color(0, 150, 136));
        JButton btnVisualizar = criarBotao("Visualizar Funcionário", new Color(102, 51, 153));
        JButton btnArquivarFunc = criarBotao("Arquivar Funcionário", new Color(220, 53, 69));
        
        btnCadastrar.addActionListener(e -> cadastrarFuncionario());
        btnListar.addActionListener(e -> listarFuncionarios());
        btnEditar.addActionListener(e -> editarFuncionario());
        btnBuscar.addActionListener(e -> buscarFuncionario());
        btnVisualizar.addActionListener(e -> visualizarFuncionario());
        btnArquivarFunc.addActionListener(e -> arquivarFuncionario());
        
        botoes.add(btnCadastrar);
        botoes.add(btnListar);
        botoes.add(btnEditar);
        botoes.add(btnBuscar);
        botoes.add(btnVisualizar);
        botoes.add(btnArquivarFunc);
        
        JPanel conteudo = new JPanel(new BorderLayout());
        JTable tabela = new JTable();
        JScrollPane scroll = new JScrollPane(tabela);
        conteudo.add(scroll, BorderLayout.CENTER);
        
        add(botoes, BorderLayout.NORTH);
        add(conteudo, BorderLayout.CENTER);
    }
    
    private JButton criarBotao(String texto, Color cor) {
        JButton botao = new JButton(texto);
        botao.setBackground(cor);
        botao.setForeground(Color.WHITE);
        botao.setFont(new Font("Arial", Font.BOLD, 12));
        botao.setFocusPainted(false);
        botao.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16));
        botao.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        botao.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                botao.setBackground(cor.darker());
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                botao.setBackground(cor);
            }
        });
        
        return botao;
    }
    
    private void cadastrarFuncionario() {
        JDialog dialog = new JDialog((JFrame)parentFrame, "Cadastro de Funcionário", true);
        dialog.setSize(400, 500);
        dialog.setLocationRelativeTo(parentFrame);
        dialog.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        
        JTextField nomeField = new JTextField(20);
        JTextField cpfField = new JTextField(20);
        JTextField telefoneField = new JTextField(20);
        JTextField emailField = new JTextField(20);
        JTextField enderecoField = new JTextField(20);
        JComboBox<String> generoCombo = new JComboBox<>(new String[]{"MASCULINO", "FEMININO", "OUTROS"});
        JComboBox<String> cargoCombo = new JComboBox<>(new String[]{"FUNCIONARIO", "GERENTE"});
        JTextField salarioField = new JTextField(20);
        
        gbc.gridx = 0; gbc.gridy = 0; gbc.anchor = GridBagConstraints.EAST;
        dialog.add(new JLabel("Nome:"), gbc);
        gbc.gridx = 1; gbc.anchor = GridBagConstraints.WEST;
        dialog.add(nomeField, gbc);
        
        gbc.gridx = 0; gbc.gridy = 1; gbc.anchor = GridBagConstraints.EAST;
        dialog.add(new JLabel("CPF:"), gbc);
        gbc.gridx = 1; gbc.anchor = GridBagConstraints.WEST;
        dialog.add(cpfField, gbc);
        
        gbc.gridx = 0; gbc.gridy = 2; gbc.anchor = GridBagConstraints.EAST;
        dialog.add(new JLabel("Telefone:"), gbc);
        gbc.gridx = 1; gbc.anchor = GridBagConstraints.WEST;
        dialog.add(telefoneField, gbc);
        
        gbc.gridx = 0; gbc.gridy = 3; gbc.anchor = GridBagConstraints.EAST;
        dialog.add(new JLabel("Email:"), gbc);
        gbc.gridx = 1; gbc.anchor = GridBagConstraints.WEST;
        dialog.add(emailField, gbc);
        
        gbc.gridx = 0; gbc.gridy = 4; gbc.anchor = GridBagConstraints.EAST;
        dialog.add(new JLabel("Endereço:"), gbc);
        gbc.gridx = 1; gbc.anchor = GridBagConstraints.WEST;
        dialog.add(enderecoField, gbc);
        
        gbc.gridx = 0; gbc.gridy = 5; gbc.anchor = GridBagConstraints.EAST;
        dialog.add(new JLabel("Gênero:"), gbc);
        gbc.gridx = 1; gbc.anchor = GridBagConstraints.WEST;
        dialog.add(generoCombo, gbc);
        
        gbc.gridx = 0; gbc.gridy = 6; gbc.anchor = GridBagConstraints.EAST;
        dialog.add(new JLabel("Cargo:"), gbc);
        gbc.gridx = 1; gbc.anchor = GridBagConstraints.WEST;
        dialog.add(cargoCombo, gbc);
        
        gbc.gridx = 0; gbc.gridy = 7; gbc.anchor = GridBagConstraints.EAST;
        dialog.add(new JLabel("Salário:"), gbc);
        gbc.gridx = 1; gbc.anchor = GridBagConstraints.WEST;
        dialog.add(salarioField, gbc);
        
        JPanel buttonPanel = new JPanel();
        JButton salvarBtn = new JButton("Salvar");
        JButton cancelarBtn = new JButton("Cancelar");
        
        salvarBtn.addActionListener(e -> {
            try {
                String nome = nomeField.getText().trim();
                String cpf = cpfField.getText().trim();
                String telefone = telefoneField.getText().trim();
                String email = emailField.getText().trim();
                String endereco = enderecoField.getText().trim();
                String generoStr = (String) generoCombo.getSelectedItem();
                String cargoStr = (String) cargoCombo.getSelectedItem();
                double salario = Double.parseDouble(salarioField.getText().trim());
                
                if (nome.isEmpty() || cpf.isEmpty() || email.isEmpty()) {
                    JOptionPane.showMessageDialog(dialog, "Preencha todos os campos obrigatórios!", "Erro", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                LocalDateTime nascimento = LocalDateTime.of(1980, 1, 1, 0, 0);
                EnumGenero genero = EnumGenero.valueOf(generoStr);
                EnumCargo cargo = EnumCargo.valueOf(cargoStr);
                
                boolean sucesso = controladorCentral.registrarFuncionario(
                    nome, nascimento, cpf, telefone, email, endereco, genero, null, cargo, salario
                );
                
                if (sucesso) {
                    JOptionPane.showMessageDialog(dialog, "Funcionário cadastrado com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                    dialog.dispose();
                } else {
                    JOptionPane.showMessageDialog(dialog, "Erro ao cadastrar funcionário. Verifique os dados.", "Erro", JOptionPane.ERROR_MESSAGE);
                }
                
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(dialog, "Erro: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            }
        });
        
        cancelarBtn.addActionListener(e -> dialog.dispose());
        
        buttonPanel.add(salvarBtn);
        buttonPanel.add(cancelarBtn);
        
        gbc.gridx = 0; gbc.gridy = 8; gbc.gridwidth = 2;
        dialog.add(buttonPanel, gbc);
        
        dialog.setVisible(true);
    }
    
    private void listarFuncionarios() {
        try {
            String listaFuncionarios = controladorCentral.consultaListagem(1);
            
            if (listaFuncionarios == null || listaFuncionarios.trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, 
                    "Nenhum funcionário cadastrado no sistema.", 
                    "Lista de Funcionários", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            
            JDialog dialogLista = new JDialog((JFrame)parentFrame, "Lista de Funcionários", true);
            dialogLista.setSize(500, 400);
            dialogLista.setLocationRelativeTo(parentFrame);
            
            JTextArea areaLista = new JTextArea(listaFuncionarios);
            areaLista.setEditable(false);
            areaLista.setFont(new Font("Arial", Font.PLAIN, 12));
            
            JScrollPane scrollPane = new JScrollPane(areaLista);
            dialogLista.add(scrollPane);
            dialogLista.setVisible(true);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "Erro ao listar funcionários: " + e.getMessage(), 
                "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void editarFuncionario() {
        try {
            String identificador = JOptionPane.showInputDialog(
                this, 
                "Digite o nome ou email do funcionário que deseja editar:",
                "Editar Funcionário",
                JOptionPane.QUESTION_MESSAGE
            );
            
            if (identificador == null || identificador.trim().isEmpty()) {
                return;
            }
            
            Funcionario funcionario = CatalogoFuncionario.getInstance().buscarFuncionario(identificador.trim());
            if (funcionario == null) {
                funcionario = CatalogoFuncionario.getInstance().buscarFuncionarioPorEmail(identificador.trim());
            }
            
            if (funcionario == null) {
                JOptionPane.showMessageDialog(
                    this,
                    "Funcionário não encontrado: " + identificador,
                    "Erro",
                    JOptionPane.ERROR_MESSAGE
                );
                return;
            }
            
            Funcionario funcionarioLogado = controladorCentral.getFuncionarioLogado();
            boolean podeEditar = false;
            boolean isEdicaoPropia = funcionario.getEmail().equals(funcionarioLogado.getEmail());
            boolean isGerenteInicial = funcionarioLogado.getNome().equals("Gerente Inicial");
            boolean isGerente = funcionarioLogado.getCargo() == EnumCargo.GERENTE;
            
            if (isEdicaoPropia) {
                podeEditar = true;
                mostrarDialogEdicaoFuncionarioProprio(funcionario);
            } else if (isGerenteInicial) {
                podeEditar = true;
                mostrarDialogEdicaoGerenteInicial(funcionario);
            } else if (isGerente && funcionario.getCargo() != EnumCargo.GERENTE) {
                podeEditar = true;
                mostrarDialogEdicaoGerente(funcionario);
            }
            
            if (!podeEditar) {
                JOptionPane.showMessageDialog(
                    this,
                    "Você não tem permissão para editar este funcionário.\n" +
                    "Gerentes só podem editar funcionários comuns.\n" +
                    "Você só pode editar seus próprios dados.",
                    "Sem Permissão",
                    JOptionPane.WARNING_MESSAGE
                );
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(
                this,
                "Erro ao editar funcionário: " + e.getMessage(),
                "Erro",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }
    
    private void mostrarDialogEdicaoFuncionarioProprio(Funcionario funcionario) {
        JDialog dialog = new JDialog((JFrame)parentFrame, "Editar Meus Dados", true);
        dialog.setSize(400, 350);
        dialog.setLocationRelativeTo(parentFrame);
        
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;
        
        JPasswordField senhaField = new JPasswordField(15);
        JTextField telefoneField = new JTextField(funcionario.getTelefone(), 15);
        JTextField emailField = new JTextField(funcionario.getEmail(), 15);
        JTextField enderecoField = new JTextField(funcionario.getEndereco(), 15);
        
        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(new JLabel("Nova Senha:"), gbc);
        gbc.gridx = 1;
        panel.add(senhaField, gbc);
        
        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(new JLabel("Telefone:"), gbc);
        gbc.gridx = 1;
        panel.add(telefoneField, gbc);
        
        gbc.gridx = 0; gbc.gridy = 2;
        panel.add(new JLabel("Email:"), gbc);
        gbc.gridx = 1;
        panel.add(emailField, gbc);
        
        gbc.gridx = 0; gbc.gridy = 3;
        panel.add(new JLabel("Endereço:"), gbc);
        gbc.gridx = 1;
        panel.add(enderecoField, gbc);
        
        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton btnSalvar = new JButton("Salvar");
        JButton btnCancelar = new JButton("Cancelar");
        
        btnSalvar.addActionListener(e -> {
            try {
                String novaSenha = new String(senhaField.getPassword());
                String novoTelefone = telefoneField.getText().trim();
                String novoEmail = emailField.getText().trim();
                String novoEndereco = enderecoField.getText().trim();
                
                boolean sucesso = controladorCentral.editarFuncionarioProprio(
                    funcionario.getEmail(), 
                    novaSenha.isEmpty() ? null : novaSenha,
                    novoTelefone.isEmpty() ? null : novoTelefone,
                    novoEmail.isEmpty() ? null : novoEmail,
                    novoEndereco.isEmpty() ? null : novoEndereco
                );
                
                if (sucesso) {
                    JOptionPane.showMessageDialog(dialog, "Dados atualizados com sucesso!");
                    dialog.dispose();
                } else {
                    JOptionPane.showMessageDialog(dialog, "Erro ao atualizar dados", "Erro", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(dialog, "Erro: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            }
        });
        
        btnCancelar.addActionListener(e -> dialog.dispose());
        
        buttonPanel.add(btnSalvar);
        buttonPanel.add(btnCancelar);
        
        gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 2;
        panel.add(buttonPanel, gbc);
        
        dialog.add(panel);
        dialog.setVisible(true);
    }
    
    private void mostrarDialogEdicaoGerente(Funcionario funcionario) {
        JDialog dialog = new JDialog((JFrame)parentFrame, "Editar Funcionário (Gerente)", true);
        dialog.setSize(500, 450);
        dialog.setLocationRelativeTo(parentFrame);
        
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;
        
        JTextField nomeField = new JTextField(funcionario.getNome(), 15);
        JTextField telefoneField = new JTextField(funcionario.getTelefone(), 15);
        JTextField emailField = new JTextField(funcionario.getEmail(), 15);
        JTextField enderecoField = new JTextField(funcionario.getEndereco(), 15);
        JComboBox<EnumGenero> generoCombo = new JComboBox<>(EnumGenero.values());
        JComboBox<EnumCargo> cargoCombo = new JComboBox<>(EnumCargo.values());
        JTextField salarioField = new JTextField(String.valueOf(funcionario.getSalario()), 15);
        
        generoCombo.setSelectedItem(funcionario.getGenero());
        cargoCombo.setSelectedItem(funcionario.getCargo());
        
        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(new JLabel("Nome:"), gbc);
        gbc.gridx = 1;
        panel.add(nomeField, gbc);
        
        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(new JLabel("Telefone:"), gbc);
        gbc.gridx = 1;
        panel.add(telefoneField, gbc);
        
        gbc.gridx = 0; gbc.gridy = 2;
        panel.add(new JLabel("Email:"), gbc);
        gbc.gridx = 1;
        panel.add(emailField, gbc);
        
        gbc.gridx = 0; gbc.gridy = 3;
        panel.add(new JLabel("Endereço:"), gbc);
        gbc.gridx = 1;
        panel.add(enderecoField, gbc);
        
        gbc.gridx = 0; gbc.gridy = 4;
        panel.add(new JLabel("Gênero:"), gbc);
        gbc.gridx = 1;
        panel.add(generoCombo, gbc);
        
        gbc.gridx = 0; gbc.gridy = 5;
        panel.add(new JLabel("Cargo:"), gbc);
        gbc.gridx = 1;
        panel.add(cargoCombo, gbc);
        
        gbc.gridx = 0; gbc.gridy = 6;
        panel.add(new JLabel("Salário:"), gbc);
        gbc.gridx = 1;
        panel.add(salarioField, gbc);
        
        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton btnSalvar = new JButton("Salvar");
        JButton btnCancelar = new JButton("Cancelar");
        
        btnSalvar.addActionListener(e -> {
            try {
                String nome = nomeField.getText().trim();
                String telefone = telefoneField.getText().trim();
                String email = emailField.getText().trim();
                String endereco = enderecoField.getText().trim();
                EnumGenero genero = (EnumGenero) generoCombo.getSelectedItem();
                EnumCargo cargo = (EnumCargo) cargoCombo.getSelectedItem();
                Double salario = Double.parseDouble(salarioField.getText().trim());
                
                boolean sucesso = controladorCentral.editarFuncionarioPorGerente(
                    funcionario.getNome(),
                    nome.isEmpty() ? null : nome,
                    telefone.isEmpty() ? null : telefone,
                    email.isEmpty() ? null : email,
                    endereco.isEmpty() ? null : endereco,
                    null,
                    genero,
                    cargo,
                    salario
                );
                
                if (sucesso) {
                    JOptionPane.showMessageDialog(dialog, "Funcionário atualizado com sucesso!");
                    dialog.dispose();
                } else {
                    JOptionPane.showMessageDialog(dialog, "Erro ao atualizar funcionário", "Erro", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(dialog, "Erro: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            }
        });
        
        btnCancelar.addActionListener(e -> dialog.dispose());
        
        buttonPanel.add(btnSalvar);
        buttonPanel.add(btnCancelar);
        
        gbc.gridx = 0; gbc.gridy = 7; gbc.gridwidth = 2;
        panel.add(buttonPanel, gbc);
        
        dialog.add(panel);
        dialog.setVisible(true);
    }
    
    private void mostrarDialogEdicaoGerenteInicial(Funcionario funcionario) {
        JDialog dialog = new JDialog((JFrame)parentFrame, "Editar Funcionário (Gerente Inicial)", true);
        dialog.setSize(500, 500);
        dialog.setLocationRelativeTo(parentFrame);
        
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;
        
        JTextField nomeField = new JTextField(funcionario.getNome(), 15);
        JPasswordField senhaField = new JPasswordField(15);
        JTextField telefoneField = new JTextField(funcionario.getTelefone(), 15);
        JTextField emailField = new JTextField(funcionario.getEmail(), 15);
        JTextField enderecoField = new JTextField(funcionario.getEndereco(), 15);
        JComboBox<EnumGenero> generoCombo = new JComboBox<>(EnumGenero.values());
        JComboBox<EnumCargo> cargoCombo = new JComboBox<>(EnumCargo.values());
        JTextField salarioField = new JTextField(String.valueOf(funcionario.getSalario()), 15);
        
        generoCombo.setSelectedItem(funcionario.getGenero());
        cargoCombo.setSelectedItem(funcionario.getCargo());
        
        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(new JLabel("Nome:"), gbc);
        gbc.gridx = 1;
        panel.add(nomeField, gbc);
        
        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(new JLabel("Nova Senha:"), gbc);
        gbc.gridx = 1;
        panel.add(senhaField, gbc);
        
        gbc.gridx = 0; gbc.gridy = 2;
        panel.add(new JLabel("Telefone:"), gbc);
        gbc.gridx = 1;
        panel.add(telefoneField, gbc);
        
        gbc.gridx = 0; gbc.gridy = 3;
        panel.add(new JLabel("Email:"), gbc);
        gbc.gridx = 1;
        panel.add(emailField, gbc);
        
        gbc.gridx = 0; gbc.gridy = 4;
        panel.add(new JLabel("Endereço:"), gbc);
        gbc.gridx = 1;
        panel.add(enderecoField, gbc);
        
        gbc.gridx = 0; gbc.gridy = 5;
        panel.add(new JLabel("Gênero:"), gbc);
        gbc.gridx = 1;
        panel.add(generoCombo, gbc);
        
        gbc.gridx = 0; gbc.gridy = 6;
        panel.add(new JLabel("Cargo:"), gbc);
        gbc.gridx = 1;
        panel.add(cargoCombo, gbc);
        
        gbc.gridx = 0; gbc.gridy = 7;
        panel.add(new JLabel("Salário:"), gbc);
        gbc.gridx = 1;
        panel.add(salarioField, gbc);
        
        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton btnSalvar = new JButton("Salvar");
        JButton btnCancelar = new JButton("Cancelar");
        
        btnSalvar.addActionListener(e -> {
            try {
                String nome = nomeField.getText().trim();
                String senha = new String(senhaField.getPassword());
                String telefone = telefoneField.getText().trim();
                String email = emailField.getText().trim();
                String endereco = enderecoField.getText().trim();
                EnumGenero genero = (EnumGenero) generoCombo.getSelectedItem();
                EnumCargo cargo = (EnumCargo) cargoCombo.getSelectedItem();
                Double salario = Double.parseDouble(salarioField.getText().trim());
                
                String novoNome = nome.isEmpty() ? null : nome;
                String novaSenha = senha.isEmpty() ? null : senha;
                String novoTelefone = telefone.isEmpty() ? null : telefone;
                String novoEmail = email.isEmpty() ? null : email;
                String novoEndereco = endereco.isEmpty() ? null : endereco;
                
                boolean sucesso = controladorCentral.editarFuncionarioGerenteInicial(
                    funcionario.getNome(),
                    novoNome,
                    novoTelefone,
                    novoEmail,
                    novoEndereco,
                    null,
                    genero,
                    cargo,
                    salario,
                    novaSenha
                );
                
                if (sucesso) {
                    JOptionPane.showMessageDialog(dialog, "Funcionário atualizado com sucesso!");
                    dialog.dispose();
                } else {
                    JOptionPane.showMessageDialog(dialog, "Erro ao atualizar funcionário", "Erro", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(dialog, "Erro: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            }
        });
        
        btnCancelar.addActionListener(e -> dialog.dispose());
        
        buttonPanel.add(btnSalvar);
        buttonPanel.add(btnCancelar);
        
        gbc.gridx = 0; gbc.gridy = 8; gbc.gridwidth = 2;
        panel.add(buttonPanel, gbc);
        
        dialog.add(panel);
        dialog.setVisible(true);
    }
    
    private void arquivarFuncionario() {
        try {
            Funcionario funcionarioLogado = controladorCentral.getFuncionarioLogado();
            if (funcionarioLogado == null || funcionarioLogado.getCargo() != EnumCargo.GERENTE) {
                JOptionPane.showMessageDialog(this,
                    "Apenas gerentes podem arquivar funcionários!",
                    "Sem Permissão",
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            String nomeFuncionario = JOptionPane.showInputDialog(
                this, 
                "Digite o nome do funcionário que deseja arquivar:\n\n" +
                "⚠️ ATENÇÃO: Esta operação é irreversível!\n" +
                "O funcionário será marcado como arquivado.\n\n" +
                "NOTA: Gerentes não podem arquivar outros gerentes.",
                "Arquivar Funcionário",
                JOptionPane.WARNING_MESSAGE
            );
            
            if (nomeFuncionario == null || nomeFuncionario.trim().isEmpty()) {
                return;
            }
            
            Funcionario funcionarioAlvo = controladorCentral.buscarFuncionario(nomeFuncionario);
            if (funcionarioAlvo != null && funcionarioAlvo.getCargo() == EnumCargo.GERENTE) {
                JOptionPane.showMessageDialog(this,
                    "Não é possível arquivar um gerente!\n" +
                    "Apenas funcionários comuns podem ser arquivados.",
                    "Operação Negada",
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            int confirmacao = JOptionPane.showConfirmDialog(
                this,
                "Tem certeza que deseja arquivar o funcionário?\n\n" +
                "Funcionário: " + nomeFuncionario + "\n\n" +
                "Esta operação é irreversível!",
                "Confirmar Arquivamento",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE
            );
            
            if (confirmacao == JOptionPane.YES_OPTION) {
                boolean sucesso = controladorCentral.arquivarFuncionario(nomeFuncionario);
                
                if (sucesso) {
                    JOptionPane.showMessageDialog(this, "Funcionário arquivado com sucesso!");
                } else {
                    JOptionPane.showMessageDialog(this, 
                        "Erro ao arquivar funcionário!\nVerifique se o nome está correto.", 
                        "Erro", JOptionPane.ERROR_MESSAGE);
                }
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Erro inesperado: " + e.getMessage(),
                "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void buscarFuncionario() {
        try {
            String nomeFuncionario = JOptionPane.showInputDialog(
                this,
                "Digite o nome do funcionário que deseja buscar:",
                "Buscar Funcionário",
                JOptionPane.QUESTION_MESSAGE
            );
            
            if (nomeFuncionario == null || nomeFuncionario.trim().isEmpty()) {
                return;
            }
            
            Funcionario funcionario = controladorCentral.buscarFuncionario(nomeFuncionario.trim());
            
            if (funcionario != null) {
                JOptionPane.showMessageDialog(this,
                    "✅ Funcionário encontrado!\n\n" +
                    "Nome: " + funcionario.getNome() + "\n" +
                    "Email: " + funcionario.getEmail() + "\n" +
                    "Telefone: " + funcionario.getTelefone() + "\n" +
                    "Cargo: " + funcionario.getCargo() + "\n" +
                    "Salário: R$ " + funcionario.getSalario(),
                    "Funcionário Encontrado",
                    JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this,
                    "❌ Funcionário não encontrado!\n\n" +
                    "Nome buscado: " + nomeFuncionario + "\n\n" +
                    "Dicas:\n" +
                    "• Verifique se o nome está correto\n" +
                    "• A busca é case-sensitive\n" +
                    "• Use o nome completo cadastrado",
                    "Funcionário Não Encontrado",
                    JOptionPane.WARNING_MESSAGE);
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Erro ao buscar funcionário: " + e.getMessage(),
                "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void visualizarFuncionario() {
        try {
            String nomeFuncionario = JOptionPane.showInputDialog(
                this,
                "Digite o nome do funcionário para visualizar detalhes completos:",
                "Visualizar Funcionário",
                JOptionPane.QUESTION_MESSAGE
            );
            
            if (nomeFuncionario == null || nomeFuncionario.trim().isEmpty()) {
                return;
            }
            
            Funcionario funcionario = controladorCentral.buscarFuncionario(nomeFuncionario.trim());
            
            if (funcionario != null) {
                // Criar janela de visualização detalhada
                JDialog dialog = new JDialog((JFrame)parentFrame, "Detalhes do Funcionário", true);
                dialog.setSize(450, 350);
                dialog.setLocationRelativeTo(parentFrame);
                dialog.setLayout(new BorderLayout());
                
                JPanel painelInfo = new JPanel();
                painelInfo.setLayout(new BoxLayout(painelInfo, BoxLayout.Y_AXIS));
                painelInfo.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
                
                painelInfo.add(criarLabelInfo("👤 Nome:", funcionario.getNome()));
                painelInfo.add(Box.createVerticalStrut(10));
                painelInfo.add(criarLabelInfo("📧 Email:", funcionario.getEmail()));
                painelInfo.add(Box.createVerticalStrut(10));
                painelInfo.add(criarLabelInfo("📞 Telefone:", funcionario.getTelefone()));
                painelInfo.add(Box.createVerticalStrut(10));
                painelInfo.add(criarLabelInfo("💼 Cargo:", funcionario.getCargo().toString()));
                painelInfo.add(Box.createVerticalStrut(10));
                painelInfo.add(criarLabelInfo("💰 Salário:", "R$ " + String.format("%.2f", funcionario.getSalario())));
                painelInfo.add(Box.createVerticalStrut(10));
                painelInfo.add(criarLabelInfo("🔑 Senha:", funcionario.getSenha()));
                
                JButton btnFechar = criarBotao("Fechar", Color.GRAY);
                btnFechar.addActionListener(e -> dialog.dispose());
                
                JPanel painelBotao = new JPanel();
                painelBotao.add(btnFechar);
                
                dialog.add(painelInfo, BorderLayout.CENTER);
                dialog.add(painelBotao, BorderLayout.SOUTH);
                
                dialog.setVisible(true);
                
            } else {
                JOptionPane.showMessageDialog(this,
                    "❌ Funcionário não encontrado!\n\n" +
                    "Nome buscado: " + nomeFuncionario + "\n\n" +
                    "Dicas:\n" +
                    "• Verifique se o nome está correto\n" +
                    "• A busca é case-sensitive\n" +
                    "• Use o nome completo cadastrado",
                    "Funcionário Não Encontrado",
                    JOptionPane.WARNING_MESSAGE);
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Erro ao visualizar funcionário: " + e.getMessage(),
                "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private JPanel criarLabelInfo(String titulo, String valor) {
        JPanel painel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel lblTitulo = new JLabel(titulo);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 12));
        JLabel lblValor = new JLabel(valor);
        lblValor.setFont(new Font("Arial", Font.PLAIN, 12));
        
        painel.add(lblTitulo);
        painel.add(lblValor);
        return painel;
    }
}