package Interface;

import Controle.ControladorCentral;
import Conceitos.*;
import Catalogos.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.DefaultListModel;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

public class PainelAgendamentos extends JPanel {
    
    private ControladorCentral controladorCentral;
    private JFrame parentFrame;
    private static final Color COR_PRIMARIA = new Color(41, 98, 255);
    
    public PainelAgendamentos(ControladorCentral controlador, JFrame parent) {
        this.controladorCentral = controlador;
        this.parentFrame = parent;
        criarInterface();
    }
    
    private void criarInterface() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        JPanel botoes = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton btnVisita = criarBotao("Agendar Visita", COR_PRIMARIA);
        JButton btnVistoria = criarBotao("Agendar Vistoria", COR_PRIMARIA);
        JButton btnListarVisitas = criarBotao("Listar Visitas", Color.GRAY);
        JButton btnListarVistorias = criarBotao("Listar Vistorias", Color.GRAY);
        JButton btnEditarVisita = criarBotao("Editar Visita", new Color(255, 140, 0));
        JButton btnEditarVistoria = criarBotao("Editar Vistoria", new Color(255, 140, 0));
        JButton btnVisualizarVisita = criarBotao("Visualizar Visita", new Color(102, 51, 153));
        JButton btnVisualizarVistoria = criarBotao("Visualizar Vistoria", new Color(102, 51, 153));
        
        btnVisita.addActionListener(e -> agendarVisita());
        btnVistoria.addActionListener(e -> agendarVistoria());
        btnListarVisitas.addActionListener(e -> listarAgendamentosVisita());
        btnListarVistorias.addActionListener(e -> listarAgendamentosVistoria());
        btnEditarVisita.addActionListener(e -> editarAgendamentoVisita());
        btnEditarVistoria.addActionListener(e -> editarAgendamentoVistoria());
        btnVisualizarVisita.addActionListener(e -> visualizarVisita());
        btnVisualizarVistoria.addActionListener(e -> visualizarVistoria());
        
        botoes.add(btnVisita);
        botoes.add(btnListarVisitas);
        botoes.add(btnVisualizarVisita);
        botoes.add(btnVistoria);
        botoes.add(btnListarVistorias);
        botoes.add(btnVisualizarVistoria);
        botoes.add(btnEditarVisita);
        botoes.add(btnEditarVistoria);
        
        JPanel conteudo = new JPanel(new BorderLayout());
        JTable tabela = new JTable();
        JScrollPane scroll = new JScrollPane(tabela);
        conteudo.add(scroll, BorderLayout.CENTER);
        
        add(botoes, BorderLayout.NORTH);
        add(conteudo, BorderLayout.CENTER);
    }
    
    private JButton criarBotao(String texto, Color cor) {
        JButton botao = new JButton(texto);
        botao.setBackground(cor);
        botao.setForeground(Color.WHITE);
        botao.setFont(new Font("Arial", Font.BOLD, 12));
        botao.setFocusPainted(false);
        botao.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16));
        botao.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        botao.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                botao.setBackground(cor.darker());
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                botao.setBackground(cor);
            }
        });
        
        return botao;
    }
    
    private void agendarVisita() {
        if (CatalogoCliente.getInstance().listar().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Não há clientes cadastrados no sistema!");
            return;
        }
        
        if (CatalogoFuncionario.getInstance().getFuncionarios().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Não há funcionários cadastrados no sistema!");
            return;
        }
        
        if (CatalogoImovel.getInstance().getImoveis().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Não há imóveis cadastrados no sistema!");
            return;
        }
        
        JDialog dialog = new JDialog((JFrame)parentFrame, "Agendar Visita", true);
        dialog.setSize(500, 400);
        dialog.setLocationRelativeTo(parentFrame);
        dialog.setLayout(new BorderLayout());
        
        JPanel painelPrincipal = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.WEST;
        
        gbc.gridx = 0; gbc.gridy = 0;
        painelPrincipal.add(new JLabel("Data:"), gbc);
        
        JSpinner spinnerData = new JSpinner(new SpinnerDateModel());
        JSpinner.DateEditor editorData = new JSpinner.DateEditor(spinnerData, "dd/MM/yyyy");
        spinnerData.setEditor(editorData);
        gbc.gridx = 1;
        painelPrincipal.add(spinnerData, gbc);
        
        gbc.gridx = 0; gbc.gridy = 1;
        painelPrincipal.add(new JLabel("Hora:"), gbc);
        
        JSpinner spinnerHora = new JSpinner(new SpinnerDateModel());
        JSpinner.DateEditor editorHora = new JSpinner.DateEditor(spinnerHora, "HH:mm");
        spinnerHora.setEditor(editorHora);
        gbc.gridx = 1;
        painelPrincipal.add(spinnerHora, gbc);
        
        gbc.gridx = 0; gbc.gridy = 2;
        painelPrincipal.add(new JLabel("Cliente:"), gbc);
        
        JComboBox<Cliente> comboCliente = new JComboBox<>();
        for (Cliente cliente : CatalogoCliente.getInstance().getClientes()) {
            comboCliente.addItem(cliente);
        }
        gbc.gridx = 1;
        painelPrincipal.add(comboCliente, gbc);
        
        gbc.gridx = 0; gbc.gridy = 3;
        painelPrincipal.add(new JLabel("Funcionário:"), gbc);
        
        JComboBox<Funcionario> comboFuncionario = new JComboBox<>();
        for (Funcionario funcionario : CatalogoFuncionario.getInstance().getFuncionarios()) {
            comboFuncionario.addItem(funcionario);
        }
        gbc.gridx = 1;
        painelPrincipal.add(comboFuncionario, gbc);
        
        gbc.gridx = 0; gbc.gridy = 4;
        painelPrincipal.add(new JLabel("Imóvel:"), gbc);
        
        JComboBox<imovel> comboImovel = new JComboBox<>();
        for (imovel imovelItem : CatalogoImovel.getInstance().getImoveis()) {
            comboImovel.addItem(imovelItem);
        }
        gbc.gridx = 1;
        painelPrincipal.add(comboImovel, gbc);
        
        JPanel painelBotoes = new JPanel(new FlowLayout());
        JButton btnCancelar = criarBotao("Cancelar", Color.GRAY);
        JButton btnSalvar = criarBotao("Agendar", COR_PRIMARIA);
        
        btnCancelar.addActionListener(e -> dialog.dispose());
        
        btnSalvar.addActionListener(e -> {
            try {
                Date data = (Date) spinnerData.getValue();
                Date hora = (Date) spinnerHora.getValue();
                
                java.util.Calendar cal = java.util.Calendar.getInstance();
                cal.setTime(data);
                
                java.util.Calendar calHora = java.util.Calendar.getInstance();
                calHora.setTime(hora);
                
                cal.set(java.util.Calendar.HOUR_OF_DAY, calHora.get(java.util.Calendar.HOUR_OF_DAY));
                cal.set(java.util.Calendar.MINUTE, calHora.get(java.util.Calendar.MINUTE));
                
                LocalDateTime dataHora = cal.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
                
                Cliente clienteSelecionado = (Cliente) comboCliente.getSelectedItem();
                Funcionario funcionarioSelecionado = (Funcionario) comboFuncionario.getSelectedItem();
                imovel imovelSelecionado = (imovel) comboImovel.getSelectedItem();
                
                if (!CatalogoAgendamentoVisita.getInstance().verificarDisponibilidade(dataHora, funcionarioSelecionado, null)) {
                    JOptionPane.showMessageDialog(dialog, "Funcionário não disponível neste horário!");
                    return;
                }
                
                AgendamentoVisita agendamento = new AgendamentoVisita(dataHora, funcionarioSelecionado, clienteSelecionado, imovelSelecionado);
                CatalogoAgendamentoVisita.getInstance().adicionarAgendamento(agendamento);
                
                JOptionPane.showMessageDialog(dialog, "Visita agendada com sucesso!");
                dialog.dispose();
                
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(dialog, "Erro ao agendar visita: " + ex.getMessage());
            }
        });
        
        painelBotoes.add(btnCancelar);
        painelBotoes.add(btnSalvar);
        
        dialog.add(painelPrincipal, BorderLayout.CENTER);
        dialog.add(painelBotoes, BorderLayout.SOUTH);
        
        dialog.setVisible(true);
    }
    
    private void agendarVistoria() {
        if (CatalogoFuncionario.getInstance().getFuncionarios().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Não há funcionários cadastrados no sistema!");
            return;
        }
        
        if (CatalogoImovel.getInstance().getImoveis().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Não há imóveis cadastrados no sistema!");
            return;
        }
        
        JDialog dialog = new JDialog((JFrame)parentFrame, "Agendar Vistoria", true);
        dialog.setSize(500, 350);
        dialog.setLocationRelativeTo(parentFrame);
        dialog.setLayout(new BorderLayout());
        
        JPanel painelPrincipal = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.WEST;
        
        gbc.gridx = 0; gbc.gridy = 0;
        painelPrincipal.add(new JLabel("Data:"), gbc);
        
        JSpinner spinnerData = new JSpinner(new SpinnerDateModel());
        JSpinner.DateEditor editorData = new JSpinner.DateEditor(spinnerData, "dd/MM/yyyy");
        spinnerData.setEditor(editorData);
        gbc.gridx = 1;
        painelPrincipal.add(spinnerData, gbc);
        
        gbc.gridx = 0; gbc.gridy = 1;
        painelPrincipal.add(new JLabel("Hora:"), gbc);
        
        JSpinner spinnerHora = new JSpinner(new SpinnerDateModel());
        JSpinner.DateEditor editorHora = new JSpinner.DateEditor(spinnerHora, "HH:mm");
        spinnerHora.setEditor(editorHora);
        gbc.gridx = 1;
        painelPrincipal.add(spinnerHora, gbc);
        
        gbc.gridx = 0; gbc.gridy = 2;
        painelPrincipal.add(new JLabel("Funcionário:"), gbc);
        
        JComboBox<Funcionario> comboFuncionario = new JComboBox<>();
        for (Funcionario funcionario : CatalogoFuncionario.getInstance().getFuncionarios()) {
            comboFuncionario.addItem(funcionario);
        }
        gbc.gridx = 1;
        painelPrincipal.add(comboFuncionario, gbc);
        
        gbc.gridx = 0; gbc.gridy = 3;
        painelPrincipal.add(new JLabel("Imóvel:"), gbc);
        
        JComboBox<imovel> comboImovel = new JComboBox<>();
        for (imovel imovelItem : CatalogoImovel.getInstance().getImoveis()) {
            comboImovel.addItem(imovelItem);
        }
        gbc.gridx = 1;
        painelPrincipal.add(comboImovel, gbc);
        
        JPanel painelBotoes = new JPanel(new FlowLayout());
        JButton btnCancelar = criarBotao("Cancelar", Color.GRAY);
        JButton btnSalvar = criarBotao("Agendar", COR_PRIMARIA);
        
        btnCancelar.addActionListener(e -> dialog.dispose());
        
        btnSalvar.addActionListener(e -> {
            try {
                Date data = (Date) spinnerData.getValue();
                Date hora = (Date) spinnerHora.getValue();
                
                java.util.Calendar cal = java.util.Calendar.getInstance();
                cal.setTime(data);
                
                java.util.Calendar calHora = java.util.Calendar.getInstance();
                calHora.setTime(hora);
                
                cal.set(java.util.Calendar.HOUR_OF_DAY, calHora.get(java.util.Calendar.HOUR_OF_DAY));
                cal.set(java.util.Calendar.MINUTE, calHora.get(java.util.Calendar.MINUTE));
                
                LocalDateTime dataHora = cal.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
                
                Funcionario funcionarioSelecionado = (Funcionario) comboFuncionario.getSelectedItem();
                imovel imovelSelecionado = (imovel) comboImovel.getSelectedItem();
                
                if (!CatalogoAgendamentoVistoria.getInstance().verificarDisponibilidade(dataHora, funcionarioSelecionado, null)) {
                    JOptionPane.showMessageDialog(dialog, "Funcionário não disponível neste horário!");
                    return;
                }
                
                AgendamentoVistoria agendamento = new AgendamentoVistoria(dataHora, funcionarioSelecionado, imovelSelecionado);
                CatalogoAgendamentoVistoria.getInstance().adicionarAgendamento(agendamento);
                
                JOptionPane.showMessageDialog(dialog, "Vistoria agendada com sucesso!");
                dialog.dispose();
                
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(dialog, "Erro ao agendar vistoria: " + ex.getMessage());
            }
        });
        
        painelBotoes.add(btnCancelar);
        painelBotoes.add(btnSalvar);
        
        dialog.add(painelPrincipal, BorderLayout.CENTER);
        dialog.add(painelBotoes, BorderLayout.SOUTH);
        
        dialog.setVisible(true);
    }
    
    private void editarAgendamentoVisita() {
        if (CatalogoAgendamentoVisita.getInstance().listarTodos().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Não há agendamentos de visita para editar!");
            return;
        }
        
        JDialog dialog = new JDialog((JFrame)parentFrame, "Editar Agendamento de Visita", true);
        dialog.setSize(600, 500);
        dialog.setLocationRelativeTo(parentFrame);
        dialog.setLayout(new BorderLayout());
        
        DefaultListModel<String> modeloLista = new DefaultListModel<>();
        java.util.List<AgendamentoVisita> agendamentos = CatalogoAgendamentoVisita.getInstance().listarTodos();
        
        for (int i = 0; i < agendamentos.size(); i++) {
            AgendamentoVisita ag = agendamentos.get(i);
            String item = String.format("[%d] %s - Cliente: %s - Funcionário: %s - Imóvel: %s", 
                i + 1, formatarDataHora(ag.getDataHora()), ag.getCliente().getNome(), 
                ag.getFuncionario().getNome(), ag.getImovel().getNome());
            modeloLista.addElement(item);
        }
        
        JList<String> lista = new JList<>(modeloLista);
        lista.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scrollLista = new JScrollPane(lista);
        scrollLista.setBorder(BorderFactory.createTitledBorder("Selecione o agendamento para editar:"));
        
        JPanel painelBotoes = new JPanel(new FlowLayout());
        JButton btnEditar = criarBotao("Editar Selecionado", COR_PRIMARIA);
        JButton btnCancelar = criarBotao("Cancelar", Color.GRAY);
        
        btnEditar.addActionListener(e -> {
            int indice = lista.getSelectedIndex();
            if (indice >= 0) {
                dialog.dispose();
                editarAgendamentoVisitaSelecionado(agendamentos.get(indice));
            } else {
                JOptionPane.showMessageDialog(dialog, "Selecione um agendamento para editar!");
            }
        });
        
        btnCancelar.addActionListener(e -> dialog.dispose());
        
        painelBotoes.add(btnEditar);
        painelBotoes.add(btnCancelar);
        
        dialog.add(scrollLista, BorderLayout.CENTER);
        dialog.add(painelBotoes, BorderLayout.SOUTH);
        dialog.setVisible(true);
    }
    
    private void editarAgendamentoVisitaSelecionado(AgendamentoVisita agendamento) {
        JDialog dialog = new JDialog((JFrame)parentFrame, "Editar Visita", true);
        dialog.setSize(500, 400);
        dialog.setLocationRelativeTo(parentFrame);
        dialog.setLayout(new BorderLayout());
        
        JPanel painelPrincipal = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.WEST;
        
        gbc.gridx = 0; gbc.gridy = 0;
        painelPrincipal.add(new JLabel("Data:"), gbc);
        
        JSpinner spinnerData = new JSpinner(new SpinnerDateModel());
        JSpinner.DateEditor editorData = new JSpinner.DateEditor(spinnerData, "dd/MM/yyyy");
        spinnerData.setEditor(editorData);
        if (agendamento.getDataHora() != null) {
            Date dataAtual = Date.from(agendamento.getDataHora().atZone(ZoneId.systemDefault()).toInstant());
            spinnerData.setValue(dataAtual);
        }
        gbc.gridx = 1;
        painelPrincipal.add(spinnerData, gbc);
        
        gbc.gridx = 0; gbc.gridy = 1;
        painelPrincipal.add(new JLabel("Hora:"), gbc);
        
        JSpinner spinnerHora = new JSpinner(new SpinnerDateModel());
        JSpinner.DateEditor editorHora = new JSpinner.DateEditor(spinnerHora, "HH:mm");
        spinnerHora.setEditor(editorHora);
        if (agendamento.getDataHora() != null) {
            Date horaAtual = Date.from(agendamento.getDataHora().atZone(ZoneId.systemDefault()).toInstant());
            spinnerHora.setValue(horaAtual);
        }
        gbc.gridx = 1;
        painelPrincipal.add(spinnerHora, gbc);
        
        JPanel painelBotoes = new JPanel(new FlowLayout());
        JButton btnSalvar = criarBotao("Salvar Alterações", COR_PRIMARIA);
        JButton btnCancelar = criarBotao("Cancelar", Color.GRAY);
        
        btnSalvar.addActionListener(e -> {
            try {
                Date data = (Date) spinnerData.getValue();
                Date hora = (Date) spinnerHora.getValue();
                
                java.util.Calendar calData = java.util.Calendar.getInstance();
                calData.setTime(data);
                java.util.Calendar calHora = java.util.Calendar.getInstance();
                calHora.setTime(hora);
                
                calData.set(java.util.Calendar.HOUR_OF_DAY, calHora.get(java.util.Calendar.HOUR_OF_DAY));
                calData.set(java.util.Calendar.MINUTE, calHora.get(java.util.Calendar.MINUTE));
                
                LocalDateTime novaDataHora = calData.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
                
                agendamento.setDataHora(novaDataHora);
                
                JOptionPane.showMessageDialog(parentFrame, "Agendamento de visita atualizado com sucesso!");
                dialog.dispose();
                
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(parentFrame, "Erro ao atualizar agendamento: " + ex.getMessage());
            }
        });
        
        btnCancelar.addActionListener(e -> dialog.dispose());
        
        painelBotoes.add(btnSalvar);
        painelBotoes.add(btnCancelar);
        
        dialog.add(painelPrincipal, BorderLayout.CENTER);
        dialog.add(painelBotoes, BorderLayout.SOUTH);
        dialog.setVisible(true);
    }
    
    private void editarAgendamentoVistoria() {
        if (CatalogoAgendamentoVistoria.getInstance().listarTodos().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Não há agendamentos de vistoria para editar!");
            return;
        }
        
        JDialog dialog = new JDialog((JFrame)parentFrame, "Editar Agendamento de Vistoria", true);
        dialog.setSize(600, 500);
        dialog.setLocationRelativeTo(parentFrame);
        dialog.setLayout(new BorderLayout());
        
        DefaultListModel<String> modeloLista = new DefaultListModel<>();
        java.util.List<AgendamentoVistoria> agendamentos = CatalogoAgendamentoVistoria.getInstance().listarTodos();
        
        for (int i = 0; i < agendamentos.size(); i++) {
            AgendamentoVistoria ag = agendamentos.get(i);
            String item = String.format("[%d] %s - Funcionário: %s - Imóvel: %s", 
                i + 1, formatarDataHora(ag.getDataHora()), ag.getFuncionario().getNome(), ag.getImovel().getNome());
            modeloLista.addElement(item);
        }
        
        JList<String> lista = new JList<>(modeloLista);
        lista.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scrollLista = new JScrollPane(lista);
        scrollLista.setBorder(BorderFactory.createTitledBorder("Selecione o agendamento para editar:"));
        
        JPanel painelBotoes = new JPanel(new FlowLayout());
        JButton btnEditar = criarBotao("Editar Selecionado", COR_PRIMARIA);
        JButton btnCancelar = criarBotao("Cancelar", Color.GRAY);
        
        btnEditar.addActionListener(e -> {
            int indice = lista.getSelectedIndex();
            if (indice >= 0) {
                dialog.dispose();
                editarAgendamentoVistoriaSelecionado(agendamentos.get(indice));
            } else {
                JOptionPane.showMessageDialog(dialog, "Selecione um agendamento para editar!");
            }
        });
        
        btnCancelar.addActionListener(e -> dialog.dispose());
        
        painelBotoes.add(btnEditar);
        painelBotoes.add(btnCancelar);
        
        dialog.add(scrollLista, BorderLayout.CENTER);
        dialog.add(painelBotoes, BorderLayout.SOUTH);
        dialog.setVisible(true);
    }
    
    private void editarAgendamentoVistoriaSelecionado(AgendamentoVistoria agendamento) {
        JDialog dialog = new JDialog((JFrame)parentFrame, "Editar Vistoria", true);
        dialog.setSize(500, 400);
        dialog.setLocationRelativeTo(parentFrame);
        dialog.setLayout(new BorderLayout());
        
        JPanel painelPrincipal = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.WEST;
        
        gbc.gridx = 0; gbc.gridy = 0;
        painelPrincipal.add(new JLabel("Data:"), gbc);
        
        JSpinner spinnerData = new JSpinner(new SpinnerDateModel());
        JSpinner.DateEditor editorData = new JSpinner.DateEditor(spinnerData, "dd/MM/yyyy");
        spinnerData.setEditor(editorData);
        if (agendamento.getDataHora() != null) {
            Date dataAtual = Date.from(agendamento.getDataHora().atZone(ZoneId.systemDefault()).toInstant());
            spinnerData.setValue(dataAtual);
        }
        gbc.gridx = 1;
        painelPrincipal.add(spinnerData, gbc);
        
        gbc.gridx = 0; gbc.gridy = 1;
        painelPrincipal.add(new JLabel("Hora:"), gbc);
        
        JSpinner spinnerHora = new JSpinner(new SpinnerDateModel());
        JSpinner.DateEditor editorHora = new JSpinner.DateEditor(spinnerHora, "HH:mm");
        spinnerHora.setEditor(editorHora);
        if (agendamento.getDataHora() != null) {
            Date horaAtual = Date.from(agendamento.getDataHora().atZone(ZoneId.systemDefault()).toInstant());
            spinnerHora.setValue(horaAtual);
        }
        gbc.gridx = 1;
        painelPrincipal.add(spinnerHora, gbc);
        
        JPanel painelBotoes = new JPanel(new FlowLayout());
        JButton btnSalvar = criarBotao("Salvar Alterações", COR_PRIMARIA);
        JButton btnCancelar = criarBotao("Cancelar", Color.GRAY);
        
        btnSalvar.addActionListener(e -> {
            try {
                Date data = (Date) spinnerData.getValue();
                Date hora = (Date) spinnerHora.getValue();
                
                java.util.Calendar calData = java.util.Calendar.getInstance();
                calData.setTime(data);
                java.util.Calendar calHora = java.util.Calendar.getInstance();
                calHora.setTime(hora);
                
                calData.set(java.util.Calendar.HOUR_OF_DAY, calHora.get(java.util.Calendar.HOUR_OF_DAY));
                calData.set(java.util.Calendar.MINUTE, calHora.get(java.util.Calendar.MINUTE));
                
                LocalDateTime novaDataHora = calData.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
                
                agendamento.setDataHora(novaDataHora);
                
                JOptionPane.showMessageDialog(parentFrame, "Agendamento de vistoria atualizado com sucesso!");
                dialog.dispose();
                
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(parentFrame, "Erro ao atualizar agendamento: " + ex.getMessage());
            }
        });
        
        btnCancelar.addActionListener(e -> dialog.dispose());
        
        painelBotoes.add(btnSalvar);
        painelBotoes.add(btnCancelar);
        
        dialog.add(painelPrincipal, BorderLayout.CENTER);
        dialog.add(painelBotoes, BorderLayout.SOUTH);
        dialog.setVisible(true);
    }
    
    private String formatarDataHora(LocalDateTime dataHora) {
        if (dataHora == null) return "Data não definida";
        
        java.time.format.DateTimeFormatter formatter = java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        return dataHora.format(formatter);
    }
    
    private void listarAgendamentosVisita() {
        try {
            var agendamentos = CatalogoAgendamentoVisita.getInstance().listarTodos();
            
            if (agendamentos.isEmpty()) {
                JOptionPane.showMessageDialog(this, 
                    "Nenhuma visita agendada no sistema.",
                    "Lista de Visitas", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            
            // Criar dialog de listagem
            JDialog dialogLista = new JDialog((JFrame)parentFrame, "Lista de Agendamentos de Visita", true);
            dialogLista.setSize(800, 600);
            dialogLista.setLocationRelativeTo(parentFrame);
            dialogLista.setLayout(new BorderLayout());
            
            // Painel de informações
            JPanel painelInfo = new JPanel(new FlowLayout(FlowLayout.LEFT));
            painelInfo.setBorder(BorderFactory.createTitledBorder("Informações"));
            JLabel lblInfo = new JLabel("Total de Visitas Agendadas: " + agendamentos.size() + 
                " | Atualizado em: " + java.time.LocalDateTime.now().format(
                java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")));
            painelInfo.add(lblInfo);
            
            // Formatação da lista
            StringBuilder listaFormatada = new StringBuilder();
            listaFormatada.append("=== AGENDAMENTOS DE VISITA ===\n\n");
            listaFormatada.append("Total: ").append(agendamentos.size()).append(" agendamento(s)\n");
            listaFormatada.append("Gerado em: ").append(java.time.LocalDateTime.now().format(
                java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"))).append("\n\n");
            
            listaFormatada.append("--- LISTA DETALHADA ---\n");
            for (int i = 0; i < agendamentos.size(); i++) {
                var agendamento = agendamentos.get(i);
                listaFormatada.append("\n").append(i + 1).append(". Visita Agendada\n");
                listaFormatada.append("   ID: ").append(agendamento.getId()).append("\n");
                listaFormatada.append("   Data/Hora: ").append(formatarDataHora(agendamento.getDataHora())).append("\n");
                listaFormatada.append("   Funcionário: ").append(agendamento.getFuncionario() != null ? 
                    agendamento.getFuncionario().getNome() : "Não definido").append("\n");
                listaFormatada.append("   Cliente: ").append(agendamento.getCliente() != null ? 
                    agendamento.getCliente().getNome() : "Não definido").append("\n");
                listaFormatada.append("   Imóvel: ").append(agendamento.getImovel() != null ? 
                    agendamento.getImovel().getNome() : "Não definido").append("\n");
            }
            
            // Área de texto
            JTextArea areaLista = new JTextArea();
            areaLista.setEditable(false);
            areaLista.setFont(new Font("Courier New", Font.PLAIN, 11));
            areaLista.setText(listaFormatada.toString());
            
            JScrollPane scrollPane = new JScrollPane(areaLista);
            
            // Botões
            JPanel painelBotoes = new JPanel(new FlowLayout());
            JButton btnFechar = criarBotao("Fechar", Color.GRAY);
            JButton btnAtualizar = criarBotao("Atualizar", new Color(0, 150, 136));
            
            btnFechar.addActionListener(e -> dialogLista.dispose());
            btnAtualizar.addActionListener(e -> {
                dialogLista.dispose();
                listarAgendamentosVisita(); // Recarregar
            });
            
            painelBotoes.add(btnAtualizar);
            painelBotoes.add(btnFechar);
            
            dialogLista.add(painelInfo, BorderLayout.NORTH);
            dialogLista.add(scrollPane, BorderLayout.CENTER);
            dialogLista.add(painelBotoes, BorderLayout.SOUTH);
            
            dialogLista.setVisible(true);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "Erro ao listar agendamentos de visita: " + e.getMessage(), 
                "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void listarAgendamentosVistoria() {
        try {
            var agendamentos = CatalogoAgendamentoVistoria.getInstance().listarTodos();
            
            if (agendamentos.isEmpty()) {
                JOptionPane.showMessageDialog(this, 
                    "Nenhuma vistoria agendada no sistema.",
                    "Lista de Vistorias", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            
            // Criar dialog de listagem
            JDialog dialogLista = new JDialog((JFrame)parentFrame, "Lista de Agendamentos de Vistoria", true);
            dialogLista.setSize(800, 600);
            dialogLista.setLocationRelativeTo(parentFrame);
            dialogLista.setLayout(new BorderLayout());
            
            // Painel de informações
            JPanel painelInfo = new JPanel(new FlowLayout(FlowLayout.LEFT));
            painelInfo.setBorder(BorderFactory.createTitledBorder("Informações"));
            JLabel lblInfo = new JLabel("Total de Vistorias Agendadas: " + agendamentos.size() + 
                " | Atualizado em: " + java.time.LocalDateTime.now().format(
                java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")));
            painelInfo.add(lblInfo);
            
            // Formatação da lista
            StringBuilder listaFormatada = new StringBuilder();
            listaFormatada.append("=== AGENDAMENTOS DE VISTORIA ===\n\n");
            listaFormatada.append("Total: ").append(agendamentos.size()).append(" agendamento(s)\n");
            listaFormatada.append("Gerado em: ").append(java.time.LocalDateTime.now().format(
                java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"))).append("\n\n");
            
            listaFormatada.append("--- LISTA DETALHADA ---\n");
            for (int i = 0; i < agendamentos.size(); i++) {
                var agendamento = agendamentos.get(i);
                listaFormatada.append("\n").append(i + 1).append(". Vistoria Agendada\n");
                listaFormatada.append("   ID: ").append(agendamento.getId()).append("\n");
                listaFormatada.append("   Data/Hora: ").append(formatarDataHora(agendamento.getDataHora())).append("\n");
                listaFormatada.append("   Funcionário: ").append(agendamento.getFuncionario() != null ? 
                    agendamento.getFuncionario().getNome() : "Não definido").append("\n");
                listaFormatada.append("   Imóvel: ").append(agendamento.getImovel() != null ? 
                    agendamento.getImovel().getNome() : "Não definido").append("\n");
            }
            
            // Área de texto
            JTextArea areaLista = new JTextArea();
            areaLista.setEditable(false);
            areaLista.setFont(new Font("Courier New", Font.PLAIN, 11));
            areaLista.setText(listaFormatada.toString());
            
            JScrollPane scrollPane = new JScrollPane(areaLista);
            
            // Botões
            JPanel painelBotoes = new JPanel(new FlowLayout());
            JButton btnFechar = criarBotao("Fechar", Color.GRAY);
            JButton btnAtualizar = criarBotao("Atualizar", new Color(0, 150, 136));
            
            btnFechar.addActionListener(e -> dialogLista.dispose());
            btnAtualizar.addActionListener(e -> {
                dialogLista.dispose();
                listarAgendamentosVistoria(); // Recarregar
            });
            
            painelBotoes.add(btnAtualizar);
            painelBotoes.add(btnFechar);
            
            dialogLista.add(painelInfo, BorderLayout.NORTH);
            dialogLista.add(scrollPane, BorderLayout.CENTER);
            dialogLista.add(painelBotoes, BorderLayout.SOUTH);
            
            dialogLista.setVisible(true);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "Erro ao listar agendamentos de vistoria: " + e.getMessage(), 
                "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void visualizarVisita() {
        try {
            String identificador = JOptionPane.showInputDialog(
                this,
                "Digite o identificador do agendamento de visita:",
                "Visualizar Visita",
                JOptionPane.QUESTION_MESSAGE
            );
            
            if (identificador == null || identificador.trim().isEmpty()) {
                return;
            }
            
            JOptionPane.showMessageDialog(this,
                "Identificador buscado: " + identificador + "\n\n" +
                "Agendamento de visita pesquisado no sistema.",
                "Busca de Agendamento",
                JOptionPane.INFORMATION_MESSAGE);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Erro ao visualizar visita: " + e.getMessage(),
                "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void visualizarVistoria() {
        try {
            String identificador = JOptionPane.showInputDialog(
                this,
                "Digite o identificador do agendamento de vistoria:",
                "Visualizar Vistoria",
                JOptionPane.QUESTION_MESSAGE
            );
            
            if (identificador == null || identificador.trim().isEmpty()) {
                return;
            }
            
            JOptionPane.showMessageDialog(this,
                "Identificador buscado: " + identificador + "\n\n" +
                "Agendamento de vistoria pesquisado no sistema.",
                "Busca de Agendamento",
                JOptionPane.INFORMATION_MESSAGE);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Erro ao visualizar vistoria: " + e.getMessage(),
                "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private JPanel criarLabelInfo(String titulo, String valor) {
        JPanel painel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel lblTitulo = new JLabel(titulo);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 12));
        JLabel lblValor = new JLabel(valor);
        lblValor.setFont(new Font("Arial", Font.PLAIN, 12));
        
        painel.add(lblTitulo);
        painel.add(lblValor);
        return painel;
    }
}